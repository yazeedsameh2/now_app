/// Date helpers. Calendar dates are local, date-only values (never UTC).

DateTime dateOnly(DateTime value) {
  return DateTime(value.year, value.month, value.day);
}

/// Adds whole calendar days; safe across daylight-saving changes.
DateTime addDays(DateTime date, int days) {
  return DateTime(date.year, date.month, date.day + days);
}

bool isSameDay(DateTime a, DateTime b) {
  return a.year == b.year && a.month == b.month && a.day == b.day;
}

/// Local wall-clock instant for [date] at [minutes] after midnight.
DateTime atMinutes(DateTime date, int minutes) {
  return DateTime(date.year, date.month, date.day, 0, minutes);
}

/// First day of the week containing [date]. [firstWeekday] uses
/// [DateTime.monday] .. [DateTime.sunday].
DateTime startOfWeek(DateTime date, int firstWeekday) {
  final diff = (date.weekday - firstWeekday + 7) % 7;
  return addDays(dateOnly(date), -diff);
}

String dateKey(DateTime date) {
  final month = date.month.toString().padLeft(2, '0');
  final day = date.day.toString().padLeft(2, '0');
  return '${date.year.toString().padLeft(4, '0')}-$month-$day';
}

DateTime? parseDateKey(String? key) {
  if (key == null) {
    return null;
  }
  final parts = key.split('-');
  if (parts.length != 3) {
    return null;
  }
  final year = int.tryParse(parts[0]);
  final month = int.tryParse(parts[1]);
  final day = int.tryParse(parts[2]);
  if (year == null || month == null || day == null) {
    return null;
  }
  return DateTime(year, month, day);
}

/// Converts Flutter's firstDayOfWeekIndex (0 = Sunday) to a DateTime weekday.
int weekdayFromFirstDayIndex(int index) {
  return index == 0 ? DateTime.sunday : index;
}
