import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:now_app/app/app_shell.dart';
import 'package:now_app/features/calendar/presentation/calendar_screen.dart';
import 'package:now_app/features/dashboard/presentation/dashboard_screen.dart';
import 'package:now_app/features/settings/presentation/settings_screen.dart';
import 'package:now_app/features/tasks/presentation/tasks_screen.dart';

abstract final class AppRoutes {
  static const home = '/';
  static const tasks = '/tasks';
  static const calendar = '/calendar';
  static const settings = '/settings';
}

StatefulShellBranch _branch(
  String path,
  Widget Function(BuildContext, GoRouterState) builder,
) {
  return StatefulShellBranch(
    routes: [GoRoute(path: path, builder: builder)],
  );
}

final routerProvider = Provider<GoRouter>((ref) {
  final router = GoRouter(
    initialLocation: AppRoutes.home,
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => AppShell(navigationShell: shell),
        branches: [
          _branch(AppRoutes.home, (context, state) => const DashboardScreen()),
          _branch(AppRoutes.tasks, (context, state) => const TasksScreen()),
          _branch(
            AppRoutes.calendar,
            (context, state) => const CalendarScreen(),
          ),
          _branch(
            AppRoutes.settings,
            (context, state) => const SettingsScreen(),
          ),
        ],
      ),
    ],
  );
  ref.onDispose(router.dispose);
  return router;
});
