import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:now_app/app/router.dart';
import 'package:now_app/core/theme/app_theme.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/l10n/app_localizations.dart';

class NowApp extends ConsumerWidget {
  const NowApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsControllerProvider);
    final router = ref.watch(routerProvider);

    return MaterialApp.router(
      onGenerateTitle: (context) => AppLocalizations.of(context).appName,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: _themeMode(settings.theme),
      locale: _locale(settings.language),
      localizationsDelegates: const [
        AppLocalizations.delegate,
        ...GlobalMaterialLocalizations.delegates,
      ],
      supportedLocales: AppLocalizations.supportedLocales,
      routerConfig: router,
    );
  }
}

ThemeMode _themeMode(AppThemeSetting setting) {
  return switch (setting) {
    AppThemeSetting.system => ThemeMode.system,
    AppThemeSetting.light => ThemeMode.light,
    AppThemeSetting.dark => ThemeMode.dark,
  };
}

/// `null` means "follow the device locale".
Locale? _locale(AppLanguage language) {
  return switch (language) {
    AppLanguage.system => null,
    AppLanguage.arabic => const Locale('ar'),
    AppLanguage.english => const Locale('en'),
  };
}
