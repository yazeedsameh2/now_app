import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart'
    as fln;
import 'package:now_app/features/reminders/domain/notification_service.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// flutter_local_notifications behind the [NotificationService] interface.
///
/// Reminders are absolute instants, so they are scheduled in UTC. Local
/// wall-clock times are recomputed (and rescheduled) whenever the app
/// reconciles, which keeps them correct after timezone changes.
class LocalNotificationService implements NotificationService {
  final fln.FlutterLocalNotificationsPlugin _plugin =
      fln.FlutterLocalNotificationsPlugin();
  bool? _lastRequestResult;

  fln.AndroidFlutterLocalNotificationsPlugin? get _android {
    return _plugin
        .resolvePlatformSpecificImplementation<
          fln.AndroidFlutterLocalNotificationsPlugin
        >();
  }

  @override
  Future<void> initialize() async {
    tzdata.initializeTimeZones();
    const android = fln.AndroidInitializationSettings('@mipmap/ic_launcher');
    const darwin = fln.DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    await _plugin.initialize(
      settings: const fln.InitializationSettings(
        android: android,
        iOS: darwin,
      ),
    );
  }

  @override
  Future<bool> permissionGranted() async {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return (await _android?.areNotificationsEnabled()) ?? false;
    }
    return _lastRequestResult ?? true;
  }

  @override
  Future<bool> requestPermission() async {
    if (defaultTargetPlatform == TargetPlatform.android) {
      final granted = await _android?.requestNotificationsPermission();
      return granted ?? false;
    }
    final ios = _plugin
        .resolvePlatformSpecificImplementation<
          fln.IOSFlutterLocalNotificationsPlugin
        >();
    final result = await ios?.requestPermissions(
      alert: true,
      badge: false,
      sound: true,
    );
    _lastRequestResult = result ?? false;
    return _lastRequestResult!;
  }

  @override
  Future<void> schedule(ReminderNotification notification) async {
    await _plugin.zonedSchedule(
      id: notification.id,
      title: notification.title,
      body: notification.body,
      scheduledDate: tz.TZDateTime.from(
        notification.triggerAt,
        tz.getLocation('UTC'),
      ),
      notificationDetails: const fln.NotificationDetails(
        android: fln.AndroidNotificationDetails(
          'reminders',
          'Reminders',
          channelDescription: 'Task and event reminders',
          importance: fln.Importance.high,
          priority: fln.Priority.high,
        ),
      ),
      androidScheduleMode: fln.AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  @override
  Future<void> cancel(int id) async {
    await _plugin.cancel(id: id);
  }

  @override
  Future<Set<int>> pendingIds() async {
    final pending = await _plugin.pendingNotificationRequests();
    return pending.map((request) => request.id).toSet();
  }
}
