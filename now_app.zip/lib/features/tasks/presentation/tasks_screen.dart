import 'package:flutter/material.dart';
import 'package:now_app/core/widgets/empty_state.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Placeholder until Phase 2 (database and task management).
class TasksScreen extends StatelessWidget {
  const TasksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l10n.navTasks)),
      body: EmptyState(
        key: const ValueKey('tasks-placeholder'),
        icon: Icons.checklist_outlined,
        title: l10n.comingSoonTitle,
        message: l10n.comingSoonMessage,
      ),
    );
  }
}
