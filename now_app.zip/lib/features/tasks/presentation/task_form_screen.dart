import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/utils/form_error_text.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/core/widgets/choice_chips.dart';
import 'package:now_app/core/widgets/confirm_dialog.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/presentation/permission_flow.dart';
import 'package:now_app/features/reminders/presentation/reminder_chips.dart';
import 'package:now_app/features/tasks/application/task_actions.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/l10n/app_localizations.dart';
import 'package:now_app/shared/models/item_category.dart';
import 'package:now_app/shared/models/priority.dart';

class TaskFormScreen extends ConsumerStatefulWidget {
  const TaskFormScreen({super.key, this.taskId, this.initialDate});

  final String? taskId;
  final DateTime? initialDate;

  @override
  ConsumerState<TaskFormScreen> createState() => _TaskFormScreenState();
}

class _TaskFormScreenState extends ConsumerState<TaskFormScreen> {
  final _title = TextEditingController();
  final _description = TextEditingController();
  Priority _priority = Priority.medium;
  DateTime? _dueDate;
  int? _dueMinutes;
  ItemCategory? _category;
  int? _reminder;
  Task? _existing;
  int? _previousReminder;
  bool _loading = true;
  bool _saving = false;
  Set<FormError> _errors = {};

  @override
  void initState() {
    super.initState();
    _dueDate = widget.initialDate;
    _load();
  }

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final id = widget.taskId;
    if (id != null) {
      final task = await ref.read(taskRepositoryProvider).getById(id);
      final reminder = await ref
          .read(reminderRepositoryProvider)
          .getForOwner(ReminderOwnerType.task, id);
      if (!mounted) {
        return;
      }
      if (task != null) {
        _existing = task;
        _title.text = task.title;
        _description.text = task.description ?? '';
        _priority = task.priority;
        _dueDate = task.dueDate;
        _dueMinutes = task.dueMinutes;
        _category = task.category;
      }
      _previousReminder = reminder?.offsetMinutes;
      _reminder = reminder?.offsetMinutes;
    }
    if (mounted) {
      setState(() => _loading = false);
    }
  }

  Future<void> _pickDate() async {
    final today = dateOnly(ref.read(clockProvider)());
    final picked = await showDatePicker(
      context: context,
      initialDate: _dueDate ?? today,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null && mounted) {
      setState(() => _dueDate = dateOnly(picked));
    }
  }

  Future<void> _pickTime() async {
    final initial = _dueMinutes ?? defaultTaskReminderMinutes;
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: initial ~/ 60, minute: initial % 60),
    );
    if (picked != null && mounted) {
      setState(() => _dueMinutes = picked.hour * 60 + picked.minute);
    }
  }

  Future<void> _save() async {
    final messenger = ScaffoldMessenger.of(context);
    final l10n = AppLocalizations.of(context);
    final router = GoRouter.of(context);
    setState(() => _saving = true);
    final draft = TaskDraft(
      title: _title.text,
      description: _description.text,
      priority: _priority,
      dueDate: _dueDate,
      dueMinutes: _dueMinutes,
      category: _category,
      reminderOffset: _reminder,
    );
    final result = await ref
        .read(taskActionsProvider)
        .save(
          draft,
          existing: _existing,
          previousReminderOffset: _previousReminder,
        );
    if (!mounted) {
      return;
    }
    if (!result.ok) {
      setState(() {
        _errors = result.errors;
        _saving = false;
      });
      return;
    }
    if (_reminder != null) {
      await ensureNotificationPermission(ref, messenger, l10n);
    }
    router.pop();
  }

  Future<void> _delete() async {
    final l10n = AppLocalizations.of(context);
    final router = GoRouter.of(context);
    final id = _existing?.id;
    if (id == null) {
      return;
    }
    final confirmed = await confirmAction(
      context,
      title: l10n.deleteTaskTitle,
      message: l10n.deleteTaskBody,
      confirmLabel: l10n.actionDelete,
    );
    if (!confirmed) {
      return;
    }
    await ref.read(taskActionsProvider).delete(id);
    router.pop();
  }

  String? _errorFor(AppLocalizations l10n, Set<FormError> kinds) {
    for (final error in _errors) {
      if (kinds.contains(error)) {
        return formErrorText(l10n, error);
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final editing = widget.taskId != null;
    final date = _dueDate;
    final minutes = _dueMinutes;

    final dateError = _errorFor(l10n, {
      FormError.timeWithoutDate,
      FormError.reminderNeedsDate,
    });
    final reminderError = _errorFor(l10n, {FormError.reminderInPast});

    return Scaffold(
      appBar: AppBar(
        title: Text(editing ? l10n.taskEditTitle : l10n.taskNewTitle),
        actions: [
          if (editing && _existing != null)
            IconButton(
              key: const ValueKey('delete-button'),
              tooltip: l10n.actionDelete,
              icon: const Icon(Icons.delete_outline),
              onPressed: _delete,
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                TextField(
                  key: const ValueKey('title-field'),
                  controller: _title,
                  textCapitalization: TextCapitalization.sentences,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    labelText: l10n.fieldTitle,
                    errorText: _errorFor(l10n, {
                      FormError.titleRequired,
                      FormError.titleTooLong,
                    }),
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                TextField(
                  key: const ValueKey('description-field'),
                  controller: _description,
                  textCapitalization: TextCapitalization.sentences,
                  minLines: 2,
                  maxLines: 5,
                  decoration: InputDecoration(
                    labelText: l10n.fieldDescription,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                ListTile(
                  key: const ValueKey('due-date-tile'),
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.calendar_today_outlined),
                  title: Text(l10n.fieldDueDate),
                  subtitle: Text(
                    date == null ? l10n.noDate : formatDate(context, date),
                  ),
                  trailing: date == null
                      ? null
                      : IconButton(
                          tooltip: l10n.actionClear,
                          icon: const Icon(Icons.close),
                          onPressed: () => setState(() {
                            _dueDate = null;
                            _dueMinutes = null;
                          }),
                        ),
                  onTap: _pickDate,
                ),
                ListTile(
                  key: const ValueKey('due-time-tile'),
                  contentPadding: EdgeInsets.zero,
                  enabled: date != null,
                  leading: const Icon(Icons.schedule),
                  title: Text(l10n.fieldDueTime),
                  subtitle: Text(
                    minutes == null
                        ? l10n.noTime
                        : formatMinutes(context, minutes),
                  ),
                  trailing: minutes == null
                      ? null
                      : IconButton(
                          tooltip: l10n.actionClear,
                          icon: const Icon(Icons.close),
                          onPressed: () => setState(() => _dueMinutes = null),
                        ),
                  onTap: date == null ? null : _pickTime,
                ),
                if (dateError != null)
                  Text(
                    dateError,
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                const SizedBox(height: AppSpacing.md),
                Text(l10n.fieldPriority, style: theme.textTheme.titleSmall),
                const SizedBox(height: AppSpacing.sm),
                SegmentedButton<Priority>(
                  segments: [
                    for (final priority in Priority.values)
                      ButtonSegment(
                        value: priority,
                        label: Text(priorityLabel(l10n, priority)),
                      ),
                  ],
                  selected: {_priority},
                  onSelectionChanged: (selection) {
                    setState(() => _priority = selection.first);
                  },
                ),
                const SizedBox(height: AppSpacing.md),
                Text(l10n.fieldCategory, style: theme.textTheme.titleSmall),
                const SizedBox(height: AppSpacing.sm),
                ChoiceChips<ItemCategory?>(
                  groupKey: 'category',
                  value: _category,
                  options: [
                    (null, l10n.noCategory),
                    for (final category in ItemCategory.values)
                      (category, categoryLabel(l10n, category)),
                  ],
                  onSelected: (value) => setState(() => _category = value),
                ),
                const SizedBox(height: AppSpacing.md),
                Text(l10n.fieldReminder, style: theme.textTheme.titleSmall),
                const SizedBox(height: AppSpacing.sm),
                ReminderChips(
                  value: _reminder,
                  onChanged: (value) => setState(() => _reminder = value),
                ),
                if (reminderError != null)
                  Padding(
                    padding: const EdgeInsets.only(top: AppSpacing.sm),
                    child: Text(
                      reminderError,
                      style: TextStyle(color: theme.colorScheme.error),
                    ),
                  ),
                const SizedBox(height: AppSpacing.lg),
                FilledButton(
                  key: const ValueKey('save-button'),
                  onPressed: _saving ? null : _save,
                  child: Text(l10n.actionSave),
                ),
                ],
              ),
            ),
    );
  }
}
