import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/features/settings/domain/settings_repository.dart';

/// Must be overridden at startup (see bootstrap) and in tests.
final settingsRepositoryProvider = Provider<SettingsRepository>(
  (ref) => throw UnimplementedError('Override settingsRepositoryProvider.'),
);

final settingsControllerProvider =
    NotifierProvider<SettingsController, AppSettings>(SettingsController.new);

class SettingsController extends Notifier<AppSettings> {
  @override
  AppSettings build() => ref.read(settingsRepositoryProvider).load();

  Future<void> setLanguage(AppLanguage language) {
    return _update(state.copyWith(language: language));
  }

  Future<void> setTheme(AppThemeSetting theme) {
    return _update(state.copyWith(theme: theme));
  }

  Future<void> _update(AppSettings next) async {
    state = next;
    await ref.read(settingsRepositoryProvider).save(next);
  }
}
