import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/l10n/app_localizations.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(settingsControllerProvider);
    final controller = ref.read(settingsControllerProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.settingsTitle)),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.md),
        children: [
          _SectionHeader(l10n.settingsLanguage),
          _ChoiceCard<AppLanguage>(
            groupKey: 'language',
            value: settings.language,
            onSelected: controller.setLanguage,
            options: [
              (AppLanguage.system, l10n.languageSystem),
              (AppLanguage.arabic, l10n.languageArabic),
              (AppLanguage.english, l10n.languageEnglish),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          _SectionHeader(l10n.settingsAppearance),
          _ChoiceCard<AppThemeSetting>(
            groupKey: 'theme',
            value: settings.theme,
            onSelected: controller.setTheme,
            options: [
              (AppThemeSetting.system, l10n.themeSystem),
              (AppThemeSetting.light, l10n.themeLight),
              (AppThemeSetting.dark, l10n.themeDark),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: Semantics(
        header: true,
        child: Text(text, style: Theme.of(context).textTheme.titleMedium),
      ),
    );
  }
}

class _ChoiceCard<T> extends StatelessWidget {
  const _ChoiceCard({
    required this.groupKey,
    required this.value,
    required this.options,
    required this.onSelected,
  });

  final String groupKey;
  final T value;
  final List<(T, String)> options;
  final void Function(T) onSelected;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: [
          for (final (option, label) in options)
            ListTile(
              key: ValueKey('$groupKey-$option'),
              title: Text(label),
              selected: option == value,
              trailing: option == value ? const Icon(Icons.check) : null,
              onTap: () => onSelected(option),
            ),
        ],
      ),
    );
  }
}
