import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/features/settings/domain/settings_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Stores preferences in SharedPreferences. Unknown or missing stored values
/// fall back to defaults instead of throwing.
class SharedPreferencesSettingsRepository implements SettingsRepository {
  SharedPreferencesSettingsRepository(this._prefs);

  static const languageKey = 'settings.language';
  static const themeKey = 'settings.theme';

  final SharedPreferences _prefs;

  @override
  AppSettings load() {
    final storedLanguage = _prefs.getString(languageKey);
    final storedTheme = _prefs.getString(themeKey);
    final languages = AppLanguage.values.asNameMap();
    final themes = AppThemeSetting.values.asNameMap();
    return AppSettings(
      language: languages[storedLanguage] ?? AppLanguage.system,
      theme: themes[storedTheme] ?? AppThemeSetting.system,
    );
  }

  @override
  Future<void> save(AppSettings settings) async {
    await _prefs.setString(languageKey, settings.language.name);
    await _prefs.setString(themeKey, settings.theme.name);
  }
}
