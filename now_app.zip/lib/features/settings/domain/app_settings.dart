/// Interface language. `system` follows the device locale.
enum AppLanguage { system, arabic, english }

/// Appearance. `system` follows the device brightness.
enum AppThemeSetting { system, light, dark }

/// Device-level preferences. Pure Dart: no Flutter types on purpose.
class AppSettings {
  const AppSettings({
    this.language = AppLanguage.system,
    this.theme = AppThemeSetting.system,
  });

  final AppLanguage language;
  final AppThemeSetting theme;

  AppSettings copyWith({AppLanguage? language, AppThemeSetting? theme}) {
    return AppSettings(
      language: language ?? this.language,
      theme: theme ?? this.theme,
    );
  }
}
