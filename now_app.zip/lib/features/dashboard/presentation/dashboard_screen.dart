import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/widgets/empty_state.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Phase 1: header date and an honest empty state. No fake sample data.
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final now = ref.watch(clockProvider)();
    final locale = Localizations.localeOf(context).toString();
    final dateLabel = DateFormat.yMMMMEEEEd(locale).format(now);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.appName)),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.md,
              vertical: AppSpacing.sm,
            ),
            child: Text(
              dateLabel,
              key: const ValueKey('dashboard-date'),
              style: Theme.of(context).textTheme.headlineSmall,
            ),
          ),
          Expanded(
            child: EmptyState(
              key: const ValueKey('dashboard-empty'),
              icon: Icons.wb_sunny_outlined,
              title: l10n.dashboardEmptyTitle,
              message: l10n.dashboardEmptyBody,
            ),
          ),
        ],
      ),
    );
  }
}
