import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/add_sheet.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/app/routes.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/core/widgets/empty_state.dart';
import 'package:now_app/core/widgets/section_header.dart';
import 'package:now_app/features/scheduling/domain/day_plan.dart';
import 'package:now_app/features/scheduling/presentation/timeline_view.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/domain/task_rules.dart';
import 'package:now_app/features/tasks/presentation/widgets/task_tile.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Today at a glance, derived entirely from persisted data.
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final tasksAsync = ref.watch(tasksProvider);
    final eventsAsync = ref.watch(eventsProvider);
    final clock = ref.watch(clockProvider);
    final now = ref.watch(currentTimeProvider).value ?? clock();
    final today = dateOnly(now);

    Widget body;
    if (tasksAsync.hasError || eventsAsync.hasError) {
      body = Center(child: Text(l10n.errorGeneric));
    } else if (!tasksAsync.hasValue || !eventsAsync.hasValue) {
      body = const Center(child: CircularProgressIndicator());
    } else {
      final tasks = tasksAsync.requireValue;
      final events = eventsAsync.requireValue;
      final plan = buildDayPlan(date: today, tasks: tasks, events: events);
      final overdue = overdueTasks(tasks, today);
      body = _DashboardBody(
        today: today,
        now: now,
        plan: plan,
        overdue: overdue,
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(l10n.appName)),
      floatingActionButton: FloatingActionButton.extended(
        key: const ValueKey('dashboard-fab'),
        heroTag: null,
        onPressed: () => showAddSheet(context, date: today),
        icon: const Icon(Icons.add),
        label: Text(l10n.actionAdd),
      ),
      body: body,
    );
  }
}

class _DashboardBody extends StatelessWidget {
  const _DashboardBody({
    required this.today,
    required this.now,
    required this.plan,
    required this.overdue,
  });

  final DateTime today;
  final DateTime now;
  final DayPlan plan;
  final List<Task> overdue;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final overview = computeOverview(plan, now);

    final header = Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: Text(
        formatLongDate(context, today),
        key: const ValueKey('dashboard-date'),
        style: theme.textTheme.headlineSmall,
      ),
    );

    if (plan.isEmpty && overdue.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.md,
              AppSpacing.sm,
              AppSpacing.md,
              0,
            ),
            child: header,
          ),
          Expanded(
            child: EmptyState(
              key: const ValueKey('dashboard-empty'),
              icon: Icons.wb_sunny_outlined,
              title: l10n.dashboardEmptyTitle,
              message: l10n.dashboardEmptyBody,
              action: FilledButton.icon(
                onPressed: () => context.push(AppRoutes.newTask(date: today)),
                icon: const Icon(Icons.add),
                label: Text(l10n.addTask),
              ),
            ),
          ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md,
        AppSpacing.sm,
        AppSpacing.md,
        96,
      ),
      children: [
        header,
        _SummaryCard(plan: plan),
        if (overview.ongoingEvent != null || overview.nextEntry != null)
          _NextCard(overview: overview),
        if (plan.conflicts.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: AppSpacing.sm),
            child: Row(
              key: const ValueKey('dashboard-conflicts'),
              children: [
                Icon(Icons.warning_amber, color: theme.colorScheme.error),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    l10n.conflictsBanner(plan.conflicts.length),
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                ),
              ],
            ),
          ),
        if (plan.timeline.isNotEmpty) ...[
          SectionHeader(l10n.scheduleTitle),
          TimelineView(plan: plan),
        ],
        if (plan.anytimeTasks.isNotEmpty) ...[
          SectionHeader(l10n.anytimeTitle),
          Card(
            child: Column(
              children: [
                for (final task in plan.anytimeTasks) TaskTile(task: task),
              ],
            ),
          ),
        ],
        if (overdue.isNotEmpty) ...[
          SectionHeader(l10n.overdueTitle),
          Card(
            child: Column(
              children: [
                for (final task in overdue) TaskTile(task: task, showDate: true),
              ],
            ),
          ),
        ],
        const SizedBox(height: AppSpacing.md),
        OutlinedButton.icon(
          key: const ValueKey('dashboard-review'),
          onPressed: () => context.push(AppRoutes.review(today)),
          icon: const Icon(Icons.fact_check_outlined),
          label: Text(l10n.reviewDayAction),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.plan});

  final DayPlan plan;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final total = plan.tasksTotal;
    final done = plan.tasksDone;
    return Card(
      key: const ValueKey('dashboard-summary'),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(l10n.summaryTitle, style: theme.textTheme.titleMedium),
            const SizedBox(height: AppSpacing.xs),
            Text(
              total == 0
                  ? l10n.summaryNoTasks
                  : l10n.summaryProgress(done, total),
            ),
            if (total > 0) ...[
              const SizedBox(height: AppSpacing.sm),
              LinearProgressIndicator(value: done / total),
            ],
          ],
        ),
      ),
    );
  }
}

class _NextCard extends StatelessWidget {
  const _NextCard({required this.overview});

  final DayOverview overview;

  String _timeLabel(BuildContext context, TimelineEntry entry) {
    final l10n = AppLocalizations.of(context);
    final time = formatTimeOfDay(context, entry.start);
    return entry is EventEntry
        ? l10n.startsAtLabel(time)
        : l10n.dueAtLabel(time);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final ongoing = overview.ongoingEvent;
    final next = overview.nextEntry;
    return Card(
      key: const ValueKey('dashboard-next'),
      color: theme.colorScheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (ongoing != null) ...[
              Text(l10n.happeningNow, style: theme.textTheme.labelLarge),
              Text(ongoing.title, style: theme.textTheme.titleMedium),
            ],
            if (ongoing != null && next != null)
              const SizedBox(height: AppSpacing.sm),
            if (next != null) ...[
              Text(l10n.nextUpTitle, style: theme.textTheme.labelLarge),
              Text(next.title, style: theme.textTheme.titleMedium),
              Text(_timeLabel(context, next)),
            ],
          ],
        ),
      ),
    );
  }
}
