import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/add_sheet.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/app/routes.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/core/widgets/section_header.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/scheduling/domain/day_plan.dart';
import 'package:now_app/features/scheduling/presentation/timeline_view.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/presentation/widgets/task_tile.dart';
import 'package:now_app/l10n/app_localizations.dart';

enum CalendarMode { day, week }

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  CalendarMode _mode = CalendarMode.day;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final selected = ref.watch(selectedDateProvider);
    final tasksAsync = ref.watch(tasksProvider);
    final eventsAsync = ref.watch(eventsProvider);

    Widget body;
    if (tasksAsync.hasError || eventsAsync.hasError) {
      body = Center(child: Text(l10n.errorGeneric));
    } else if (!tasksAsync.hasValue || !eventsAsync.hasValue) {
      body = const Center(child: CircularProgressIndicator());
    } else {
      final tasks = tasksAsync.requireValue;
      final events = eventsAsync.requireValue;
      body = _mode == CalendarMode.day
          ? _DayView(date: selected, tasks: tasks, events: events)
          : _WeekView(
              selected: selected,
              tasks: tasks,
              events: events,
              onOpenDay: (date) {
                ref.read(selectedDateProvider.notifier).select(date);
                setState(() => _mode = CalendarMode.day);
              },
            );
    }

    return Scaffold(
      appBar: AppBar(title: Text(l10n.navCalendar)),
      floatingActionButton: FloatingActionButton.extended(
        key: const ValueKey('calendar-fab'),
        onPressed: () => showAddSheet(context, date: selected),
        icon: const Icon(Icons.add),
        label: Text(l10n.actionAdd),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: SegmentedButton<CalendarMode>(
              segments: [
                ButtonSegment(
                  value: CalendarMode.day,
                  label: Text(l10n.calendarDay),
                ),
                ButtonSegment(
                  value: CalendarMode.week,
                  label: Text(l10n.calendarWeek),
                ),
              ],
              selected: {_mode},
              onSelectionChanged: (selection) {
                setState(() => _mode = selection.first);
              },
            ),
          ),
          Expanded(child: body),
        ],
      ),
    );
  }
}

/// Previous/next navigation row shared by the day and week views.
class _NavRow extends ConsumerWidget {
  const _NavRow({
    required this.title,
    required this.onPrevious,
    required this.onNext,
    required this.onPickDate,
  });

  final String title;
  final VoidCallback onPrevious;
  final VoidCallback onNext;
  final VoidCallback onPickDate;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final rtl = Directionality.of(context) == TextDirection.rtl;
    return Row(
      children: [
        IconButton(
          key: const ValueKey('calendar-previous'),
          tooltip: l10n.navPrevious,
          icon: Icon(rtl ? Icons.chevron_right : Icons.chevron_left),
          onPressed: onPrevious,
        ),
        Expanded(
          child: TextButton(
            key: const ValueKey('calendar-title'),
            onPressed: onPickDate,
            child: Text(title, textAlign: TextAlign.center),
          ),
        ),
        IconButton(
          key: const ValueKey('calendar-next'),
          tooltip: l10n.navNext,
          icon: Icon(rtl ? Icons.chevron_left : Icons.chevron_right),
          onPressed: onNext,
        ),
        TextButton(
          key: const ValueKey('calendar-today'),
          onPressed: () {
            final today = dateOnly(ref.read(clockProvider)());
            ref.read(selectedDateProvider.notifier).select(today);
          },
          child: Text(l10n.calendarToday),
        ),
      ],
    );
  }
}

class _DayView extends ConsumerWidget {
  const _DayView({
    required this.date,
    required this.tasks,
    required this.events,
  });

  final DateTime date;
  final List<Task> tasks;
  final List<Event> events;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final plan = buildDayPlan(date: date, tasks: tasks, events: events);
    final notifier = ref.read(selectedDateProvider.notifier);

    Future<void> pick() async {
      final picked = await showDatePicker(
        context: context,
        initialDate: date,
        firstDate: DateTime(2020),
        lastDate: DateTime(2100),
      );
      if (picked != null) {
        notifier.select(picked);
      }
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md,
        0,
        AppSpacing.md,
        96,
      ),
      children: [
        _NavRow(
          title: formatDate(context, date),
          onPrevious: () => notifier.select(addDays(date, -1)),
          onNext: () => notifier.select(addDays(date, 1)),
          onPickDate: pick,
        ),
        if (plan.isEmpty)
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Center(
              child: Text(
                l10n.calendarEmptyDay,
                key: const ValueKey('calendar-empty-day'),
              ),
            ),
          ),
        if (plan.conflicts.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: AppSpacing.sm),
            child: Row(
              children: [
                Icon(Icons.warning_amber, color: theme.colorScheme.error),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    l10n.conflictsBanner(plan.conflicts.length),
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                ),
              ],
            ),
          ),
        if (plan.timeline.isNotEmpty) ...[
          SectionHeader(l10n.scheduleTitle),
          TimelineView(plan: plan),
        ],
        if (plan.anytimeTasks.isNotEmpty) ...[
          SectionHeader(l10n.anytimeTitle),
          Card(
            child: Column(
              children: [
                for (final task in plan.anytimeTasks) TaskTile(task: task),
              ],
            ),
          ),
        ],
        const SizedBox(height: AppSpacing.md),
        OutlinedButton.icon(
          key: const ValueKey('calendar-review'),
          onPressed: () => context.push(AppRoutes.review(date)),
          icon: const Icon(Icons.fact_check_outlined),
          label: Text(l10n.reviewDayAction),
        ),
      ],
    );
  }
}

class _WeekView extends ConsumerWidget {
  const _WeekView({
    required this.selected,
    required this.tasks,
    required this.events,
    required this.onOpenDay,
  });

  final DateTime selected;
  final List<Task> tasks;
  final List<Event> events;
  final void Function(DateTime) onOpenDay;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final firstIndex = MaterialLocalizations.of(context).firstDayOfWeekIndex;
    final start = startOfWeek(selected, weekdayFromFirstDayIndex(firstIndex));
    final days = [for (var i = 0; i < 7; i++) addDays(start, i)];
    final notifier = ref.read(selectedDateProvider.notifier);

    Future<void> pick() async {
      final picked = await showDatePicker(
        context: context,
        initialDate: selected,
        firstDate: DateTime(2020),
        lastDate: DateTime(2100),
      );
      if (picked != null) {
        notifier.select(picked);
      }
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md,
        0,
        AppSpacing.md,
        96,
      ),
      children: [
        _NavRow(
          title:
              '${formatShortDate(context, days.first)} – '
              '${formatShortDate(context, days.last)}',
          onPrevious: () => notifier.select(addDays(selected, -7)),
          onNext: () => notifier.select(addDays(selected, 7)),
          onPickDate: pick,
        ),
        for (final day in days)
          _WeekDayCard(
            day: day,
            plan: buildDayPlan(date: day, tasks: tasks, events: events),
            isSelected: isSameDay(day, selected),
            onTap: () => onOpenDay(day),
            l10n: l10n,
          ),
      ],
    );
  }
}

class _WeekDayCard extends StatelessWidget {
  const _WeekDayCard({
    required this.day,
    required this.plan,
    required this.isSelected,
    required this.onTap,
    required this.l10n,
  });

  final DateTime day;
  final DayPlan plan;
  final bool isSelected;
  final VoidCallback onTap;
  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      key: ValueKey('week-day-${dateKey(day)}'),
      color: isSelected ? theme.colorScheme.primaryContainer : null,
      child: ListTile(
        title: Text(formatShortDate(context, day)),
        subtitle: Text(
          l10n.weekSummary(plan.events.length, plan.tasksTotal),
        ),
        trailing: plan.conflicts.isEmpty
            ? null
            : Icon(
                Icons.warning_amber,
                color: theme.colorScheme.error,
                semanticLabel: l10n.overlapsLabel,
              ),
        onTap: onTap,
      ),
    );
  }
}
