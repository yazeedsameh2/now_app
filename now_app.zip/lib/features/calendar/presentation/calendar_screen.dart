import 'package:material_ui/material_ui.dart';
import 'package:now_app/core/widgets/empty_state.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Placeholder until Phase 3 (events, calendar, timeline).
class CalendarScreen extends StatelessWidget {
  const CalendarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l10n.navCalendar)),
      body: EmptyState(
        key: const ValueKey('calendar-placeholder'),
        icon: Icons.calendar_month_outlined,
        title: l10n.comingSoonTitle,
        message: l10n.comingSoonMessage,
      ),
    );
  }
}
