import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/utils/form_error_text.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/core/widgets/choice_chips.dart';
import 'package:now_app/core/widgets/confirm_dialog.dart';
import 'package:now_app/features/calendar/application/event_actions.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/presentation/permission_flow.dart';
import 'package:now_app/features/reminders/presentation/reminder_chips.dart';
import 'package:now_app/l10n/app_localizations.dart';
import 'package:now_app/shared/models/item_category.dart';

class EventFormScreen extends ConsumerStatefulWidget {
  const EventFormScreen({super.key, this.eventId, this.initialDate});

  final String? eventId;
  final DateTime? initialDate;

  @override
  ConsumerState<EventFormScreen> createState() => _EventFormScreenState();
}

class _EventFormScreenState extends ConsumerState<EventFormScreen> {
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _location = TextEditingController();
  late DateTime _date;
  int _startMinutes = 9 * 60;
  int _endMinutes = 10 * 60;
  ItemCategory? _category;
  int? _reminder;
  Event? _existing;
  int? _previousReminder;
  bool _loading = true;
  bool _saving = false;
  Set<FormError> _errors = {};

  @override
  void initState() {
    super.initState();
    _date = widget.initialDate ?? dateOnly(ref.read(clockProvider)());
    _load();
  }

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    _location.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final id = widget.eventId;
    if (id != null) {
      final event = await ref.read(eventRepositoryProvider).getById(id);
      final reminder = await ref
          .read(reminderRepositoryProvider)
          .getForOwner(ReminderOwnerType.event, id);
      if (!mounted) {
        return;
      }
      if (event != null) {
        _existing = event;
        _title.text = event.title;
        _description.text = event.description ?? '';
        _location.text = event.location ?? '';
        _date = dateOnly(event.startsAt);
        _startMinutes = event.startsAt.hour * 60 + event.startsAt.minute;
        _endMinutes = event.endsAt.hour * 60 + event.endsAt.minute;
        _category = event.category;
      }
      _previousReminder = reminder?.offsetMinutes;
      _reminder = reminder?.offsetMinutes;
    }
    if (mounted) {
      setState(() => _loading = false);
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null && mounted) {
      setState(() => _date = dateOnly(picked));
    }
  }

  Future<void> _pickTime({required bool start}) async {
    final initial = start ? _startMinutes : _endMinutes;
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: initial ~/ 60, minute: initial % 60),
    );
    if (picked == null || !mounted) {
      return;
    }
    final value = picked.hour * 60 + picked.minute;
    setState(() {
      if (start) {
        _startMinutes = value;
      } else {
        _endMinutes = value;
      }
    });
  }

  EventDraft _draft() {
    return EventDraft(
      title: _title.text,
      description: _description.text,
      date: _date,
      startMinutes: _startMinutes,
      endMinutes: _endMinutes,
      location: _location.text,
      category: _category,
      reminderOffset: _reminder,
    );
  }

  Future<void> _save() async {
    final messenger = ScaffoldMessenger.of(context);
    final l10n = AppLocalizations.of(context);
    final router = GoRouter.of(context);
    setState(() => _saving = true);
    final result = await ref
        .read(eventActionsProvider)
        .save(
          _draft(),
          existing: _existing,
          previousReminderOffset: _previousReminder,
        );
    if (!mounted) {
      return;
    }
    if (!result.ok) {
      setState(() {
        _errors = result.errors;
        _saving = false;
      });
      return;
    }
    if (_reminder != null) {
      await ensureNotificationPermission(ref, messenger, l10n);
    }
    router.pop();
  }

  Future<void> _delete() async {
    final l10n = AppLocalizations.of(context);
    final router = GoRouter.of(context);
    final id = _existing?.id;
    if (id == null) {
      return;
    }
    final confirmed = await confirmAction(
      context,
      title: l10n.deleteEventTitle,
      message: l10n.deleteEventBody,
      confirmLabel: l10n.actionDelete,
    );
    if (!confirmed) {
      return;
    }
    await ref.read(eventActionsProvider).delete(id);
    router.pop();
  }

  String? _errorFor(AppLocalizations l10n, Set<FormError> kinds) {
    for (final error in _errors) {
      if (kinds.contains(error)) {
        return formErrorText(l10n, error);
      }
    }
    return null;
  }

  /// Titles of other events that overlap the time currently entered.
  List<String> _overlappingTitles() {
    final draft = _draft();
    if (!draft.endsAt.isAfter(draft.startsAt)) {
      return const [];
    }
    final events = ref.watch(eventsProvider).value ?? const <Event>[];
    return [
      for (final other in events)
        if (other.id != _existing?.id &&
            other.startsAt.isBefore(draft.endsAt) &&
            draft.startsAt.isBefore(other.endsAt))
          other.title,
    ];
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final editing = widget.eventId != null;
    final overlaps = _loading ? const <String>[] : _overlappingTitles();
    final timeError = _errorFor(l10n, {FormError.endNotAfterStart});
    final reminderError = _errorFor(l10n, {FormError.reminderInPast});

    return Scaffold(
      appBar: AppBar(
        title: Text(editing ? l10n.eventEditTitle : l10n.eventNewTitle),
        actions: [
          if (editing && _existing != null)
            IconButton(
              key: const ValueKey('delete-button'),
              tooltip: l10n.actionDelete,
              icon: const Icon(Icons.delete_outline),
              onPressed: _delete,
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                TextField(
                  key: const ValueKey('title-field'),
                  controller: _title,
                  textCapitalization: TextCapitalization.sentences,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    labelText: l10n.fieldTitle,
                    errorText: _errorFor(l10n, {
                      FormError.titleRequired,
                      FormError.titleTooLong,
                    }),
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                TextField(
                  key: const ValueKey('location-field'),
                  controller: _location,
                  decoration: InputDecoration(labelText: l10n.fieldLocation),
                ),
                const SizedBox(height: AppSpacing.md),
                TextField(
                  key: const ValueKey('description-field'),
                  controller: _description,
                  textCapitalization: TextCapitalization.sentences,
                  minLines: 2,
                  maxLines: 5,
                  decoration: InputDecoration(
                    labelText: l10n.fieldDescription,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                ListTile(
                  key: const ValueKey('event-date-tile'),
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.calendar_today_outlined),
                  title: Text(l10n.fieldDate),
                  subtitle: Text(formatDate(context, _date)),
                  onTap: _pickDate,
                ),
                ListTile(
                  key: const ValueKey('event-start-tile'),
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.schedule),
                  title: Text(l10n.fieldStart),
                  subtitle: Text(formatMinutes(context, _startMinutes)),
                  onTap: () => _pickTime(start: true),
                ),
                ListTile(
                  key: const ValueKey('event-end-tile'),
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.schedule),
                  title: Text(l10n.fieldEnd),
                  subtitle: Text(formatMinutes(context, _endMinutes)),
                  onTap: () => _pickTime(start: false),
                ),
                if (timeError != null)
                  Text(
                    timeError,
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                if (overlaps.isNotEmpty)
                  Card(
                    key: const ValueKey('overlap-warning'),
                    color: theme.colorScheme.errorContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.md),
                      child: Row(
                        children: [
                          Icon(
                            Icons.warning_amber,
                            color: theme.colorScheme.onErrorContainer,
                          ),
                          const SizedBox(width: AppSpacing.sm),
                          Expanded(
                            child: Text(
                              l10n.eventOverlapWarning(overlaps.join(', ')),
                              style: TextStyle(
                                color: theme.colorScheme.onErrorContainer,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: AppSpacing.md),
                Text(l10n.fieldCategory, style: theme.textTheme.titleSmall),
                const SizedBox(height: AppSpacing.sm),
                ChoiceChips<ItemCategory?>(
                  groupKey: 'category',
                  value: _category,
                  options: [
                    (null, l10n.noCategory),
                    for (final category in ItemCategory.values)
                      (category, categoryLabel(l10n, category)),
                  ],
                  onSelected: (value) => setState(() => _category = value),
                ),
                const SizedBox(height: AppSpacing.md),
                Text(l10n.fieldReminder, style: theme.textTheme.titleSmall),
                const SizedBox(height: AppSpacing.sm),
                ReminderChips(
                  value: _reminder,
                  onChanged: (value) => setState(() => _reminder = value),
                ),
                if (reminderError != null)
                  Padding(
                    padding: const EdgeInsets.only(top: AppSpacing.sm),
                    child: Text(
                      reminderError,
                      style: TextStyle(color: theme.colorScheme.error),
                    ),
                  ),
                const SizedBox(height: AppSpacing.lg),
                FilledButton(
                  key: const ValueKey('save-button'),
                  onPressed: _saving ? null : _save,
                  child: Text(l10n.actionSave),
                ),
                ],
              ),
            ),
    );
  }
}
