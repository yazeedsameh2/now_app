import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/app/app.dart';

void main() {
  testWidgets('app shell renders the NOW wordmark', (tester) async {
    await tester.pumpWidget(const NowApp());

    expect(find.text('NOW'), findsOneWidget);
  });
}
