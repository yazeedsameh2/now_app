import 'package:flutter/material.dart';

/// Phase 0 placeholder shell.
///
/// Theme tokens, localization (Arabic/English) and routing are Phase 1 and are
/// intentionally not stubbed here.
class NowApp extends StatelessWidget {
  const NowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NOW',
      theme: ThemeData(colorSchemeSeed: Colors.indigo),
      home: const Scaffold(body: Center(child: Text('NOW'))),
    );
  }
}
