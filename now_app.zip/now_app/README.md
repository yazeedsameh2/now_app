# NOW — يومك بوضوح

Bilingual (Arabic/English), local-first daily planner built with Flutter.
Source of truth: `docs/NOW_PRODUCT_SPEC.md` and `docs/NOW_TECHNICAL_ARCHITECTURE.md`.

## Status
Phase 0 (bootstrap) files written. **Nothing here has been executed yet** —
the first CI run is the first real verification. See "Known limitations".

## Setup (free tools only)
1. Install the Flutter SDK (stable): https://docs.flutter.dev/get-started/install
2. `flutter doctor`
3. `flutter create --platforms=android,ios --project-name now_app --org <your.org> .`
   only if `android/` / `ios/` are missing (CI generates them temporarily).

## Commands
```
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter run
```

## CI (GitHub Actions)
`.github/workflows/ci.yml`:
- `verify`: format check, analyze, test (every push/PR)
- `android-debug-apk`: builds a debug APK, uploaded as an artifact
- `ios-compile-check`: manual run only; unsigned compile check, no installable IPA

## Dependency versions
Phase 0 uses only the Flutter SDK and `flutter_lints ^5.0.0`; the Dart SDK
constraint is `>=3.5.0 <4.0.0`. None of this was resolved locally. After the
first green CI run, commit the generated `pubspec.lock`.

## Known limitations
- `android/` and `ios/` are not committed yet; CI generates them on the fly.
  They must be committed before Phase 5 (notification manifest/permissions).
- Application ID prefix `com.example.now` is a placeholder (proposal, needs owner decision).
- iOS: an unsigned compile does not mean the app can be installed on an iPhone.
