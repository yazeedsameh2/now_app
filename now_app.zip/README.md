# NOW — يومك بوضوح

Bilingual (Arabic/English), local-first daily planner built with Flutter.
Source of truth: `docs/NOW_PRODUCT_SPEC.md` and
`docs/NOW_TECHNICAL_ARCHITECTURE.md`.

## Status
- Phase 0 (bootstrap): built and installed on an Android phone (owner screenshot).
- Phase 1 (design system, localization, navigation, empty dashboard): code
  written, **not yet verified**. The first CI run is the first verification.

## Setup (free tools only)
1. Install the Flutter SDK (stable): https://docs.flutter.dev/get-started/install
2. `flutter doctor`
3. `flutter pub get` then `flutter gen-l10n`

## Commands
```
flutter pub get
flutter gen-l10n          # generates lib/l10n/app_localizations*.dart (git-ignored)
dart format lib test
flutter analyze
flutter test
flutter run
```

## CI (GitHub Actions) — `.github/workflows/build.yml`
- `verify`: gen-l10n, format check (non-blocking for now), analyze, test.
  Uploads `pubspec.lock` and `formatting.patch` as artifacts.
- `android`: debug APK artifact (needs `verify`).
- `ios`: unsigned compile check only. **Not installable on an iPhone.**

## Dependencies (resolved by CI, not locally)
`flutter_riverpod ^3.4.1`, `go_router ^18.1.1`, `shared_preferences ^2.5.3`,
`intl` (any: pinned by `flutter_localizations`), `flutter_lints ^5.0.0`.
Dart SDK `>=3.8.0 <4.0.0`. Commit `pubspec.lock` after the first green run.

## Project layout
`lib/app` (bootstrap, router, shell) · `lib/core` (theme tokens, shared
widgets, utils) · `lib/features/<feature>/{domain,data,application,presentation}`
· `lib/l10n` (ARB sources) · `test/{unit,widget,support}`.

## Known limitations / proposals
- `android/` and `ios/` are not committed; CI generates them temporarily.
  Commit them before Phase 5 (notification permissions/manifest).
- App id prefix `com.example.now` is a placeholder (owner decision needed).
- Palette (indigo seed), system fonts and Arabic wording are design proposals
  pending owner review.
- Card/input/dialog component themes are deferred to Phase 2, when forms exist.
- Onboarding (spec §5.1) is not assigned to any phase in the architecture doc;
  proposed as a small step before Phase 4.
