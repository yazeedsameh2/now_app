import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';

import '../support/test_app.dart';

void main() {
  setUpAll(() async {
    await initializeDateFormatting();
  });

  group('English (LTR)', () {
    testWidgets('shows the empty dashboard and localized navigation', (
      tester,
    ) async {
      await pumpNowApp(tester);

      expect(directionOf(tester), TextDirection.ltr);
      expect(find.byKey(const ValueKey('dashboard-empty')), findsOneWidget);
      expect(find.text('Nothing planned for today'), findsOneWidget);
      expect(find.text('Wednesday, November 25, 2026'), findsOneWidget);
      for (final label in ['Home', 'Tasks', 'Calendar', 'Settings']) {
        expect(navLabel(label), findsOneWidget);
      }
    });

    testWidgets('navigates between all four tabs', (tester) async {
      await pumpNowApp(tester);

      await tester.tap(navLabel('Tasks'));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('tasks-placeholder')), findsOneWidget);

      await tester.tap(navLabel('Calendar'));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('calendar-placeholder')),
        findsOneWidget,
      );

      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('language-AppLanguage.arabic')),
        findsOneWidget,
      );

      await tester.tap(navLabel('Home'));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('dashboard-empty')), findsOneWidget);
    });
  });

  group('Arabic (RTL)', () {
    testWidgets('mirrors the layout and shows Arabic strings', (tester) async {
      await pumpNowApp(tester, language: AppLanguage.arabic);

      expect(directionOf(tester), TextDirection.rtl);
      expect(find.text('لا يوجد شيء مخطط لليوم'), findsOneWidget);
      for (final label in ['الرئيسية', 'المهام', 'التقويم', 'الإعدادات']) {
        expect(navLabel(label), findsOneWidget);
      }
    });
  });

  group('Settings', () {
    testWidgets('switching language to Arabic flips to RTL and persists', (
      tester,
    ) async {
      final repository = await pumpNowApp(tester);

      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('language-AppLanguage.arabic')),
      );
      await tester.pumpAndSettle();

      expect(directionOf(tester), TextDirection.rtl);
      expect(repository.settings.language, AppLanguage.arabic);
      expect(repository.saveCount, 1);
    });

    testWidgets('switching theme to dark changes brightness and persists', (
      tester,
    ) async {
      final repository = await pumpNowApp(tester);
      expect(brightnessOf(tester), Brightness.light);

      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('theme-AppThemeSetting.dark')),
      );
      await tester.pumpAndSettle();

      expect(brightnessOf(tester), Brightness.dark);
      expect(repository.settings.theme, AppThemeSetting.dark);
    });
  });

  group('Small screen (320x568)', () {
    for (final language in [AppLanguage.english, AppLanguage.arabic]) {
      for (final theme in [AppThemeSetting.light, AppThemeSetting.dark]) {
        testWidgets('no overflow: ${language.name}, ${theme.name}', (
          tester,
        ) async {
          await pumpNowApp(
            tester,
            language: language,
            theme: theme,
            size: const Size(320, 568),
          );

          for (var index = 0; index < 4; index++) {
            await tester.tap(find.byType(NavigationDestination).at(index));
            await tester.pumpAndSettle();
            expect(tester.takeException(), isNull);
          }
        });
      }
    }
  });
}
