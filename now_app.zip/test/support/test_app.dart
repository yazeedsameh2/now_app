import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/app.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/database/unit_of_work.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/l10n/app_localizations.dart';

import 'fakes.dart';
import 'test_data.dart';

/// Everything a widget test may want to inspect after interacting.
class Harness {
  Harness({
    required this.settings,
    required this.tasks,
    required this.events,
    required this.reminders,
    required this.notifications,
  });

  final FakeSettingsRepository settings;
  final InMemoryTaskRepository tasks;
  final InMemoryEventRepository events;
  final InMemoryReminderRepository reminders;
  final FakeNotificationService notifications;

  List<Override> overrides() {
    return [
      settingsRepositoryProvider.overrideWithValue(settings),
      clockProvider.overrideWithValue(() => testNow),
      currentTimeProvider.overrideWith((ref) => Stream.value(testNow)),
      taskRepositoryProvider.overrideWithValue(tasks),
      eventRepositoryProvider.overrideWithValue(events),
      reminderRepositoryProvider.overrideWithValue(reminders),
      unitOfWorkProvider.overrideWithValue(PassthroughUnitOfWork()),
      notificationServiceProvider.overrideWithValue(notifications),
      reminderTextsProvider.overrideWithValue(FakeReminderTexts()),
    ];
  }
}

Harness makeHarness({
  AppLanguage language = AppLanguage.english,
  AppThemeSetting theme = AppThemeSetting.light,
  bool onboardingDone = true,
  List<Task> tasks = const [],
  List<Event> events = const [],
  bool notificationsGranted = true,
}) {
  return Harness(
    settings: FakeSettingsRepository(
      AppSettings(
        language: language,
        theme: theme,
        onboardingDone: onboardingDone,
      ),
    ),
    tasks: InMemoryTaskRepository(tasks),
    events: InMemoryEventRepository(events),
    reminders: InMemoryReminderRepository(),
    notifications: FakeNotificationService(granted: notificationsGranted),
  );
}

void setScreenSize(WidgetTester tester, Size size) {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.reset);
}

Future<Harness> pumpNowApp(
  WidgetTester tester, {
  AppLanguage language = AppLanguage.english,
  AppThemeSetting theme = AppThemeSetting.light,
  bool onboardingDone = true,
  List<Task> tasks = const [],
  List<Event> events = const [],
  Size size = const Size(360, 740),
}) async {
  setScreenSize(tester, size);
  final harness = makeHarness(
    language: language,
    theme: theme,
    onboardingDone: onboardingDone,
    tasks: tasks,
    events: events,
  );
  await tester.pumpWidget(
    ProviderScope(overrides: harness.overrides(), child: const NowApp()),
  );
  await tester.pumpAndSettle();
  return harness;
}

/// Pumps a single screen (no router) with localization and fakes.
Future<Harness> pumpScreen(
  WidgetTester tester,
  Widget screen, {
  List<Task> tasks = const [],
  List<Event> events = const [],
}) async {
  setScreenSize(tester, const Size(400, 1600));
  final harness = makeHarness(tasks: tasks, events: events);
  await tester.pumpWidget(
    ProviderScope(
      overrides: harness.overrides(),
      child: MaterialApp(
        localizationsDelegates: const [
          AppLocalizations.delegate,
          ...GlobalMaterialLocalizations.delegates,
        ],
        supportedLocales: AppLocalizations.supportedLocales,
        locale: const Locale('en'),
        home: screen,
      ),
    ),
  );
  await tester.pumpAndSettle();
  return harness;
}

TextDirection directionOf(WidgetTester tester) {
  return Directionality.of(tester.element(find.byType(NavigationBar)));
}

Brightness brightnessOf(WidgetTester tester) {
  return Theme.of(tester.element(find.byType(NavigationBar))).brightness;
}

Finder navLabel(String text) {
  return find.descendant(
    of: find.byType(NavigationBar),
    matching: find.text(text),
  );
}

/// Taps a widget that may be below the fold in a scrolling list.
Future<void> tapScrolled(WidgetTester tester, Finder finder) async {
  await tester.ensureVisible(finder);
  await tester.pumpAndSettle();
  await tester.tap(finder);
  await tester.pumpAndSettle();
}

/// The GoRouter of the running app (for assertions on navigation).
GoRouter routerOf(WidgetTester tester) {
  return GoRouter.of(tester.element(find.byType(NavigationBar)));
}
