import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/app/app.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/features/settings/domain/settings_repository.dart';

/// In-memory repository so widget tests never touch the platform.
class FakeSettingsRepository implements SettingsRepository {
  FakeSettingsRepository([this.settings = const AppSettings()]);

  AppSettings settings;
  int saveCount = 0;

  @override
  AppSettings load() => settings;

  @override
  Future<void> save(AppSettings next) async {
    settings = next;
    saveCount++;
  }
}

/// Fixed "today" used by all widget tests: Wednesday, 25 November 2026.
final testNow = DateTime(2026, 11, 25, 9);

Future<FakeSettingsRepository> pumpNowApp(
  WidgetTester tester, {
  AppLanguage language = AppLanguage.english,
  AppThemeSetting theme = AppThemeSetting.light,
  Size size = const Size(360, 740),
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.reset);

  final repository = FakeSettingsRepository(
    AppSettings(language: language, theme: theme),
  );
  await tester.pumpWidget(
    ProviderScope(
      overrides: [
        settingsRepositoryProvider.overrideWithValue(repository),
        clockProvider.overrideWithValue(() => testNow),
      ],
      child: const NowApp(),
    ),
  );
  await tester.pumpAndSettle();
  return repository;
}

/// Reading direction as seen by the navigation bar.
TextDirection directionOf(WidgetTester tester) {
  return Directionality.of(tester.element(find.byType(NavigationBar)));
}

Brightness brightnessOf(WidgetTester tester) {
  return Theme.of(tester.element(find.byType(NavigationBar))).brightness;
}

Finder navLabel(String text) {
  return find.descendant(
    of: find.byType(NavigationBar),
    matching: find.text(text),
  );
}
