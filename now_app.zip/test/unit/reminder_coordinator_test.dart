import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';

import '../support/services.dart';
import '../support/test_data.dart';

void main() {
  Future<Services> servicesWithTaskReminder({
    bool granted = true,
    bool enabled = true,
  }) async {
    final s = Services(notificationsGranted: granted, remindersEnabled: enabled);
    await s.tasks.upsert(
      makeTask('t', 'Report', dueDate: testToday, dueMinutes: 14 * 60),
    );
    await s.reminders.save(
      type: ReminderOwnerType.task,
      ownerId: 't',
      offsetMinutes: 30,
      now: testNow,
    );
    return s;
  }

  test('reconcile schedules every wanted notification once', () async {
    final s = await servicesWithTaskReminder();

    await s.coordinator.reconcile();
    await s.coordinator.reconcile();

    expect(s.notifications.scheduled, hasLength(1));
    expect(s.notifications.scheduled.values.single.body, startsWith('body-'));
  });

  test('stale pending notifications are cancelled', () async {
    final s = await servicesWithTaskReminder();
    await s.notifications.schedule(
      ReminderNotification(
        id: 999,
        title: 'ghost',
        body: 'ghost',
        triggerAt: at(20),
      ),
    );

    await s.coordinator.reconcile();

    expect(s.notifications.scheduled.keys, isNot(contains(999)));
    expect(s.notifications.cancelled, contains(999));
    expect(s.notifications.scheduled, hasLength(1));
  });

  test('deleting the owner behind a reminder cancels it', () async {
    final s = await servicesWithTaskReminder();
    await s.coordinator.reconcile();
    expect(s.notifications.scheduled, hasLength(1));

    await s.tasks.delete('t');
    await s.coordinator.reconcile();

    expect(s.notifications.scheduled, isEmpty);
  });

  test('turning reminders off cancels everything', () async {
    final s = await servicesWithTaskReminder();
    await s.coordinator.reconcile();

    s.enabled = false;
    await s.coordinator.reconcile();

    expect(s.notifications.scheduled, isEmpty);
  });

  test('without permission nothing is scheduled', () async {
    final s = await servicesWithTaskReminder(granted: false);

    await s.coordinator.reconcile();

    expect(s.notifications.scheduled, isEmpty);
    expect(s.notifications.scheduleCalls, 0);
  });

  test('granting permission later schedules on the next reconcile', () async {
    final s = await servicesWithTaskReminder(granted: false);
    await s.coordinator.reconcile();

    s.notifications.granted = true;
    await s.coordinator.reconcile();

    expect(s.notifications.scheduled, hasLength(1));
  });

  test('concurrent reconciles are serialized and stay consistent', () async {
    final s = await servicesWithTaskReminder();

    await Future.wait([
      s.coordinator.reconcile(),
      s.coordinator.reconcile(),
      s.coordinator.reconcile(),
    ]);

    expect(s.notifications.scheduled, hasLength(1));
  });

  test('time passing removes reminders whose moment has gone', () async {
    final s = await servicesWithTaskReminder();
    await s.coordinator.reconcile();
    expect(s.notifications.scheduled, hasLength(1));

    s.clockValue = at(14);
    await s.coordinator.reconcile();

    expect(s.notifications.scheduled, isEmpty);
  });
}
