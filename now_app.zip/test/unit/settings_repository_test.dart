import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/features/settings/data/shared_preferences_settings_repository.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<SharedPreferencesSettingsRepository> repositoryWith(
  Map<String, Object> initial,
) async {
  SharedPreferences.setMockInitialValues(initial);
  final prefs = await SharedPreferences.getInstance();
  return SharedPreferencesSettingsRepository(prefs);
}

void main() {
  test('returns defaults when nothing is stored', () async {
    final repository = await repositoryWith({});

    final settings = repository.load();

    expect(settings.language, AppLanguage.system);
    expect(settings.theme, AppThemeSetting.system);
  });

  test('saved settings are loaded back', () async {
    final repository = await repositoryWith({});

    await repository.save(
      const AppSettings(
        language: AppLanguage.arabic,
        theme: AppThemeSetting.dark,
      ),
    );
    final settings = repository.load();

    expect(settings.language, AppLanguage.arabic);
    expect(settings.theme, AppThemeSetting.dark);
  });

  test('unknown stored values fall back to defaults', () async {
    final repository = await repositoryWith({
      SharedPreferencesSettingsRepository.languageKey: 'klingon',
      SharedPreferencesSettingsRepository.themeKey: '42',
    });

    final settings = repository.load();

    expect(settings.language, AppLanguage.system);
    expect(settings.theme, AppThemeSetting.system);
  });
}
