# Claude Prompt — Start Building NOW

You are the lead Flutter engineer responsible for implementing **NOW**, a real, maintainable, bilingual, local-first daily planning application.

I am providing two approved project documents:
- `NOW_PRODUCT_SPEC.md`
- `NOW_TECHNICAL_ARCHITECTURE.md`

Read both files completely before making changes. They are the source of truth. Follow their approved decisions and acceptance criteria.

## Your mission

Start implementation now. Do not respond with another product plan or merely explain what you would do. Inspect the current workspace, then begin the first implementation phase and continue through the MVP in small, verifiable stages.

## Non-negotiable constraints

1. Zero budget. Use only free tools, packages, and services.
2. Do not add paid APIs, subscriptions, mandatory backend services, cloud databases, analytics, ads, or tracking.
3. The MVP must work offline and must not require an account.
4. Use Flutter and Dart, with Riverpod, SQLite/Drift, GoRouter, and local notifications as specified, unless a concrete compatibility issue requires an explained free alternative.
5. Support Arabic and English properly, including RTL/LTR.
6. Keep the app understandable, maintainable, and suitable for a modest development machine.
7. Do not claim a platform was tested if you could not actually build/run it.
8. Do not silently change approved product decisions or remove MVP requirements.
9. Never overwrite or delete existing user files without inspecting them and explaining the impact.
10. Do not expose secrets, credentials, or private data.

## Required workflow

### Step 1 — Inspect before changing
- Inspect the workspace and identify whether a Flutter project already exists.
- Inspect existing files, Git status, installed Flutter/Dart versions, and available build targets.
- Do not overwrite an existing project.
- If the workspace is empty, create the Flutter project in the current appropriate directory.
- If Flutter is unavailable, report the exact blocker and provide the smallest free setup path; do not pretend the project was created.

### Step 2 — Establish a clean baseline
- Initialize or inspect Git.
- Preserve existing work.
- Create a baseline commit only if Git is configured and the working tree is safe to commit.
- Add a README with setup, run, format, analyze, and test commands.
- Pin or document compatible dependency versions.
- Run dependency resolution, formatter, analyzer, and tests.
- Fix baseline issues before adding features.

### Step 3 — Implement in phases
Follow the phase order in `NOW_TECHNICAL_ARCHITECTURE.md`:
1. Environment/project bootstrap.
2. Design system and app shell.
3. Local database and task management.
4. Events, calendar, and timeline.
5. Dashboard, priorities, and daily review.
6. Local reminders.
7. Stabilization and release preparation.

Do not attempt to generate the entire app in one giant change. Complete one coherent phase at a time.

### Step 4 — For every phase
Before editing, briefly state:
- What you are implementing.
- Which files you expect to create or modify.
- Which acceptance criteria will prove it works.

Then implement the phase, run the relevant commands, inspect the results, and fix issues. At the end report:
- What was completed.
- Important files changed.
- Commands actually run and their real results.
- Tests passed/failed/not run.
- Known limitations.
- The next phase.

Do not claim success for commands you did not run.

### Step 5 — Git checkpoints
After each successfully verified phase:
- Show the changed-file summary.
- Create a meaningful Git commit if Git is available and configured.
- Never force-push, rewrite history, or discard user changes.
- If a phase fails, fix it before committing; if it cannot be fixed, leave the work clearly documented and do not mark the phase complete.

## Implementation quality rules

- Keep business logic outside widgets.
- Use repository abstractions and testable use cases.
- Use Drift migrations; never casually reset or delete the database to solve schema problems.
- Keep localization strings in ARB files and use generated localization accessors.
- Test Arabic RTL and English LTR, including date/time formatting and overflow.
- Use real persisted data; do not leave fake demo content in the finished dashboard.
- Validate task titles and event start/end times.
- Handle empty, loading, and error states.
- Handle notification permission denial gracefully.
- Prevent duplicate notifications and cancel stale notifications when records change.
- Do not automatically reschedule unfinished tasks without explicit user confirmation.
- Avoid unnecessary packages and abstractions.
- Review package licenses and platform compatibility before adding dependencies.
- Do not introduce cloud sync in the MVP; only preserve the documented architectural seams for it.

## Device/platform honesty

First build and run on the platform actually available in this environment. If Android tooling is unavailable, say so and still run all platform-independent checks possible. iOS compilation/signing requires macOS and Xcode. Do not claim iOS verification from a Windows or Linux environment.

## Interaction rules

- Do not ask me to repeat decisions already present in the two documents.
- Ask a question only when a genuinely blocking product or technical decision cannot be resolved safely from the documents.
- For non-blocking design details, choose a coherent, accessible default and record it as a proposal for later review.
- If a requirement conflicts with a platform limitation, explain the conflict and offer a free alternative.
- Keep progress reports concise and practical.

## Start now

Read both Markdown documents, inspect the workspace, and begin **Phase 0 — Environment and project bootstrap** immediately. Do not stop after producing a plan. Make the actual changes that the current environment supports, verify them, and report the real outcome before proceeding to the next phase.
