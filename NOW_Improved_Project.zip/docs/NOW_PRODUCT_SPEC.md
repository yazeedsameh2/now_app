# NOW — Product Specification
**Version:** 1.0  
**Status:** Approved baseline for MVP implementation  
**Product name:** NOW  
**Tagline:** يومك بوضوح

---

## 1. Product vision

NOW is a modern, bilingual, local-first personal day-planning application. It helps people understand their day, decide what deserves attention now, and adapt their plans when the day changes.

NOW is more than a conventional to-do list. Its central experience connects tasks, events, priorities, a daily timeline, reminders, and a short daily review.

### Core questions NOW should answer
1. What do I have today?
2. What should I focus on now?
3. Is my day on track, and what should I adjust?

## 2. Approved product decisions

These decisions are approved and must not be silently changed:

| Area | Decision |
|---|---|
| Visual identity | Modern — contemporary, energetic, clear |
| Languages | Arabic and English |
| Audience | All age groups |
| Initial data model | Local-first |
| Account requirement | No account required for MVP |
| Initial storage | On-device database |
| Future growth | Architecture should allow optional cloud sync later |
| Budget | Zero-cost tools and services only |
| Ads and tracking | No ads; no unnecessary analytics or tracking |

Arabic must be a complete interface language with correct RTL layout. English must use LTR. Do not implement Arabic as a superficial text translation only.

## 3. Audience and use cases

NOW is intended for people of different ages and routines, including:
- School and university students planning study sessions, assignments, and classes.
- Employees planning work, meetings, and deadlines.
- People organizing personal errands, appointments, and everyday responsibilities.

The interface should be approachable for first-time users while remaining useful for people with many tasks and events.

## 4. Product principles

1. **Clarity first:** users should understand the current day quickly.
2. **Low friction:** creating and completing a task should be straightforward.
3. **User control:** suggestions never silently rewrite the user's plan.
4. **Offline by default:** core functionality must work without internet access.
5. **Privacy by design:** personal schedule data stays on-device in the MVP.
6. **Honest intelligence:** rule-based scheduling must not be marketed as generative AI.
7. **Accessible design:** readable typography, clear contrast, touch-friendly controls, and localization.
8. **Restraint:** do not add features merely because competitors have them.

## 5. MVP scope

The MVP should deliver a coherent, dependable daily-planning experience. Prioritize the following:

### 5.1 Onboarding and preferences
- First-launch introduction explaining NOW briefly.
- Language selection: system default where practical, with manual Arabic/English choice.
- Light and dark appearance, plus system-following option if feasible.
- No sign-up or login.
- Avoid collecting personal information that is not needed.

### 5.2 Home dashboard
- Clearly show the selected date and a useful summary of the day.
- Show today's scheduled events and tasks.
- Show completed versus remaining tasks.
- Highlight the next upcoming scheduled item when one exists.
- Provide a clear action to add a task or event.
- Provide sensible empty states for a new user.
- Do not show fabricated sample data after onboarding.

### 5.3 Tasks
A user can:
- Create, view, edit, complete, and delete a task.
- Enter a title and optional description.
- Set an optional due date and time.
- Set a priority (for example: low, medium, high).
- Assign an optional category.
- See task status (at minimum: pending/completed).
- Filter or sort tasks in a simple, understandable way.

Validation:
- A title is required.
- Invalid or contradictory date/time values must be handled clearly.
- Deletion of meaningful user data requires a confirmation step.
- Completing a task must persist after app restart.

### 5.4 Events and calendar
- Create, edit, view, and delete events.
- Store event title, optional description, start, end, and optional location/category where useful.
- Validate that an event end is after its start.
- Provide a useful daily and weekly view in the MVP.
- A monthly calendar may be included only if it does not delay core reliability.
- Show tasks with dates in relevant date views without confusing tasks and fixed-time events.
- Detect and communicate overlapping fixed-time events.

### 5.5 Daily timeline
- Present scheduled events and time-specific tasks chronologically.
- Make unscheduled tasks distinguishable from fixed-time items.
- Identify obvious overlaps.
- Avoid implying that an unscheduled task has a reserved time.
- Allow users to inspect the day's plan quickly.

### 5.6 Priorities
- Support a small, understandable priority scale.
- Make high-priority tasks visible without overwhelming the dashboard.
- Priority must not replace due dates or task status.

### 5.7 Local reminders
- Allow a reminder for a task or event when a date/time exists.
- Schedule notifications locally on the device.
- Allow reminders to be edited, disabled, and cancelled.
- Avoid duplicate notifications.
- Handle permission denial gracefully and explain how the user can enable notifications.
- Reconcile scheduled notifications with stored data after edits, deletion, and app restart where supported.
- Respect device timezone changes and daylight-saving behavior where relevant.

### 5.8 Daily review
- Summarize completed and unfinished tasks for a selected day.
- Offer a simple transition to the next day.
- Do not shame users or frame incomplete tasks as failure.
- Do not automatically move unfinished tasks without user confirmation.

### 5.9 Settings and data management
- Language selection.
- Theme selection.
- Notification preferences.
- Basic local data export/backup and restore should be considered for MVP if reliable; otherwise explicitly schedule it for the next phase and document the limitation.
- Provide a clear destructive-data reset flow with confirmation.

## 6. Explicitly out of MVP

Do not implement these in the first MVP unless the owner approves a scope change:

- Cloud accounts or mandatory authentication.
- Cloud synchronization or multi-device sync.
- Paid AI APIs or subscription services.
- Generative AI assistant or natural-language command interpretation.
- External calendar integrations.
- Home-screen widgets.
- Complex habit tracking and routine automation.
- Advanced analytics or productivity scoring.
- Social features, sharing, leaderboards, or collaboration.
- Ads, behavioral tracking, or unnecessary data collection.

## 7. Future roadmap

### Phase 2 — Personalization and deeper planning
- Recurring tasks and routines.
- Assisted rescheduling.
- Time-use insights.
- Home-screen widgets.
- Quick actions.
- Expanded theme customization.
- Reliable backup and restore if not included in MVP.

### Phase 3 — Connected and assisted experience
- NOW Assistant.
- Arabic natural-language task entry.
- Context-aware suggestions based on the user's own schedule.
- External calendar integrations.
- Optional account and cloud synchronization.
- Multi-device continuity.

Every future feature must be evaluated for ongoing cost, privacy impact, offline behavior, and maintenance burden before approval.

## 8. User stories

### Tasks
- As a user, I can quickly add a task so I do not forget it.
- As a user, I can set a due date and priority so I can organize my responsibilities.
- As a user, I can mark a task complete and see the change reflected immediately.
- As a user, I can edit or delete a task when plans change.

### Daily planning
- As a user, I can see today's events and tasks in one place.
- As a user, I can identify the next scheduled item.
- As a user, I can see conflicts between fixed-time events.

### Reminders
- As a user, I can receive a local reminder before an important item.
- As a user, I can change or cancel a reminder without receiving stale notifications.

### Accessibility and localization
- As an Arabic user, I can use the full app in RTL.
- As an English user, I can use the full app in LTR.
- As a user, I can choose a comfortable appearance.

### Privacy and reliability
- As a user, I can use core features without creating an account or connecting to the internet.
- As a user, I can close and reopen the app without losing saved data.

## 9. Main user flows

### First launch
1. Launch NOW.
2. Choose or confirm language.
3. Choose appearance or keep the default.
4. View a short explanation.
5. Arrive at an empty dashboard with a clear create-task action.

### Create a task
1. Open the add-task action.
2. Enter a required title.
3. Optionally add details, date/time, priority, category, and reminder.
4. Save.
5. See the task in the appropriate dashboard/list/date view.

### Create an event
1. Open add-event.
2. Enter title and start/end times.
3. Optionally add details and reminder.
4. Validate the time range and show any overlap.
5. Save and display the event in the calendar/timeline.

### Complete a task
1. Select the task completion control.
2. Persist the updated state.
3. Update relevant counts and views.
4. Ensure any no-longer-needed reminder is handled correctly.

### Daily review
1. Open daily review for a date.
2. Inspect completed and unfinished tasks.
3. Choose manually whether to reschedule unfinished work.

## 10. UX and visual direction

### Brand direction
- Modern, energetic, friendly, and focused.
- Use a consistent visual system rather than ad hoc styling.
- Avoid visual clutter, excessive gradients, and unnecessary animation.
- Motion should be subtle, purposeful, and respectful of reduced-motion settings where practical.

### Required design-system tokens
Define and centralize:
- Color roles for light and dark themes.
- Typography scale with Arabic font compatibility.
- Spacing scale.
- Corner radii.
- Elevation/surface rules.
- Icon sizing and usage.
- Button, card, input, dialog, navigation, and list-item styles.
- Focus, disabled, loading, empty, error, and success states.

Do not hard-code repeated visual values throughout feature widgets.

### Localization requirements
- Use Flutter localization infrastructure.
- Keep user-facing strings out of business logic.
- Verify RTL mirroring, text alignment, icons with directional meaning, date/time formatting, pluralization, and mixed Arabic/English content.
- Do not assume every icon should be mirrored; mirror only direction-sensitive icons.

## 11. Functional acceptance criteria

The MVP is not complete until:
- A user can create, edit, complete, and delete tasks.
- A user can create, edit, and delete events.
- Data persists after a force-close/relaunch test.
- The dashboard reflects saved data accurately.
- Daily and weekly views show the correct items.
- Fixed-time overlaps are identified accurately.
- Local reminders can be scheduled, edited, and cancelled without duplicates on supported platforms.
- Arabic RTL and English LTR are both usable across all MVP screens.
- Light and dark themes are coherent.
- Permission denial and empty states are handled gracefully.
- Core scheduling/date logic has automated tests.
- Database operations and migrations have tests where practical.
- No paid service or mandatory backend is required for core functionality.

## 12. Non-functional requirements

- Reliability takes priority over decorative features.
- Keep startup and navigation responsive on modest devices.
- Avoid unnecessary background work and battery use.
- Handle timezone and locale changes deliberately.
- Use accessible contrast and touch targets.
- Never log task descriptions or sensitive schedule content unnecessarily.
- Keep dependencies minimal and review their licenses and maintenance status.
- Do not promise iOS release readiness until it has been built and tested on macOS/Xcode.

## 13. MVP prioritization

**P0 — required:** local persistence, tasks, events, dashboard, daily view, Arabic/English localization, RTL/LTR, theme basics, tests.

**P1 — expected if stable:** weekly view, daily timeline, priorities, local reminders, daily review.

**P2 — defer if it threatens reliability or delivery:** monthly calendar, advanced filters, export/restore, extra animations, extensive customization.

Claude must report any proposed scope trade-off before dropping a P0 or P1 item.

## 14. Product risks and open decisions

- iOS compilation and signing require access to macOS and Xcode; do not claim iOS builds have been verified on a non-macOS machine.
- Notification behavior varies by platform and OS version; verify plugin support and platform-specific permission requirements.
- Backup/restore format and compatibility policy must be decided before implementing a production backup feature.
- The exact visual palette, typography, and navigation layout may be proposed by Claude, but should be presented for owner review before being treated as final brand decisions.
- Public app-store distribution may involve fees and account eligibility requirements; this is separate from zero-cost development and must not be misrepresented.

## 15. Change-control rule

The approved decisions in Section 2 are fixed unless the product owner explicitly changes them. Any new feature, paid dependency, backend, account requirement, or material scope change must be explained and approved before implementation.
