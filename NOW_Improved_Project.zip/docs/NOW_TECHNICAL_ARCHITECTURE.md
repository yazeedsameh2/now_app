# NOW — Technical Architecture
**Version:** 1.0  
**Status:** Approved technical baseline; validate package/platform details during implementation.

---

## 1. Architecture goals

Build NOW as a maintainable Flutter application with:
- A single shared codebase for Android and iOS.
- Local-first operation with no mandatory backend.
- Clear separation of UI, application logic, domain rules, and persistence.
- Complete Arabic RTL and English LTR support.
- A path to optional synchronization later without coupling the MVP to a cloud provider.
- Minimal dependencies and zero required service spend.

## 2. Proposed technology stack

| Concern | Proposed choice | Notes |
|---|---|---|
| App framework | Flutter | Shared Android/iOS codebase |
| Language | Dart | Primary application language |
| State management | Riverpod | Keep providers scoped and testable |
| Local database | SQLite + Drift | Typed queries, migrations, reactive streams |
| Navigation | GoRouter | Central route definitions |
| Notifications | A maintained local-notifications package | Verify current platform setup and exact supported versions before adoption |
| Simple preferences | SharedPreferences | Theme/language and non-relational preferences only |
| Localization | Flutter gen-l10n / ARB | Arabic and English |
| Version control | Git; GitHub optional | No paid service required |
| Tests | flutter_test; package-specific test tools | Unit, widget, and integration coverage |

Do not add Firebase, Supabase, a hosted database, analytics, crash-reporting SaaS, or an AI API to the MVP. A future cloud option must be separately evaluated for cost, privacy, and operational burden.

Before adding a dependency, check current maintenance, license, compatibility with the selected Flutter/Dart version, platform support, and whether the framework already provides the capability.

## 3. Architectural style

Use a feature-oriented, layered architecture. Avoid excessive abstraction for a small MVP, but preserve boundaries that matter.

### Layers

**Presentation**
- Screens, widgets, UI state, form validation presentation.
- Reads state through Riverpod providers.
- Does not issue SQL directly or own business rules.

**Application**
- Use cases and orchestration, such as CreateTask, CompleteTask, CreateEvent, ScheduleReminder, and LoadDailyOverview.
- Coordinates repositories and device services.

**Domain**
- Core entities, value objects, validation rules, and scheduling logic.
- Prefer pure Dart code where possible.
- Must not depend on Flutter widgets, SQLite, or notification plugins.

**Data**
- Repository implementations, Drift DAOs, DTO/entity mapping, migrations, and local data sources.
- Exposes repository contracts to the application/domain boundary.

**Device services**
- Notification scheduling, timezone integration, platform permissions, and other OS capabilities.
- Encapsulate plugins behind interfaces so tests can use fakes.

### Dependency direction

Presentation → Application → Domain  
Data implements repository contracts used by Application/Domain.  
Device services are accessed through abstractions.

Do not allow UI widgets to depend directly on database tables or plugin APIs.

## 4. Suggested project structure

```text
lib/
  app/
    app.dart
    router.dart
    bootstrap.dart
  core/
    errors/
    localization/
    theme/
    utils/
    widgets/
  database/
    app_database.dart
    migrations/
    tables/
    daos/
  features/
    dashboard/
      data/
      application/
      domain/
      presentation/
    tasks/
      data/
      application/
      domain/
      presentation/
    calendar/
      data/
      application/
      domain/
      presentation/
    scheduling/
      application/
      domain/
    reminders/
      data/
      application/
      domain/
      presentation/
    daily_review/
      application/
      presentation/
    settings/
      data/
      application/
      presentation/
  shared/
    models/
    services/
  l10n/
  main.dart

test/
  unit/
  widget/
  integration/
```

The structure can be adjusted if the chosen Drift or localization generator requires generated files. Keep generated code clearly separated and never hand-edit generated files.

## 5. Domain model and database design

Use stable primary identifiers (UUIDs or another well-defined local ID strategy). Store timestamps in a consistent UTC representation where appropriate, while preserving the intended local date/time semantics for calendar items.

The following is a conceptual starting point, not a mandate to create every table in the first migration.

### tasks
- id
- title (required)
- description (nullable)
- status (pending/completed)
- priority (low/medium/high)
- due_at_utc (nullable)
- due_timezone_id or explicit local-time metadata if required by the chosen date model
- category_id (nullable)
- created_at
- updated_at
- completed_at (nullable)

### events
- id
- title (required)
- description (nullable)
- starts_at_utc
- ends_at_utc
- timezone_id / local-time intent metadata as required
- location (nullable)
- category_id (nullable)
- created_at
- updated_at

### categories
- id
- name or localization strategy
- color/token identifier (nullable)
- created_at
- updated_at

### reminders
- id
- owner_type (task/event)
- owner_id
- trigger_at_utc
- notification_identifier (unique where supported)
- enabled
- created_at
- updated_at

### routines (future phase)
- id
- title
- recurrence_rule
- start_date
- optional end_date
- created_at
- updated_at

### daily_plans (only if a real persisted plan is needed)
- id
- local_date
- plan metadata
- created_at
- updated_at

### user_settings
Prefer SharedPreferences for simple device preferences. Use a database table only for structured settings that need transactional or relational behavior. Do not store the same setting in two sources of truth.

### Data rules
- A task title cannot be blank.
- Event end must be after event start.
- A reminder must reference a valid task/event.
- Deleting an item must cancel its scheduled notification.
- Define foreign-key and deletion behavior deliberately.
- Add indexes for common date/status/category queries after measuring query patterns.
- Use transactions for multi-step changes.
- Use migrations for every schema change after the initial release.
- Do not silently discard user data during migrations.

## 6. Time, date, and timezone strategy

Time handling is a high-risk area for planners.

- Define a single canonical representation for instants (UTC) and a clear representation for date-only values.
- Preserve timezone/local-time intent for future scheduled events where needed.
- Do not treat a date-only task as a UTC instant.
- Validate event start/end ordering.
- Test daylight-saving transitions where applicable, timezone changes, midnight boundaries, and locale-specific date display.
- Keep scheduling logic independent from widget formatting.
- Use the platform's current timezone data through a maintained package if required; verify package setup for each target platform.

## 7. State management

Use Riverpod for:
- Repository providers.
- Use-case providers.
- Screen/view-model state.
- Reactive database-backed lists and dashboard summaries.

Guidelines:
- Keep business logic out of widget build methods.
- Avoid one global mutable state object.
- Model loading, data, empty, and error states explicitly.
- Invalidate or update dependent providers after writes.
- Prefer immutable state and predictable transitions.
- Make providers testable with fake repositories.

## 8. Navigation

Use GoRouter with a small, understandable route map.

Proposed primary destinations:
- Home / Dashboard
- Tasks
- Calendar
- Settings

Task/event create and edit flows may use dedicated routes or modal sheets depending on usability and platform conventions. Navigation should preserve a sensible back stack and handle deep links only if genuinely needed.

## 9. Offline-first data flow

The local database is the source of truth for the MVP.

Read flow:
1. UI watches a Riverpod provider.
2. Provider calls a repository.
3. Repository reads from Drift/SQLite.
4. UI renders the local result.

Write flow:
1. UI submits a user action.
2. Application use case validates and coordinates the operation.
3. Repository writes to SQLite transactionally.
4. Reactive query streams update the UI.

Core features must not require network access. Do not create fake cloud abstractions that add complexity without an actual use case.

## 10. Future synchronization readiness

Do not implement cloud sync in the MVP. Preserve a reasonable migration path:

- Keep repository interfaces separate from Drift implementations.
- Use stable IDs.
- Track created/updated timestamps.
- Define deletion/tombstone strategy before sync is implemented.
- Consider schema versioning and conflict policy in a future design phase.
- Avoid assuming last-write-wins is always safe.
- Keep device-only settings separate from user data that might later sync.
- Do not choose a cloud provider until requirements, free-tier limits, privacy, and ongoing costs are reviewed.

## 11. Notifications

Create a notification service abstraction, for example:
- requestPermission()
- scheduleReminder()
- cancelReminder()
- rescheduleReminder()
- reconcilePendingReminders()

Requirements:
- Stable notification identifiers.
- No duplicate scheduling for the same reminder.
- Cancel stale notifications when an item is edited/deleted/completed as appropriate.
- Handle permission denial.
- Handle platform-specific exact-alarm/background restrictions honestly.
- Reconcile scheduled notifications with database records after relevant app lifecycle events.
- Test service behavior with a fake adapter and verify real devices separately.

Do not promise identical notification behavior on every Android/iOS version without testing.

## 12. Localization and RTL

- Use ARB files and generated localization accessors.
- Store Arabic and English strings in localization resources, not inline in widgets.
- Set locale direction using Flutter localization conventions.
- Test every primary screen in both locales.
- Test date/time and number formatting.
- Check text overflow, mixed-direction strings, navigation direction, and directional icons.
- Avoid concatenating translated sentence fragments.
- Provide accessible labels for icon-only controls.

## 13. Theme and design system

Create centralized theme definitions for:
- Light theme.
- Dark theme.
- Color roles.
- Text styles.
- Component themes.
- Spacing and radius constants.

The exact palette and typography are design proposals until the product owner approves them. Choose readable Arabic-compatible fonts that can be legally bundled at no cost, or use suitable system fonts. Verify font licenses.

## 14. Error handling and privacy

- Use typed/domain-level errors where useful.
- Convert low-level database/plugin exceptions into understandable UI states.
- Never show raw stack traces to end users.
- Do not log task titles, descriptions, event locations, or other schedule content unnecessarily.
- Request notification permission only when the user reaches a feature that needs it or during a clearly explained onboarding step.
- Keep all core user data local in the MVP.
- Avoid collecting analytics or identifiers.
- Do not store secrets in the app.
- Destructive actions require confirmation and clear consequences.

## 15. Testing strategy

### Unit tests
- Task validation.
- Event time validation.
- Priority sorting.
- Daily overview calculations.
- Timeline ordering.
- Overlap detection.
- Date-only and timezone conversion rules.
- Reminder identifier and reconciliation logic.

### Database tests
- CRUD behavior.
- Relationships and constraints.
- Transactions.
- Migration behavior.
- Persistence after database reopen.

### Widget tests
- Dashboard loading, empty, and populated states.
- Task create/edit validation.
- Arabic RTL and English LTR screen behavior.
- Light/dark themes.
- Error and permission-denied states where mockable.

### Integration/manual tests
- Fresh install.
- Create/edit/complete/delete task.
- Create/edit/delete event.
- Force close and relaunch.
- Reminder schedule/edit/cancel.
- Change language and theme.
- Airplane mode / offline usage.
- Test Android on a real device or emulator.
- iOS verification requires macOS and Xcode; do not claim it is tested otherwise.

## 16. Performance and maintainability

- Keep widgets small and focused.
- Use lazy lists for long collections.
- Avoid unnecessary rebuilds.
- Query only the data needed for the selected date/range.
- Avoid heavy work on the UI thread.
- Keep animations subtle and optional.
- Minimize dependencies.
- Document non-obvious architectural decisions.
- Run formatter, analyzer, and tests after each implementation phase.

## 17. Build and delivery constraints

- Development tools and dependencies must be free to use.
- Do not add a service that requires a credit card or could incur charges.
- Do not claim app-store publishing is free; development and public distribution are separate.
- Android can be tested through local builds/APKs subject to the developer's device setup.
- iOS builds/signing require macOS/Xcode access.
- Keep platform-specific instructions in the README.
- Do not commit signing keys, secrets, local machine paths, or generated private data.

## 18. Implementation phases and exit criteria

### Phase 0 — Environment and project bootstrap
Deliver:
- Flutter project scaffold.
- Git repository initialized if available.
- Dependency versions selected and documented.
- Basic app entry point.
- Analyzer and test commands documented.
- README with setup instructions.

Exit criteria:
- Project resolves dependencies.
- App launches on the available target platform.
- Formatter and analyzer run.
- A baseline test passes.

### Phase 1 — Design system and app shell
Deliver:
- Theme foundations.
- Arabic/English localization.
- RTL/LTR shell.
- Navigation.
- Empty dashboard.

Exit criteria:
- App shell runs in both languages and themes.
- No overflow on target test sizes.
- Basic widget tests pass.

### Phase 2 — Local database and tasks
Deliver:
- Drift database.
- Initial migration.
- Task model, repository, use cases, and UI.
- CRUD and completion.

Exit criteria:
- Task CRUD works.
- Data persists after restart.
- Database tests pass.

### Phase 3 — Events, calendar, and timeline
Deliver:
- Event model and repository.
- Daily/weekly views.
- Timeline ordering.
- Conflict detection.

Exit criteria:
- Event validation works.
- Views display correct items.
- Date/time and overlap tests pass.

### Phase 4 — Dashboard, priorities, and daily review
Deliver:
- Real dashboard summary.
- Next-item display.
- Priority presentation.
- Daily review.

Exit criteria:
- Dashboard derives from persisted data.
- Counts and summaries are accurate.
- Unfinished tasks are never moved without user confirmation.

### Phase 5 — Local reminders
Deliver:
- Notification abstraction and platform integration.
- Permission handling.
- Schedule/cancel/reconcile logic.

Exit criteria:
- No duplicate reminders in tested scenarios.
- Edits and deletion update notifications.
- Platform limitations are documented.

### Phase 6 — Stabilization
Deliver:
- Test coverage for critical paths.
- Accessibility and localization pass.
- Performance review.
- Data export/restore if approved and stable.
- Release checklist.

Exit criteria:
- All P0 acceptance criteria pass.
- Known limitations are documented.
- No unresolved critical data-loss or scheduling defects.

## 19. Definition of done

A feature is done only when:
1. Its behavior matches the approved product spec.
2. It has loading/empty/error states where applicable.
3. It works in Arabic and English.
4. It is tested at the appropriate level.
5. Formatting and static analysis pass.
6. No unnecessary paid dependency was introduced.
7. The user-facing behavior and any limitations are documented.
8. The changes are committed to Git when Git is available.

## 20. Architecture decision/change control

The following are baseline decisions: Flutter/Dart, Riverpod, SQLite/Drift, GoRouter, local notifications, local-first storage, no required login, Arabic/English, and no paid services.

If a package is incompatible, unmaintained, or unsuitable, propose a free alternative with evidence and trade-offs before replacing it. Do not silently introduce backend infrastructure, telemetry, subscriptions, or paid APIs.
