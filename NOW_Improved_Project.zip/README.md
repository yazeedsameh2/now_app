# NOW — يومك بوضوح

Bilingual (Arabic RTL / English LTR), local-first daily planner built with
Flutter. No account, no network, no paid service. Source of truth:
`docs/NOW_PRODUCT_SPEC.md` and `docs/NOW_TECHNICAL_ARCHITECTURE.md`.

## Status
All MVP phases are **written**. Verification so far is only what CI reports
(see "Verification"). Nothing was run on a device by the author.

| Phase | Scope | State |
|---|---|---|
| 0 | Bootstrap, CI | built and installed on a phone (owner screenshot) |
| 1 | Theme, l10n (ar/en), RTL, navigation, settings | CI green, owner device check pending |
| 2 | Drift database, tasks (CRUD, complete, filter, sort) | written, needs CI |
| 3 | Events, calendar day/week, timeline, conflict detection | written, needs CI |
| 4 | Dashboard, priorities, daily review | written, needs CI |
| 5 | Local reminders (permission, schedule, cancel, reconcile) | written, needs CI + phone |
| 6 | Tests, hardening, docs | tests written, needs CI |

## Architecture (as built)
`lib/app` (bootstrap, router, shell, provider wiring) · `lib/core` (theme
tokens, formatters, shared widgets) · `lib/database` (Drift schema, unit of
work) · `lib/features/<feature>/{domain,data,application,presentation}` ·
`lib/shared/models` · `lib/l10n` (ARB) · `test/{unit,database,widget,support}`.

- Domain code is pure Dart and unit-tested: validation, sorting, day plan,
  overlap detection, reminder planning.
- The database is the source of truth. `ReminderCoordinator.reconcile()` makes
  scheduled notifications match it (cancels stale ones, schedules wanted ones by
  stable id) after every write, on launch and on app resume.
- Task due dates are local date-only values (`yyyy-MM-dd`) plus optional minutes
  after midnight, never UTC instants. Event times are instants.

## Commands
```
flutter pub get
dart run build_runner build --delete-conflicting-outputs   # drift (*.g.dart)
flutter gen-l10n                                            # l10n (git-ignored)
flutter analyze
flutter test
```
Tests that open SQLite need the system library (`libsqlite3`).

## CI (`.github/workflows/build.yml`)
- `verify`: build_runner, gen-l10n, format check (non-blocking), analyze, test.
- `android`: **release, arm64-only** APK uploaded as a plain `.apk`
  (no zip) with 3-day retention. Signed with the Flutter debug key, which is
  enough to install on your own phone; it is not a Play Store build.
  `tool/patch_android.py` applies notification-related Android settings to the
  generated `android/` folder and prints what it changed.
- `ios`: manual only, unsigned compile check, **not installable on an iPhone**.

## Known limitations (honest list)
- Reminders use inexact alarms (`inexactAllowWhileIdle`) to avoid the exact-alarm
  permission, so Android may deliver them a few minutes late. Exact alarms are a
  possible later option.
- Reminder instants are recomputed from local wall-clock times at every
  reconcile; a timezone change is picked up the next time the app opens.
- One reminder per task/event. Events cannot be created across midnight in the
  form (the model and day view support overnight events).
- Month view, recurring items, search, export/backup, subtasks and widgets are
  out of MVP scope and not built. Export/backup is announced in Settings as
  "planned for a later release".
- Categories are a fixed built-in list stored by name, not a user-editable table.
- Reminders at "date-only" tasks fire at 09:00 local time on the due date.
- Notification channel name ("Reminders") is not localized.
- Palette, system fonts and Arabic wording are proposals pending owner review.
- `android/` and `ios/` are generated in CI and not committed.
- `go_router` may still use the legacy Material library internally; check page
  transitions on a device.
- iOS: notification and AppDelegate setup was not done or tested.


## UI and notification polish (2026-11)
- Refined the shared Material 3 theme: clearer app-bar hierarchy, rounded cards,
  consistent input surfaces, more intentional navigation, and improved touch targets.
- Dashboard progress now has a compact circular completion indicator.
- Added a custom NOW launcher icon asset and Android launcher-icon generation
  to the Android CI job (`flutter_launcher_icons`).
- Android reminders now use a new sound-enabled channel (`now_reminders_v2`),
  high importance, vibration, alarm audio attributes, and a dedicated status
  bar icon. iOS notification presentation explicitly enables sound.
- Android notification channel behavior is controlled by the OS. Users can
  still mute a channel or disable notifications in system settings; the app
  cannot override those choices.
- The source archive does not include generated `android/` or `ios/` folders.
  CI generates Android scaffolding before building.
- This environment did not have Flutter/Android SDK available, so `flutter
  analyze`, tests, and an APK build have not been executed here. Run the CI
  workflow or the README commands before treating this as a verified release.
