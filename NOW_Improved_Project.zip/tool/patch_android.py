#!/usr/bin/env python3
"""Adjusts the generated android/ folder for flutter_local_notifications.

Run from the project root, in CI only, right after `flutter create`:
  - compileSdk 37, Java 17, core library desugaring, multidex, minSdk >= 24
  - RECEIVE_BOOT_COMPLETED + the plugin's scheduled/boot receivers
  - app label "NOW"
  - keep rules so release builds do not strip the notification icon

It prints every file it changes so a failing build can be diagnosed from the
CI log alone. It exits non-zero when it cannot find the expected files.
"""
import pathlib
import re
import sys

APP = pathlib.Path("android/app")
COMPILE_SDK = 37
DESUGAR = "com.android.tools:desugar_jdk_libs:2.1.4"


def fail(message):
    print(f"ERROR: {message}")
    sys.exit(1)


def patch_kts(path):
    text = path.read_text()
    text = re.sub(r"compileSdk(?:Version)?\s*=\s*[^\n]+", f"compileSdk = {COMPILE_SDK}", text)
    text = re.sub(r"JavaVersion\.VERSION_\d+(?:_\d+)?", "JavaVersion.VERSION_17", text)
    text = re.sub(r"JvmTarget\.JVM_\d+(?:_\d+)?", "JvmTarget.JVM_17", text)
    text = re.sub(r'jvmTarget\s*=\s*"\d+"', 'jvmTarget = "17"', text)
    if "isCoreLibraryDesugaringEnabled" not in text:
        text = re.sub(
            r"(compileOptions\s*\{)",
            r"\1\n        isCoreLibraryDesugaringEnabled = true",
            text,
            count=1,
        )
    if "multiDexEnabled" not in text:
        text = re.sub(
            r"(defaultConfig\s*\{)",
            r"\1\n        multiDexEnabled = true",
            text,
            count=1,
        )
    text = re.sub(
        r"minSdk\s*=\s*flutter\.minSdkVersion",
        "minSdk = maxOf(flutter.minSdkVersion, 24)",
        text,
    )
    if "coreLibraryDesugaring(" not in text:
        text += f'\ndependencies {{\n    coreLibraryDesugaring("{DESUGAR}")\n}}\n'
    if 'signingConfigs.getByName("debug")' not in text:
        print("WARNING: release is not signed with the debug key by default;")
        print("         the APK may be unsigned and not installable.")
    return text


def patch_groovy(path):
    text = path.read_text()
    text = re.sub(
        r"compileSdk(?:Version)?\s*=?\s*flutter\.compileSdkVersion",
        f"compileSdk = {COMPILE_SDK}",
        text,
    )
    text = re.sub(r"JavaVersion\.VERSION_\d+(?:_\d+)?", "JavaVersion.VERSION_17", text)
    text = re.sub(r"jvmTarget\s*=\s*['\"]\d+['\"]", "jvmTarget = '17'", text)
    if "coreLibraryDesugaringEnabled" not in text:
        text = re.sub(
            r"(compileOptions\s*\{)",
            r"\1\n        coreLibraryDesugaringEnabled = true",
            text,
            count=1,
        )
    if "multiDexEnabled" not in text:
        text = re.sub(
            r"(defaultConfig\s*\{)",
            r"\1\n        multiDexEnabled = true",
            text,
            count=1,
        )
    text = re.sub(
        r"minSdk(?:Version)?\s*=?\s*flutter\.minSdkVersion",
        "minSdk = Math.max(flutter.minSdkVersion, 24)",
        text,
    )
    if "coreLibraryDesugaring " not in text:
        text += f"\ndependencies {{\n    coreLibraryDesugaring '{DESUGAR}'\n}}\n"
    return text


def patch_gradle():
    kts = APP / "build.gradle.kts"
    groovy = APP / "build.gradle"
    if kts.exists():
        path, text = kts, patch_kts(kts)
    elif groovy.exists():
        path, text = groovy, patch_groovy(groovy)
    else:
        fail("android/app/build.gradle(.kts) not found")
    path.write_text(text)
    print(f"--- patched {path} ---")
    print(text)


RECEIVERS = """
        <receiver
            android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver
            android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
    """


def patch_manifest():
    path = APP / "src/main/AndroidManifest.xml"
    if not path.exists():
        fail("AndroidManifest.xml not found")
    text = path.read_text()
    permissions = [
        '    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
        '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    ]
    for permission in permissions:
        marker = permission.split('"')[1]
        if marker not in text:
            text = text.replace("<application", permission + "\n    <application", 1)
    if "ScheduledNotificationReceiver" not in text:
        text = text.replace("</application>", RECEIVERS + "</application>", 1)
    text = re.sub(r'android:label="[^"]*"', 'android:label="NOW"', text, count=1)
    path.write_text(text)
    print(f"--- patched {path} ---")
    print(text)


def write_keep_rules():
    drawable = APP / "src/main/res/drawable"
    drawable.mkdir(parents=True, exist_ok=True)
    (drawable / "ic_stat_now.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\\n'
        '<vector xmlns:android="http://schemas.android.com/apk/res/android"\\n'
        '    android:width="24dp" android:height="24dp"\\n'
        '    android:viewportWidth="24" android:viewportHeight="24">\\n'
        '    <path android:fillColor="#FFFFFFFF" android:pathData="M3,12 L10,19 L21,5 L18,3 L10,14 L6,10 Z" />\\n'
        '</vector>\\n'
    )
    print("--- wrote res/drawable/ic_stat_now.xml ---")
    raw = APP / "src/main/res/raw"
    raw.mkdir(parents=True, exist_ok=True)
    (raw / "keep.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<resources xmlns:tools="http://schemas.android.com/tools"\n'
        '    tools:keep="@mipmap/ic_launcher,@drawable/*" />\n'
    )
    print("--- wrote res/raw/keep.xml ---")


if __name__ == "__main__":
    patch_gradle()
    patch_manifest()
    write_keep_rules()
