import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/widgets/choice_card.dart';
import 'package:now_app/core/widgets/confirm_dialog.dart';
import 'package:now_app/core/widgets/section_header.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/l10n/app_localizations.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final settings = ref.watch(settingsControllerProvider);
    final controller = ref.read(settingsControllerProvider.notifier);
    final permission = ref.watch(notificationPermissionProvider);
    final granted = permission.value;

    return Scaffold(
      appBar: AppBar(title: Text(l10n.settingsTitle)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
          SectionHeader(l10n.settingsLanguage),
          ChoiceCard<AppLanguage>(
            groupKey: 'language',
            value: settings.language,
            onSelected: controller.setLanguage,
            options: [
              (AppLanguage.system, l10n.languageSystem),
              (AppLanguage.arabic, l10n.languageArabic),
              (AppLanguage.english, l10n.languageEnglish),
            ],
          ),
          SectionHeader(l10n.settingsAppearance),
          ChoiceCard<AppThemeSetting>(
            groupKey: 'theme',
            value: settings.theme,
            onSelected: controller.setTheme,
            options: [
              (AppThemeSetting.system, l10n.themeSystem),
              (AppThemeSetting.light, l10n.themeLight),
              (AppThemeSetting.dark, l10n.themeDark),
            ],
          ),
          SectionHeader(l10n.settingsNotifications),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  key: const ValueKey('reminders-switch'),
                  title: Text(l10n.settingsRemindersToggle),
                  subtitle: Text(l10n.settingsRemindersSubtitle),
                  value: settings.remindersEnabled,
                  onChanged: (value) =>
                      controller.setRemindersEnabled(enabled: value),
                ),
                if (granted != null)
                  ListTile(
                    key: const ValueKey('permission-tile'),
                    leading: Icon(
                      granted
                          ? Icons.notifications_active_outlined
                          : Icons.notifications_off_outlined,
                    ),
                    title: Text(
                      granted
                          ? l10n.notificationsAllowed
                          : l10n.notificationsBlocked,
                    ),
                    subtitle: granted
                        ? null
                        : Text(l10n.notificationsBlockedHelp),
                  ),
                if (granted == false)
                  Padding(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    child: Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: FilledButton.tonal(
                        key: const ValueKey('allow-notifications'),
                        onPressed: () async {
                          final service = ref.read(notificationServiceProvider);
                          await service.requestPermission();
                          ref.invalidate(notificationPermissionProvider);
                          await ref
                              .read(reminderCoordinatorProvider)
                              .reconcile();
                        },
                        child: Text(l10n.notificationsAllow),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          SectionHeader(l10n.settingsData),
          Text(l10n.dataLocalNote, style: theme.textTheme.bodyMedium),
          const SizedBox(height: AppSpacing.sm),
          OutlinedButton.icon(
            key: const ValueKey('reset-data'),
            style: OutlinedButton.styleFrom(
              foregroundColor: theme.colorScheme.error,
            ),
            onPressed: () => _reset(context, ref),
            icon: const Icon(Icons.delete_forever_outlined),
            label: Text(l10n.dataResetAction),
          ),
          ],
        ),
      ),
    );
  }

  Future<void> _reset(BuildContext context, WidgetRef ref) async {
    final l10n = AppLocalizations.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final confirmed = await confirmAction(
      context,
      title: l10n.dataResetTitle,
      message: l10n.dataResetBody,
      confirmLabel: l10n.dataResetAction,
    );
    if (!confirmed) {
      return;
    }
    await ref.read(dataResetServiceProvider).resetAll();
    messenger.showSnackBar(SnackBar(content: Text(l10n.dataResetDone)));
  }
}
