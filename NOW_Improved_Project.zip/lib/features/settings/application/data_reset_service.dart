import 'package:now_app/database/unit_of_work.dart';
import 'package:now_app/features/calendar/domain/event_repository.dart';
import 'package:now_app/features/reminders/application/reminder_coordinator.dart';
import 'package:now_app/features/reminders/domain/reminder_repository.dart';
import 'package:now_app/features/tasks/domain/task_repository.dart';

/// Deletes all user data (tasks, events, reminders) and cancels notifications.
/// Device preferences (language, theme) are kept.
class DataResetService {
  DataResetService({
    required this.tasks,
    required this.events,
    required this.reminders,
    required this.unitOfWork,
    required this.coordinator,
  });

  final TaskRepository tasks;
  final EventRepository events;
  final ReminderRepository reminders;
  final UnitOfWork unitOfWork;
  final ReminderCoordinator coordinator;

  Future<void> resetAll() async {
    await unitOfWork.run(() async {
      await tasks.deleteAll();
      await events.deleteAll();
      await reminders.deleteAll();
    });
    await coordinator.reconcile();
  }
}
