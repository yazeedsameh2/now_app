import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/features/settings/domain/settings_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Stores preferences in SharedPreferences. Unknown or missing stored values
/// fall back to defaults instead of throwing.
class SharedPreferencesSettingsRepository implements SettingsRepository {
  SharedPreferencesSettingsRepository(this._prefs);

  static const languageKey = 'settings.language';
  static const themeKey = 'settings.theme';
  static const onboardingKey = 'settings.onboardingDone';
  static const remindersKey = 'settings.remindersEnabled';

  final SharedPreferences _prefs;

  @override
  AppSettings load() {
    final storedLanguage = _prefs.getString(languageKey);
    final storedTheme = _prefs.getString(themeKey);
    final languages = AppLanguage.values.asNameMap();
    final themes = AppThemeSetting.values.asNameMap();
    return AppSettings(
      language: languages[storedLanguage] ?? AppLanguage.system,
      theme: themes[storedTheme] ?? AppThemeSetting.system,
      onboardingDone: _prefs.getBool(onboardingKey) ?? false,
      remindersEnabled: _prefs.getBool(remindersKey) ?? true,
    );
  }

  @override
  Future<void> save(AppSettings settings) async {
    await _prefs.setString(languageKey, settings.language.name);
    await _prefs.setString(themeKey, settings.theme.name);
    await _prefs.setBool(onboardingKey, settings.onboardingDone);
    await _prefs.setBool(remindersKey, settings.remindersEnabled);
  }
}
