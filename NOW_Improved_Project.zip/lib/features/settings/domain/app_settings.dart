/// Interface language. `system` follows the device locale.
enum AppLanguage { system, arabic, english }

/// Appearance. `system` follows the device brightness.
enum AppThemeSetting { system, light, dark }

/// Device-level preferences. Pure Dart: no Flutter types on purpose.
class AppSettings {
  const AppSettings({
    this.language = AppLanguage.system,
    this.theme = AppThemeSetting.system,
    this.onboardingDone = false,
    this.remindersEnabled = true,
  });

  final AppLanguage language;
  final AppThemeSetting theme;
  final bool onboardingDone;
  final bool remindersEnabled;

  AppSettings copyWith({
    AppLanguage? language,
    AppThemeSetting? theme,
    bool? onboardingDone,
    bool? remindersEnabled,
  }) {
    return AppSettings(
      language: language ?? this.language,
      theme: theme ?? this.theme,
      onboardingDone: onboardingDone ?? this.onboardingDone,
      remindersEnabled: remindersEnabled ?? this.remindersEnabled,
    );
  }
}
