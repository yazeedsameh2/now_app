import 'app_settings.dart';

/// Contract for reading and writing device preferences.
abstract interface class SettingsRepository {
  AppSettings load();

  Future<void> save(AppSettings settings);
}
