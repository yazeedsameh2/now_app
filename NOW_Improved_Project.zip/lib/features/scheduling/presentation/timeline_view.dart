import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/routes.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/scheduling/domain/day_plan.dart';
import 'package:now_app/features/tasks/presentation/widgets/task_tile.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Chronological list of events and time-specific tasks for one day.
/// Events are filled cards; tasks are outlined cards with a checkbox, so the
/// two are distinguishable without relying on color.
class TimelineView extends StatelessWidget {
  const TimelineView({super.key, required this.plan});

  final DayPlan plan;

  @override
  Widget build(BuildContext context) {
    final conflictIds = plan.conflictEventIds;
    return Column(
      children: [
        for (final entry in plan.timeline)
          switch (entry) {
            EventEntry(:final event) => _EventCard(
              event: event,
              hasConflict: conflictIds.contains(event.id),
            ),
            TaskEntry(:final task) => Card(
              key: ValueKey('timeline-task-${task.id}'),
              elevation: 0,
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Theme.of(context).colorScheme.outline),
                borderRadius: BorderRadius.circular(AppRadius.md),
              ),
              child: TaskTile(task: task),
            ),
          },
      ],
    );
  }
}

class _EventCard extends StatelessWidget {
  const _EventCard({required this.event, required this.hasConflict});

  final Event event;
  final bool hasConflict;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final scheme = Theme.of(context).colorScheme;
    final range =
        '${formatTimeOfDay(context, event.startsAt)} – '
        '${formatTimeOfDay(context, event.endsAt)}';
    final location = event.location;
    return Card(
      key: ValueKey('timeline-event-${event.id}'),
      color: scheme.secondaryContainer,
      child: ListTile(
        leading: Icon(
          Icons.event,
          semanticLabel: l10n.kindEvent,
          color: scheme.onSecondaryContainer,
        ),
        title: Text(event.title),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(location == null ? range : '$range · $location'),
            if (hasConflict)
              Text(
                l10n.overlapsLabel,
                key: ValueKey('conflict-${event.id}'),
                style: TextStyle(
                  color: scheme.error,
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
        onTap: () => context.push(AppRoutes.editEvent(event.id)),
      ),
    );
  }
}
