import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/domain/task_rules.dart';

/// One chronological item: a fixed-time event or a task with a due time.
sealed class TimelineEntry {
  const TimelineEntry();

  DateTime get start;

  String get title;
}

class EventEntry extends TimelineEntry {
  const EventEntry(this.event);

  final Event event;

  @override
  DateTime get start => event.startsAt;

  @override
  String get title => event.title;
}

class TaskEntry extends TimelineEntry {
  const TaskEntry(this.task);

  final Task task;

  @override
  DateTime get start => task.dueAt!;

  @override
  String get title => task.title;
}

class EventConflict {
  const EventConflict(this.first, this.second);

  final Event first;
  final Event second;
}

/// All pairs of events that overlap in time (half-open intervals).
List<EventConflict> findConflicts(List<Event> events) {
  final sorted = [...events]..sort((a, b) => a.startsAt.compareTo(b.startsAt));
  final result = <EventConflict>[];
  for (var i = 0; i < sorted.length; i++) {
    for (var j = i + 1; j < sorted.length; j++) {
      if (!sorted[j].startsAt.isBefore(sorted[i].endsAt)) {
        break;
      }
      if (sorted[i].overlaps(sorted[j])) {
        result.add(EventConflict(sorted[i], sorted[j]));
      }
    }
  }
  return result;
}

class DayPlan {
  const DayPlan({
    required this.date,
    required this.timeline,
    required this.anytimeTasks,
    required this.conflicts,
  });

  final DateTime date;

  /// Events and time-specific tasks in chronological order.
  final List<TimelineEntry> timeline;

  /// Tasks due this day without a time. They have no reserved slot.
  final List<Task> anytimeTasks;
  final List<EventConflict> conflicts;

  List<Task> get tasks {
    return [
      for (final entry in timeline)
        if (entry is TaskEntry) entry.task,
      ...anytimeTasks,
    ];
  }

  List<Event> get events {
    return [
      for (final entry in timeline)
        if (entry is EventEntry) entry.event,
    ];
  }

  int get tasksTotal => tasks.length;

  int get tasksDone => tasks.where((task) => task.isCompleted).length;

  Set<String> get conflictEventIds {
    return {
      for (final conflict in conflicts) ...[
        conflict.first.id,
        conflict.second.id,
      ],
    };
  }

  bool get isEmpty => timeline.isEmpty && anytimeTasks.isEmpty;
}

int _compareEntries(TimelineEntry a, TimelineEntry b) {
  final byStart = a.start.compareTo(b.start);
  if (byStart != 0) {
    return byStart;
  }
  final aIsEvent = a is EventEntry;
  final bIsEvent = b is EventEntry;
  if (aIsEvent != bIsEvent) {
    return aIsEvent ? -1 : 1;
  }
  return a.title.toLowerCase().compareTo(b.title.toLowerCase());
}

DayPlan buildDayPlan({
  required DateTime date,
  required List<Task> tasks,
  required List<Event> events,
}) {
  final day = dateOnly(date);
  final nextDay = addDays(day, 1);
  final dayEvents = events
      .where((e) => e.startsAt.isBefore(nextDay) && e.endsAt.isAfter(day))
      .toList();
  final dueTasks = tasks.where((t) {
    final due = t.dueDate;
    return due != null && isSameDay(due, day);
  }).toList();
  final timedTasks = dueTasks.where((t) => t.hasDueTime);
  final anytime = dueTasks.where((t) => !t.hasDueTime).toList()
    ..sort((a, b) => compareTasks(a, b, TaskSort.priority));
  final timeline = <TimelineEntry>[
    for (final event in dayEvents) EventEntry(event),
    for (final task in timedTasks) TaskEntry(task),
  ]..sort(_compareEntries);
  return DayPlan(
    date: day,
    timeline: timeline,
    anytimeTasks: anytime,
    conflicts: findConflicts(dayEvents),
  );
}

class DayOverview {
  const DayOverview({this.nextEntry, this.ongoingEvent});

  final TimelineEntry? nextEntry;
  final Event? ongoingEvent;
}

/// The next scheduled item (not yet started, not a completed task) and the
/// event in progress, if any.
DayOverview computeOverview(DayPlan plan, DateTime now) {
  TimelineEntry? next;
  Event? ongoing;
  for (final entry in plan.timeline) {
    if (entry is EventEntry) {
      final event = entry.event;
      if (ongoing == null &&
          !event.startsAt.isAfter(now) &&
          event.endsAt.isAfter(now)) {
        ongoing = event;
      }
    }
    final completed = entry is TaskEntry && entry.task.isCompleted;
    if (next == null && !completed && !entry.start.isBefore(now)) {
      next = entry;
    }
  }
  return DayOverview(nextEntry: next, ongoingEvent: ongoing);
}
