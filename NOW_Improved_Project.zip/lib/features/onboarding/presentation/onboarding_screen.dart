import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/widgets/choice_card.dart';
import 'package:now_app/core/widgets/section_header.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// First-launch introduction: what NOW is, language and appearance. No
/// sign-up and no personal information is requested.
class OnboardingScreen extends ConsumerWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final settings = ref.watch(settingsControllerProvider);
    final controller = ref.read(settingsControllerProvider.notifier);

    Widget point(IconData icon, String text) {
      return Padding(
        padding: const EdgeInsets.only(bottom: AppSpacing.sm),
        child: Row(
          children: [
            Icon(icon, color: theme.colorScheme.primary),
            const SizedBox(width: AppSpacing.md),
            Expanded(child: Text(text)),
          ],
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
            Text(
              l10n.onboardingWelcome,
              key: const ValueKey('onboarding-title'),
              style: theme.textTheme.headlineMedium,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(l10n.appTagline, style: theme.textTheme.titleMedium),
            const SizedBox(height: AppSpacing.md),
            Text(l10n.onboardingBody),
            const SizedBox(height: AppSpacing.md),
            point(Icons.cloud_off_outlined, l10n.onboardingPoint1),
            point(Icons.lock_outline, l10n.onboardingPoint2),
            point(Icons.phone_android, l10n.onboardingPoint3),
            SectionHeader(l10n.settingsLanguage),
            ChoiceCard<AppLanguage>(
              groupKey: 'language',
              value: settings.language,
              onSelected: controller.setLanguage,
              options: [
                (AppLanguage.system, l10n.languageSystem),
                (AppLanguage.arabic, l10n.languageArabic),
                (AppLanguage.english, l10n.languageEnglish),
              ],
            ),
            SectionHeader(l10n.settingsAppearance),
            ChoiceCard<AppThemeSetting>(
              groupKey: 'theme',
              value: settings.theme,
              onSelected: controller.setTheme,
              options: [
                (AppThemeSetting.system, l10n.themeSystem),
                (AppThemeSetting.light, l10n.themeLight),
                (AppThemeSetting.dark, l10n.themeDark),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
            FilledButton(
              key: const ValueKey('onboarding-start'),
              onPressed: controller.completeOnboarding,
              child: Text(l10n.onboardingStart),
            ),
            ],
          ),
        ),
      ),
    );
  }
}
