import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/app/routes.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/widgets/empty_state.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/domain/task_rules.dart';
import 'package:now_app/features/tasks/presentation/widgets/task_tile.dart';
import 'package:now_app/l10n/app_localizations.dart';

class TasksScreen extends ConsumerStatefulWidget {
  const TasksScreen({super.key});

  @override
  ConsumerState<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends ConsumerState<TasksScreen> {
  TaskFilter _filter = TaskFilter.pending;
  TaskSort _sort = TaskSort.dueDate;

  String _filterLabel(AppLocalizations l10n, TaskFilter filter) {
    switch (filter) {
      case TaskFilter.pending:
        return l10n.filterPending;
      case TaskFilter.today:
        return l10n.filterToday;
      case TaskFilter.completed:
        return l10n.filterCompleted;
      case TaskFilter.all:
        return l10n.filterAll;
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final tasksAsync = ref.watch(tasksProvider);
    final today = dateOnly(ref.watch(clockProvider)());

    return Scaffold(
      appBar: AppBar(title: Text(l10n.navTasks)),
      floatingActionButton: FloatingActionButton.extended(
        key: const ValueKey('tasks-fab'),
        heroTag: null,
        onPressed: () => context.push(AppRoutes.newTask()),
        icon: const Icon(Icons.add),
        label: Text(l10n.addTask),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.md,
              vertical: AppSpacing.sm,
            ),
            child: Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: [
                for (final filter in TaskFilter.values)
                  ChoiceChip(
                    key: ValueKey('filter-${filter.name}'),
                    label: Text(_filterLabel(l10n, filter)),
                    selected: _filter == filter,
                    onSelected: (_) => setState(() => _filter = filter),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
            child: SegmentedButton<TaskSort>(
              segments: [
                ButtonSegment(
                  value: TaskSort.dueDate,
                  label: Text(l10n.sortByDue),
                ),
                ButtonSegment(
                  value: TaskSort.priority,
                  label: Text(l10n.sortByPriority),
                ),
              ],
              selected: {_sort},
              onSelectionChanged: (selection) {
                setState(() => _sort = selection.first);
              },
            ),
          ),
          Expanded(
            child: tasksAsync.when(
              data: (tasks) => _TaskList(
                tasks: _visible(tasks, today),
                emptyTitle: l10n.tasksEmptyTitle,
                emptyBody: l10n.tasksEmptyBody,
              ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, stackTrace) =>
                  Center(child: Text(l10n.errorGeneric)),
            ),
          ),
        ],
      ),
    );
  }

  List<Task> _visible(List<Task> tasks, DateTime today) {
    final result = tasks.where((t) => matchesFilter(t, _filter, today)).toList()
      ..sort((a, b) => compareTasks(a, b, _sort));
    return result;
  }
}

class _TaskList extends StatelessWidget {
  const _TaskList({
    required this.tasks,
    required this.emptyTitle,
    required this.emptyBody,
  });

  final List<Task> tasks;
  final String emptyTitle;
  final String emptyBody;

  @override
  Widget build(BuildContext context) {
    if (tasks.isEmpty) {
      return EmptyState(
        key: const ValueKey('tasks-empty'),
        icon: Icons.checklist_outlined,
        title: emptyTitle,
        message: emptyBody,
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 96),
      itemCount: tasks.length,
      itemBuilder: (context, index) {
        return TaskTile(task: tasks[index], showDate: true);
      },
    );
  }
}
