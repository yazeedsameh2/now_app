import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/app/routes.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/presentation/widgets/priority_badge.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// One task row: completion checkbox, title, due info, priority.
class TaskTile extends ConsumerWidget {
  const TaskTile({super.key, required this.task, this.showDate = false});

  final Task task;
  final bool showDate;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final parts = <String>[];
    final due = task.dueDate;
    if (showDate && due != null) {
      parts.add(formatShortDate(context, due));
    }
    final dueAt = task.dueAt;
    if (dueAt != null) {
      parts.add(l10n.dueAtLabel(formatTimeOfDay(context, dueAt)));
    }
    final category = task.category;
    if (category != null) {
      parts.add(categoryLabel(l10n, category));
    }

    return ListTile(
      key: ValueKey('task-${task.id}'),
      leading: Checkbox(
        key: ValueKey('check-${task.id}'),
        value: task.isCompleted,
        onChanged: (value) {
          ref
              .read(taskActionsProvider)
              .setCompleted(task, completed: value ?? false);
        },
      ),
      title: Text(
        task.title,
        style: task.isCompleted
            ? theme.textTheme.bodyLarge?.copyWith(
                decoration: TextDecoration.lineThrough,
                color: theme.colorScheme.onSurfaceVariant,
              )
            : null,
      ),
      subtitle: parts.isEmpty ? null : Text(parts.join(' · ')),
      trailing: PriorityBadge(priority: task.priority),
      onTap: () => context.push(AppRoutes.editTask(task.id)),
    );
  }
}
