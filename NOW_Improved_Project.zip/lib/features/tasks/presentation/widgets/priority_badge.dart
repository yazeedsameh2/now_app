import 'package:material_ui/material_ui.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/l10n/app_localizations.dart';
import 'package:now_app/shared/models/priority.dart';

/// Text + color badge: priority is never conveyed by color alone.
class PriorityBadge extends StatelessWidget {
  const PriorityBadge({super.key, required this.priority});

  final Priority priority;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = switch (priority) {
      Priority.high => scheme.error,
      Priority.medium => scheme.tertiary,
      Priority.low => scheme.outline,
    };
    final l10n = AppLocalizations.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.xs,
      ),
      decoration: BoxDecoration(
        border: Border.all(color: color),
        borderRadius: BorderRadius.circular(AppRadius.sm),
      ),
      child: Text(
        priorityLabel(l10n, priority),
        style: Theme.of(context).textTheme.labelSmall?.copyWith(color: color),
      ),
    );
  }
}
