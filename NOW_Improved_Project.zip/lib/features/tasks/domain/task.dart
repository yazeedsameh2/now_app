import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/shared/models/item_category.dart';
import 'package:now_app/shared/models/priority.dart';

class Task {
  const Task({
    required this.id,
    required this.title,
    required this.priority,
    required this.createdAt,
    required this.updatedAt,
    this.description,
    this.dueDate,
    this.dueMinutes,
    this.category,
    this.completedAt,
  });

  final String id;
  final String title;
  final String? description;
  final Priority priority;

  /// Local calendar date. A date-only value, never converted to a UTC instant.
  final DateTime? dueDate;

  /// Minutes after local midnight. Only meaningful when [dueDate] is set.
  final int? dueMinutes;
  final ItemCategory? category;
  final DateTime? completedAt;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get isCompleted => completedAt != null;

  bool get hasDueTime => dueDate != null && dueMinutes != null;

  /// Local wall-clock due instant; null for undated or date-only tasks.
  DateTime? get dueAt {
    if (!hasDueTime) {
      return null;
    }
    return atMinutes(dueDate!, dueMinutes!);
  }

  Task withCompletion(DateTime? at, DateTime now) {
    return Task(
      id: id,
      title: title,
      description: description,
      priority: priority,
      dueDate: dueDate,
      dueMinutes: dueMinutes,
      category: category,
      completedAt: at,
      createdAt: createdAt,
      updatedAt: now,
    );
  }

  Task withDueDate(DateTime date, DateTime now) {
    return Task(
      id: id,
      title: title,
      description: description,
      priority: priority,
      dueDate: dateOnly(date),
      dueMinutes: dueMinutes,
      category: category,
      completedAt: completedAt,
      createdAt: createdAt,
      updatedAt: now,
    );
  }
}
