import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/features/tasks/domain/task.dart';

enum TaskSort { dueDate, priority }

enum TaskFilter { pending, today, completed, all }

Set<FormError> validateTaskFields({
  required String title,
  DateTime? dueDate,
  int? dueMinutes,
}) {
  final errors = <FormError>{};
  final trimmed = title.trim();
  if (trimmed.isEmpty) {
    errors.add(FormError.titleRequired);
  }
  if (trimmed.length > maxTitleLength) {
    errors.add(FormError.titleTooLong);
  }
  if (dueDate == null && dueMinutes != null) {
    errors.add(FormError.timeWithoutDate);
  }
  return errors;
}

int _compareDue(Task a, Task b) {
  final ad = a.dueDate;
  final bd = b.dueDate;
  if (ad == null && bd == null) {
    return 0;
  }
  if (ad == null) {
    return 1;
  }
  if (bd == null) {
    return -1;
  }
  final byDate = ad.compareTo(bd);
  if (byDate != 0) {
    return byDate;
  }
  final am = a.dueMinutes;
  final bm = b.dueMinutes;
  if (am == null && bm == null) {
    return 0;
  }
  if (am == null) {
    return 1;
  }
  if (bm == null) {
    return -1;
  }
  return am.compareTo(bm);
}

/// Pending tasks first, then by the chosen sort, then by the other key.
int compareTasks(Task a, Task b, TaskSort sort) {
  if (a.isCompleted != b.isCompleted) {
    return a.isCompleted ? 1 : -1;
  }
  final byDue = _compareDue(a, b);
  final byPriority = b.priority.index.compareTo(a.priority.index);
  final first = sort == TaskSort.dueDate ? byDue : byPriority;
  if (first != 0) {
    return first;
  }
  final second = sort == TaskSort.dueDate ? byPriority : byDue;
  if (second != 0) {
    return second;
  }
  return a.title.toLowerCase().compareTo(b.title.toLowerCase());
}

bool matchesFilter(Task task, TaskFilter filter, DateTime today) {
  switch (filter) {
    case TaskFilter.pending:
      return !task.isCompleted;
    case TaskFilter.today:
      final due = task.dueDate;
      return due != null && isSameDay(due, today);
    case TaskFilter.completed:
      return task.isCompleted;
    case TaskFilter.all:
      return true;
  }
}

/// Pending tasks whose due date is before [today], oldest first.
List<Task> overdueTasks(List<Task> tasks, DateTime today) {
  final day = dateOnly(today);
  final result = tasks.where((task) {
    final due = task.dueDate;
    return !task.isCompleted && due != null && due.isBefore(day);
  }).toList();
  result.sort((a, b) => compareTasks(a, b, TaskSort.dueDate));
  return result;
}
