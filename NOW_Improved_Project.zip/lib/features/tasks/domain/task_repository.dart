import 'package:now_app/features/tasks/domain/task.dart';

abstract interface class TaskRepository {
  Stream<List<Task>> watchAll();

  Future<List<Task>> getAll();

  Future<Task?> getById(String id);

  Future<void> upsert(Task task);

  Future<void> delete(String id);

  Future<void> deleteAll();
}
