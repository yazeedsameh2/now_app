import 'package:drift/drift.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/database/app_database.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/domain/task_repository.dart';
import 'package:now_app/shared/models/item_category.dart';
import 'package:now_app/shared/models/priority.dart';

class DriftTaskRepository implements TaskRepository {
  DriftTaskRepository(this._db);

  final AppDatabase _db;

  Task _fromRow(TaskRow row) {
    return Task(
      id: row.id,
      title: row.title,
      description: row.description,
      priority: priorityFromIndex(row.priority),
      dueDate: parseDateKey(row.dueDate),
      dueMinutes: row.dueMinutes,
      category: categoryFromName(row.category),
      completedAt: row.completedAt,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    );
  }

  @override
  Stream<List<Task>> watchAll() {
    final query = _db.select(_db.tasks)
      ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]);
    return query.watch().map((rows) => rows.map(_fromRow).toList());
  }

  @override
  Future<List<Task>> getAll() async {
    final rows = await _db.select(_db.tasks).get();
    return rows.map(_fromRow).toList();
  }

  @override
  Future<Task?> getById(String id) async {
    final query = _db.select(_db.tasks)..where((t) => t.id.equals(id));
    final row = await query.getSingleOrNull();
    return row == null ? null : _fromRow(row);
  }

  @override
  Future<void> upsert(Task task) async {
    final due = task.dueDate;
    await _db
        .into(_db.tasks)
        .insertOnConflictUpdate(
          TasksCompanion(
            id: Value(task.id),
            title: Value(task.title),
            description: Value(task.description),
            priority: Value(task.priority.index),
            dueDate: Value(due == null ? null : dateKey(due)),
            dueMinutes: Value(task.dueMinutes),
            category: Value(task.category?.name),
            completedAt: Value(task.completedAt),
            createdAt: Value(task.createdAt),
            updatedAt: Value(task.updatedAt),
          ),
        );
  }

  @override
  Future<void> delete(String id) async {
    await (_db.delete(_db.tasks)..where((t) => t.id.equals(id))).go();
  }

  @override
  Future<void> deleteAll() async {
    await _db.delete(_db.tasks).go();
  }
}
