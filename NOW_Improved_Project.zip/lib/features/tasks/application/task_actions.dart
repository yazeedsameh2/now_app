import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/utils/ids.dart';
import 'package:now_app/database/unit_of_work.dart';
import 'package:now_app/features/reminders/application/reminder_coordinator.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/domain/reminder_repository.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/domain/task_repository.dart';
import 'package:now_app/features/tasks/domain/task_rules.dart';
import 'package:now_app/shared/models/item_category.dart';
import 'package:now_app/shared/models/priority.dart';

/// What the task form submits.
class TaskDraft {
  const TaskDraft({
    required this.title,
    required this.priority,
    this.description,
    this.dueDate,
    this.dueMinutes,
    this.category,
    this.reminderOffset,
  });

  final String title;
  final String? description;
  final Priority priority;
  final DateTime? dueDate;
  final int? dueMinutes;
  final ItemCategory? category;

  /// Minutes before the due time, or null for no reminder.
  final int? reminderOffset;
}

/// Use cases for tasks: validate, persist transactionally, reconcile reminders.
class TaskActions {
  TaskActions({
    required this.tasks,
    required this.reminders,
    required this.unitOfWork,
    required this.coordinator,
    required this.clock,
  });

  final TaskRepository tasks;
  final ReminderRepository reminders;
  final UnitOfWork unitOfWork;
  final ReminderCoordinator coordinator;
  final DateTime Function() clock;

  /// Creates a task, or updates [existing]. [previousReminderOffset] is the
  /// reminder the task had before editing (used to avoid blocking edits of old
  /// tasks whose reminder time has already passed).
  Future<SaveResult> save(
    TaskDraft draft, {
    Task? existing,
    int? previousReminderOffset,
  }) async {
    final now = clock();
    final errors = validateTaskFields(
      title: draft.title,
      dueDate: draft.dueDate,
      dueMinutes: draft.dueMinutes,
    );
    final offset = draft.reminderOffset;
    if (offset != null) {
      final date = draft.dueDate;
      if (date == null) {
        errors.add(FormError.reminderNeedsDate);
      } else {
        final base = atMinutes(
          date,
          draft.dueMinutes ?? defaultTaskReminderMinutes,
        );
        final changed =
            existing == null ||
            previousReminderOffset != offset ||
            existing.dueDate != draft.dueDate ||
            existing.dueMinutes != draft.dueMinutes;
        if (changed && !reminderTrigger(base, offset).isAfter(now)) {
          errors.add(FormError.reminderInPast);
        }
      }
    }
    if (errors.isNotEmpty) {
      return SaveResult(errors);
    }

    final description = draft.description?.trim();
    final dueDate = draft.dueDate;
    final task = Task(
      id: existing?.id ?? newId(),
      title: draft.title.trim(),
      description: (description == null || description.isEmpty)
          ? null
          : description,
      priority: draft.priority,
      dueDate: dueDate == null ? null : dateOnly(dueDate),
      dueMinutes: dueDate == null ? null : draft.dueMinutes,
      category: draft.category,
      completedAt: existing?.completedAt,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    );
    await unitOfWork.run(() async {
      await tasks.upsert(task);
      if (offset == null) {
        await reminders.removeForOwner(ReminderOwnerType.task, task.id);
      } else {
        await reminders.save(
          type: ReminderOwnerType.task,
          ownerId: task.id,
          offsetMinutes: offset,
          now: now,
        );
      }
    });
    await coordinator.reconcile();
    return SaveResult.success;
  }

  Future<void> setCompleted(Task task, {required bool completed}) async {
    final now = clock();
    await tasks.upsert(task.withCompletion(completed ? now : null, now));
    await coordinator.reconcile();
  }

  Future<void> delete(String id) async {
    await unitOfWork.run(() async {
      await tasks.delete(id);
      await reminders.removeForOwner(ReminderOwnerType.task, id);
    });
    await coordinator.reconcile();
  }

  /// Changes the due date of several tasks (user-confirmed bulk move).
  Future<void> moveToDate(List<Task> toMove, DateTime date) async {
    final now = clock();
    await unitOfWork.run(() async {
      for (final task in toMove) {
        await tasks.upsert(task.withDueDate(date, now));
      }
    });
    await coordinator.reconcile();
  }
}
