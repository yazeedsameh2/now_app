import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/core/theme/app_tokens.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/core/widgets/confirm_dialog.dart';
import 'package:now_app/core/widgets/section_header.dart';
import 'package:now_app/features/scheduling/domain/day_plan.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/presentation/widgets/task_tile.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Reflects on a day. Nothing is moved unless the user explicitly chooses to.
class DailyReviewScreen extends ConsumerWidget {
  const DailyReviewScreen({super.key, this.date});

  final DateTime? date;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final theme = Theme.of(context);
    final day = date ?? dateOnly(ref.watch(clockProvider)());
    final tasksAsync = ref.watch(tasksProvider);
    final eventsAsync = ref.watch(eventsProvider);

    Widget body;
    if (tasksAsync.hasError || eventsAsync.hasError) {
      body = Center(child: Text(l10n.errorGeneric));
    } else if (!tasksAsync.hasValue || !eventsAsync.hasValue) {
      body = const Center(child: CircularProgressIndicator());
    } else {
      final plan = buildDayPlan(
        date: day,
        tasks: tasksAsync.requireValue,
        events: eventsAsync.requireValue,
      );
      final dayTasks = plan.tasks;
      final done = dayTasks.where((t) => t.isCompleted).toList();
      final open = dayTasks.where((t) => !t.isCompleted).toList();
      body = SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
          Text(
            formatLongDate(context, day),
            style: theme.textTheme.headlineSmall,
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            dayTasks.isEmpty
                ? l10n.reviewNoTasks
                : l10n.reviewSummary(done.length, dayTasks.length),
            key: const ValueKey('review-summary'),
            style: theme.textTheme.titleMedium,
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(l10n.reviewGentle),
          SectionHeader(l10n.reviewCompleted),
          if (done.isEmpty)
            Text(l10n.reviewNothingCompleted)
          else
            Card(
              child: Column(
                children: [for (final task in done) TaskTile(task: task)],
              ),
            ),
          SectionHeader(l10n.reviewUnfinished),
          if (open.isEmpty)
            Text(
              dayTasks.isEmpty ? l10n.reviewNoTasks : l10n.reviewAllDone,
              key: const ValueKey('review-all-done'),
            )
          else ...[
            Card(
              child: Column(
                children: [
                  for (final task in open)
                    _OpenTaskRow(task: task, day: day),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.sm),
            FilledButton.tonal(
              key: const ValueKey('review-move-all'),
              onPressed: () => _moveAll(context, ref, open, day),
              child: Text(l10n.reviewMoveAll),
            ),
          ],
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(l10n.reviewTitle)),
      body: body,
    );
  }

  Future<void> _moveAll(
    BuildContext context,
    WidgetRef ref,
    List<Task> open,
    DateTime day,
  ) async {
    final l10n = AppLocalizations.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final confirmed = await confirmAction(
      context,
      title: l10n.reviewMoveAllTitle,
      message: l10n.reviewMoveAllBody,
      confirmLabel: l10n.reviewMoveAll,
    );
    if (!confirmed) {
      return;
    }
    await ref.read(taskActionsProvider).moveToDate(open, addDays(day, 1));
    messenger.showSnackBar(SnackBar(content: Text(l10n.reviewMoved)));
  }
}

class _OpenTaskRow extends ConsumerWidget {
  const _OpenTaskRow({required this.task, required this.day});

  final Task task;
  final DateTime day;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    return Column(
      children: [
        TaskTile(task: task),
        Align(
          alignment: AlignmentDirectional.centerEnd,
          child: Padding(
            padding: const EdgeInsetsDirectional.only(end: AppSpacing.sm),
            child: TextButton(
              key: ValueKey('move-${task.id}'),
              onPressed: () async {
                final messenger = ScaffoldMessenger.of(context);
                await ref
                    .read(taskActionsProvider)
                    .moveToDate([task], addDays(day, 1));
                messenger.showSnackBar(
                  SnackBar(content: Text(l10n.reviewMoved)),
                );
              },
              child: Text(l10n.reviewMoveToTomorrow),
            ),
          ),
        ),
      ],
    );
  }
}
