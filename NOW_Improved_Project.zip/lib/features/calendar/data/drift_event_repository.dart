import 'package:drift/drift.dart';
import 'package:now_app/database/app_database.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/calendar/domain/event_repository.dart';
import 'package:now_app/shared/models/item_category.dart';

class DriftEventRepository implements EventRepository {
  DriftEventRepository(this._db);

  final AppDatabase _db;

  Event _fromRow(EventRow row) {
    return Event(
      id: row.id,
      title: row.title,
      description: row.description,
      startsAt: row.startsAt,
      endsAt: row.endsAt,
      location: row.location,
      category: categoryFromName(row.category),
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    );
  }

  @override
  Stream<List<Event>> watchAll() {
    final query = _db.select(_db.events)
      ..orderBy([(e) => OrderingTerm.asc(e.startsAt)]);
    return query.watch().map((rows) => rows.map(_fromRow).toList());
  }

  @override
  Future<List<Event>> getAll() async {
    final rows = await _db.select(_db.events).get();
    return rows.map(_fromRow).toList();
  }

  @override
  Future<Event?> getById(String id) async {
    final query = _db.select(_db.events)..where((e) => e.id.equals(id));
    final row = await query.getSingleOrNull();
    return row == null ? null : _fromRow(row);
  }

  @override
  Future<void> upsert(Event event) async {
    await _db
        .into(_db.events)
        .insertOnConflictUpdate(
          EventsCompanion(
            id: Value(event.id),
            title: Value(event.title),
            description: Value(event.description),
            startsAt: Value(event.startsAt),
            endsAt: Value(event.endsAt),
            location: Value(event.location),
            category: Value(event.category?.name),
            createdAt: Value(event.createdAt),
            updatedAt: Value(event.updatedAt),
          ),
        );
  }

  @override
  Future<void> delete(String id) async {
    await (_db.delete(_db.events)..where((e) => e.id.equals(id))).go();
  }

  @override
  Future<void> deleteAll() async {
    await _db.delete(_db.events).go();
  }
}
