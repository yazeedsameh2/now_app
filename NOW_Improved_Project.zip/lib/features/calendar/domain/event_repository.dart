import 'package:now_app/features/calendar/domain/event.dart';

abstract interface class EventRepository {
  Stream<List<Event>> watchAll();

  Future<List<Event>> getAll();

  Future<Event?> getById(String id);

  Future<void> upsert(Event event);

  Future<void> delete(String id);

  Future<void> deleteAll();
}
