import 'package:now_app/core/errors/form_error.dart';

Set<FormError> validateEventFields({
  required String title,
  required DateTime startsAt,
  required DateTime endsAt,
}) {
  final errors = <FormError>{};
  final trimmed = title.trim();
  if (trimmed.isEmpty) {
    errors.add(FormError.titleRequired);
  }
  if (trimmed.length > maxTitleLength) {
    errors.add(FormError.titleTooLong);
  }
  if (!endsAt.isAfter(startsAt)) {
    errors.add(FormError.endNotAfterStart);
  }
  return errors;
}
