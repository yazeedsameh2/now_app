import 'package:now_app/shared/models/item_category.dart';

class Event {
  const Event({
    required this.id,
    required this.title,
    required this.startsAt,
    required this.endsAt,
    required this.createdAt,
    required this.updatedAt,
    this.description,
    this.location,
    this.category,
  });

  final String id;
  final String title;
  final String? description;

  /// Instants. Persisted as UTC; read back as local wall-clock values.
  final DateTime startsAt;
  final DateTime endsAt;
  final String? location;
  final ItemCategory? category;
  final DateTime createdAt;
  final DateTime updatedAt;

  /// Half-open overlap: events that merely touch do not overlap.
  bool overlaps(Event other) {
    return startsAt.isBefore(other.endsAt) && other.startsAt.isBefore(endsAt);
  }
}
