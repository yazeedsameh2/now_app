import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/core/utils/ids.dart';
import 'package:now_app/database/unit_of_work.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/calendar/domain/event_repository.dart';
import 'package:now_app/features/calendar/domain/event_rules.dart';
import 'package:now_app/features/reminders/application/reminder_coordinator.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/domain/reminder_repository.dart';
import 'package:now_app/shared/models/item_category.dart';

/// What the event form submits. Times are minutes after local midnight.
class EventDraft {
  const EventDraft({
    required this.title,
    required this.date,
    required this.startMinutes,
    required this.endMinutes,
    this.description,
    this.location,
    this.category,
    this.reminderOffset,
  });

  final String title;
  final String? description;
  final DateTime date;
  final int startMinutes;
  final int endMinutes;
  final String? location;
  final ItemCategory? category;
  final int? reminderOffset;

  DateTime get startsAt => atMinutes(date, startMinutes);

  DateTime get endsAt => atMinutes(date, endMinutes);
}

class EventActions {
  EventActions({
    required this.events,
    required this.reminders,
    required this.unitOfWork,
    required this.coordinator,
    required this.clock,
  });

  final EventRepository events;
  final ReminderRepository reminders;
  final UnitOfWork unitOfWork;
  final ReminderCoordinator coordinator;
  final DateTime Function() clock;

  Future<SaveResult> save(
    EventDraft draft, {
    Event? existing,
    int? previousReminderOffset,
  }) async {
    final now = clock();
    final errors = validateEventFields(
      title: draft.title,
      startsAt: draft.startsAt,
      endsAt: draft.endsAt,
    );
    final offset = draft.reminderOffset;
    if (offset != null) {
      final changed =
          existing == null ||
          previousReminderOffset != offset ||
          existing.startsAt != draft.startsAt;
      if (changed && !reminderTrigger(draft.startsAt, offset).isAfter(now)) {
        errors.add(FormError.reminderInPast);
      }
    }
    if (errors.isNotEmpty) {
      return SaveResult(errors);
    }

    String? clean(String? value) {
      final trimmed = value?.trim();
      return (trimmed == null || trimmed.isEmpty) ? null : trimmed;
    }

    final event = Event(
      id: existing?.id ?? newId(),
      title: draft.title.trim(),
      description: clean(draft.description),
      startsAt: draft.startsAt,
      endsAt: draft.endsAt,
      location: clean(draft.location),
      category: draft.category,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    );
    await unitOfWork.run(() async {
      await events.upsert(event);
      if (offset == null) {
        await reminders.removeForOwner(ReminderOwnerType.event, event.id);
      } else {
        await reminders.save(
          type: ReminderOwnerType.event,
          ownerId: event.id,
          offsetMinutes: offset,
          now: now,
        );
      }
    });
    await coordinator.reconcile();
    return SaveResult.success;
  }

  Future<void> delete(String id) async {
    await unitOfWork.run(() async {
      await events.delete(id);
      await reminders.removeForOwner(ReminderOwnerType.event, id);
    });
    await coordinator.reconcile();
  }
}
