import 'package:material_ui/material_ui.dart';
import 'package:now_app/core/utils/formatters.dart';
import 'package:now_app/core/widgets/choice_chips.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Reminder offset picker: "no reminder" plus the standard offsets.
class ReminderChips extends StatelessWidget {
  const ReminderChips({
    super.key,
    required this.value,
    required this.onChanged,
  });

  final int? value;
  final void Function(int?) onChanged;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final options = <int?>[null, ...reminderOffsetChoices];
    return ChoiceChips<int?>(
      groupKey: 'reminder',
      value: value,
      options: [for (final o in options) (o, reminderLabel(l10n, o))],
      onSelected: onChanged,
    );
  }
}
