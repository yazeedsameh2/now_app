import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Asks for notification permission when a reminder is used. If the user
/// declines, explains (once, via a snackbar) that the reminder is saved but
/// will only fire after notifications are allowed in system settings.
Future<void> ensureNotificationPermission(
  WidgetRef ref,
  ScaffoldMessengerState messenger,
  AppLocalizations l10n,
) async {
  final service = ref.read(notificationServiceProvider);
  var granted = await service.permissionGranted();
  if (!granted) {
    granted = await service.requestPermission();
  }
  if (granted) {
    await ref.read(reminderCoordinatorProvider).reconcile();
  } else {
    messenger.showSnackBar(
      SnackBar(content: Text(l10n.notificationsDeniedHint)),
    );
  }
}
