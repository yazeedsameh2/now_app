import 'package:now_app/features/calendar/domain/event_repository.dart';
import 'package:now_app/features/reminders/domain/notification_service.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/domain/reminder_repository.dart';
import 'package:now_app/features/reminders/domain/reminder_texts.dart';
import 'package:now_app/features/tasks/domain/task_repository.dart';

/// Makes the operating system's scheduled notifications match the database.
///
/// The database is the source of truth. [reconcile] computes the notifications
/// that should exist, cancels every other pending one and (re)schedules the
/// rest by stable id, so edits, deletions and restarts never leave stale or
/// duplicate notifications behind.
class ReminderCoordinator {
  ReminderCoordinator({
    required this.tasks,
    required this.events,
    required this.reminders,
    required this.notifications,
    required this.texts,
    required this.clock,
    required this.isEnabled,
  });

  final TaskRepository tasks;
  final EventRepository events;
  final ReminderRepository reminders;
  final NotificationService notifications;
  final ReminderTexts texts;
  final DateTime Function() clock;
  final bool Function() isEnabled;

  Future<void> _tail = Future<void>.value();

  /// Serialized: concurrent calls run one after another. Best effort: a
  /// failing notification plugin must never break saving user data.
  Future<void> reconcile() {
    final next = _tail.then((_) => _run()).catchError((Object _) {});
    _tail = next;
    return next;
  }

  Future<void> _run() async {
    final planned = isEnabled()
        ? planNotifications(
            now: clock(),
            tasks: await tasks.getAll(),
            events: await events.getAll(),
            reminders: await reminders.getAll(),
          )
        : <PlannedNotification>[];

    final pending = await notifications.pendingIds();
    final wanted = planned.map((n) => n.id).toSet();
    for (final id in pending.difference(wanted)) {
      await notifications.cancel(id);
    }
    if (planned.isEmpty || !await notifications.permissionGranted()) {
      return;
    }
    for (final item in planned) {
      await notifications.schedule(
        ReminderNotification(
          id: item.id,
          title: item.title,
          body: texts.body(item),
          triggerAt: item.triggerAt,
        ),
      );
    }
  }
}
