import 'package:drift/drift.dart';
import 'package:now_app/database/app_database.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/domain/reminder_repository.dart';

class DriftReminderRepository implements ReminderRepository {
  DriftReminderRepository(this._db);

  final AppDatabase _db;

  Reminder _fromRow(ReminderRow row) {
    final type = ReminderOwnerType.values.asNameMap()[row.ownerType];
    return Reminder(
      id: row.id,
      ownerType: type ?? ReminderOwnerType.task,
      ownerId: row.ownerId,
      offsetMinutes: row.offsetMinutes,
      enabled: row.enabled,
    );
  }

  Future<ReminderRow?> _findRow(ReminderOwnerType type, String ownerId) {
    final query = _db.select(_db.reminders)
      ..where((r) => r.ownerType.equals(type.name) & r.ownerId.equals(ownerId));
    return query.getSingleOrNull();
  }

  @override
  Future<List<Reminder>> getAll() async {
    final rows = await _db.select(_db.reminders).get();
    return rows.map(_fromRow).toList();
  }

  @override
  Future<Reminder?> getForOwner(ReminderOwnerType type, String ownerId) async {
    final row = await _findRow(type, ownerId);
    return row == null ? null : _fromRow(row);
  }

  @override
  Future<Reminder> save({
    required ReminderOwnerType type,
    required String ownerId,
    required int offsetMinutes,
    required DateTime now,
  }) async {
    final existing = await _findRow(type, ownerId);
    if (existing != null) {
      await (_db.update(_db.reminders)..where((r) => r.id.equals(existing.id)))
          .write(
            RemindersCompanion(
              offsetMinutes: Value(offsetMinutes),
              enabled: const Value(true),
              updatedAt: Value(now),
            ),
          );
      return Reminder(
        id: existing.id,
        ownerType: type,
        ownerId: ownerId,
        offsetMinutes: offsetMinutes,
      );
    }
    final id = await _db
        .into(_db.reminders)
        .insert(
          RemindersCompanion.insert(
            ownerType: type.name,
            ownerId: ownerId,
            offsetMinutes: offsetMinutes,
            createdAt: now,
            updatedAt: now,
          ),
        );
    return Reminder(
      id: id,
      ownerType: type,
      ownerId: ownerId,
      offsetMinutes: offsetMinutes,
    );
  }

  @override
  Future<void> removeForOwner(ReminderOwnerType type, String ownerId) async {
    await (_db.delete(_db.reminders)..where(
          (r) => r.ownerType.equals(type.name) & r.ownerId.equals(ownerId),
        ))
        .go();
  }

  @override
  Future<void> deleteAll() async {
    await _db.delete(_db.reminders).go();
  }
}
