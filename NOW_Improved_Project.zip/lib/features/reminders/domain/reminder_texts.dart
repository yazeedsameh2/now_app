import 'package:now_app/features/reminders/domain/reminder.dart';

/// Produces the localized notification body. Implemented in the app layer so
/// the domain stays free of Flutter localization types.
abstract interface class ReminderTexts {
  String body(PlannedNotification notification);
}
