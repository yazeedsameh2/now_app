import 'package:now_app/features/reminders/domain/reminder.dart';

abstract interface class ReminderRepository {
  Future<List<Reminder>> getAll();

  Future<Reminder?> getForOwner(ReminderOwnerType type, String ownerId);

  /// Creates or updates the single reminder of an owner (enabled).
  Future<Reminder> save({
    required ReminderOwnerType type,
    required String ownerId,
    required int offsetMinutes,
    required DateTime now,
  });

  Future<void> removeForOwner(ReminderOwnerType type, String ownerId);

  Future<void> deleteAll();
}
