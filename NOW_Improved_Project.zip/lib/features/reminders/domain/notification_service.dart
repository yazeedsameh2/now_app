/// A fully formed notification ready to hand to the operating system.
class ReminderNotification {
  const ReminderNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.triggerAt,
  });

  final int id;
  final String title;
  final String body;
  final DateTime triggerAt;
}

/// Device capability: local notifications. Plugins stay behind this interface.
abstract interface class NotificationService {
  Future<void> initialize();

  /// Whether the OS currently lets the app post notifications.
  Future<bool> permissionGranted();

  /// Asks the user for permission; returns whether it was granted.
  Future<bool> requestPermission();

  /// Schedules (or replaces, by id) one notification.
  Future<void> schedule(ReminderNotification notification);

  Future<void> cancel(int id);

  Future<Set<int>> pendingIds();
}

/// Used where no real notification support exists (tests, unsupported OS).
class NoopNotificationService implements NotificationService {
  @override
  Future<void> initialize() async {}

  @override
  Future<bool> permissionGranted() async => false;

  @override
  Future<bool> requestPermission() async => false;

  @override
  Future<void> schedule(ReminderNotification notification) async {}

  @override
  Future<void> cancel(int id) async {}

  @override
  Future<Set<int>> pendingIds() async => <int>{};
}
