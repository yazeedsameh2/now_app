import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/tasks/domain/task.dart';

enum ReminderOwnerType { task, event }

/// A reminder attached to one task or event. [id] doubles as the stable
/// notification identifier, so it is unique and never reused.
class Reminder {
  const Reminder({
    required this.id,
    required this.ownerType,
    required this.ownerId,
    required this.offsetMinutes,
    this.enabled = true,
  });

  final int id;
  final ReminderOwnerType ownerType;
  final String ownerId;

  /// Minutes before the item's start/due time. Zero means "at time".
  final int offsetMinutes;
  final bool enabled;
}

/// Offsets offered in the UI, in minutes before the item.
const List<int> reminderOffsetChoices = [0, 5, 15, 30, 60, 1440];

/// Date-only tasks are reminded at 09:00 local time on their due date.
const int defaultTaskReminderMinutes = 9 * 60;

/// The moment a task reminder is measured from; null when the task has no date.
DateTime? taskReminderBase(Task task) {
  final date = task.dueDate;
  if (date == null) {
    return null;
  }
  return atMinutes(date, task.dueMinutes ?? defaultTaskReminderMinutes);
}

DateTime reminderTrigger(DateTime base, int offsetMinutes) {
  return base.subtract(Duration(minutes: offsetMinutes));
}

/// A notification that should currently be scheduled.
class PlannedNotification {
  const PlannedNotification({
    required this.id,
    required this.triggerAt,
    required this.ownerType,
    required this.ownerId,
    required this.title,
    required this.itemStart,
    required this.isDateOnlyTask,
  });

  final int id;
  final DateTime triggerAt;
  final ReminderOwnerType ownerType;
  final String ownerId;
  final String title;
  final DateTime itemStart;
  final bool isDateOnlyTask;
}

/// Pure function: which notifications should exist right now.
///
/// Skips disabled reminders, missing owners, completed tasks and triggers that
/// are not in the future. The result is sorted by trigger time and capped to
/// [limit] (iOS keeps only 64 pending notifications).
List<PlannedNotification> planNotifications({
  required DateTime now,
  required List<Task> tasks,
  required List<Event> events,
  required List<Reminder> reminders,
  int limit = 60,
}) {
  final tasksById = {for (final task in tasks) task.id: task};
  final eventsById = {for (final event in events) event.id: event};
  final result = <PlannedNotification>[];

  for (final reminder in reminders) {
    if (!reminder.enabled) {
      continue;
    }
    if (reminder.ownerType == ReminderOwnerType.task) {
      final task = tasksById[reminder.ownerId];
      final base = task == null ? null : taskReminderBase(task);
      if (task == null || task.isCompleted || base == null) {
        continue;
      }
      final trigger = reminderTrigger(base, reminder.offsetMinutes);
      if (trigger.isAfter(now)) {
        result.add(
          PlannedNotification(
            id: reminder.id,
            triggerAt: trigger,
            ownerType: reminder.ownerType,
            ownerId: reminder.ownerId,
            title: task.title,
            itemStart: base,
            isDateOnlyTask: !task.hasDueTime,
          ),
        );
      }
    } else {
      final event = eventsById[reminder.ownerId];
      if (event == null) {
        continue;
      }
      final trigger = reminderTrigger(event.startsAt, reminder.offsetMinutes);
      if (trigger.isAfter(now)) {
        result.add(
          PlannedNotification(
            id: reminder.id,
            triggerAt: trigger,
            ownerType: reminder.ownerType,
            ownerId: reminder.ownerId,
            title: event.title,
            itemStart: event.startsAt,
            isDateOnlyTask: false,
          ),
        );
      }
    }
  }
  result.sort((a, b) => a.triggerAt.compareTo(b.triggerAt));
  return result.take(limit).toList();
}
