/// Built-in categories shared by tasks and events. Stored by name.
enum ItemCategory { work, study, personal, health, home, errands }

ItemCategory? categoryFromName(String? name) {
  if (name == null) {
    return null;
  }
  return ItemCategory.values.asNameMap()[name];
}
