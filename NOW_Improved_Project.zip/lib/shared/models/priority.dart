/// Task priority. The enum index is persisted, so never reorder values.
enum Priority { low, medium, high }

Priority priorityFromIndex(int index) {
  if (index >= 0 && index < Priority.values.length) {
    return Priority.values[index];
  }
  return Priority.medium;
}
