import 'dart:ui';

import 'package:intl/intl.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/domain/reminder_texts.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Localizes notification text outside the widget tree, using the language
/// the user selected in settings (or the device language).
class L10nReminderTexts implements ReminderTexts {
  L10nReminderTexts(this._settings);

  final AppSettings Function() _settings;

  Locale _locale() {
    switch (_settings().language) {
      case AppLanguage.arabic:
        return const Locale('ar');
      case AppLanguage.english:
        return const Locale('en');
      case AppLanguage.system:
        final device = PlatformDispatcher.instance.locale;
        final supported = AppLocalizations.supportedLocales.any(
          (locale) => locale.languageCode == device.languageCode,
        );
        return supported ? Locale(device.languageCode) : const Locale('en');
    }
  }

  @override
  String body(PlannedNotification notification) {
    final locale = _locale();
    final l10n = lookupAppLocalizations(locale);
    if (notification.isDateOnlyTask) {
      return l10n.reminderTaskDayBody;
    }
    final time = DateFormat.jm(locale.toString()).format(notification.itemStart);
    if (notification.ownerType == ReminderOwnerType.event) {
      return l10n.reminderEventBody(time);
    }
    return l10n.reminderTaskBody(time);
  }
}
