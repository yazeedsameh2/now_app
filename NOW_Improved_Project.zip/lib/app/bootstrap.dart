import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:now_app/app/app.dart';
import 'package:now_app/app/providers.dart';
import 'package:now_app/database/app_database.dart';
import 'package:now_app/features/reminders/data/local_notification_service.dart';
import 'package:now_app/features/reminders/domain/notification_service.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/data/shared_preferences_settings_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting();
  final prefs = await SharedPreferences.getInstance();

  // A notification plugin failure must never stop the app from starting.
  NotificationService notifications = LocalNotificationService();
  try {
    await notifications.initialize();
  } on Object {
    notifications = NoopNotificationService();
  }

  runApp(
    ProviderScope(
      overrides: [
        settingsRepositoryProvider.overrideWithValue(
          SharedPreferencesSettingsRepository(prefs),
        ),
        appDatabaseProvider.overrideWith((ref) {
          final database = AppDatabase.open();
          ref.onDispose(database.close);
          return database;
        }),
        notificationServiceProvider.overrideWithValue(notifications),
      ],
      child: const NowApp(),
    ),
  );
}
