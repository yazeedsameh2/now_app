import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:now_app/app/app_shell.dart';
import 'package:now_app/app/routes.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/features/calendar/presentation/calendar_screen.dart';
import 'package:now_app/features/calendar/presentation/event_form_screen.dart';
import 'package:now_app/features/daily_review/presentation/daily_review_screen.dart';
import 'package:now_app/features/dashboard/presentation/dashboard_screen.dart';
import 'package:now_app/features/onboarding/presentation/onboarding_screen.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/settings/presentation/settings_screen.dart';
import 'package:now_app/features/tasks/presentation/task_form_screen.dart';
import 'package:now_app/features/tasks/presentation/tasks_screen.dart';

StatefulShellBranch _branch(
  String path,
  Widget Function(BuildContext, GoRouterState) builder,
) {
  return StatefulShellBranch(
    routes: [GoRoute(path: path, builder: builder)],
  );
}

DateTime? _dateParam(GoRouterState state) {
  return parseDateKey(state.uri.queryParameters['date']);
}

final routerProvider = Provider<GoRouter>((ref) {
  // Lets the router re-run `redirect` when onboarding completes.
  final refresh = ValueNotifier<int>(0);
  ref.listen(
    settingsControllerProvider.select((s) => s.onboardingDone),
    (previous, next) => refresh.value++,
  );

  final router = GoRouter(
    initialLocation: AppRoutes.home,
    refreshListenable: refresh,
    redirect: (context, state) {
      final done = ref.read(settingsControllerProvider).onboardingDone;
      final onOnboarding = state.matchedLocation == AppRoutes.onboarding;
      if (!done && !onOnboarding) {
        return AppRoutes.onboarding;
      }
      if (done && onOnboarding) {
        return AppRoutes.home;
      }
      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.onboarding,
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/tasks/new',
        builder: (context, state) =>
            TaskFormScreen(initialDate: _dateParam(state)),
      ),
      GoRoute(
        path: '/tasks/:id',
        builder: (context, state) =>
            TaskFormScreen(taskId: state.pathParameters['id']),
      ),
      GoRoute(
        path: '/events/new',
        builder: (context, state) =>
            EventFormScreen(initialDate: _dateParam(state)),
      ),
      GoRoute(
        path: '/events/:id',
        builder: (context, state) =>
            EventFormScreen(eventId: state.pathParameters['id']),
      ),
      GoRoute(
        path: '/review',
        builder: (context, state) =>
            DailyReviewScreen(date: _dateParam(state)),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => AppShell(navigationShell: shell),
        branches: [
          _branch(AppRoutes.home, (context, state) => const DashboardScreen()),
          _branch(AppRoutes.tasks, (context, state) => const TasksScreen()),
          _branch(
            AppRoutes.calendar,
            (context, state) => const CalendarScreen(),
          ),
          _branch(
            AppRoutes.settings,
            (context, state) => const SettingsScreen(),
          ),
        ],
      ),
    ],
  );
  ref.onDispose(() {
    router.dispose();
    refresh.dispose();
  });
  return router;
});
