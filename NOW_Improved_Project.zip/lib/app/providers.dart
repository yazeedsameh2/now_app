import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:now_app/app/l10n_reminder_texts.dart';
import 'package:now_app/core/utils/clock.dart';
import 'package:now_app/core/utils/dates.dart';
import 'package:now_app/database/app_database.dart';
import 'package:now_app/database/drift_unit_of_work.dart';
import 'package:now_app/database/unit_of_work.dart';
import 'package:now_app/features/calendar/application/event_actions.dart';
import 'package:now_app/features/calendar/data/drift_event_repository.dart';
import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/calendar/domain/event_repository.dart';
import 'package:now_app/features/reminders/application/reminder_coordinator.dart';
import 'package:now_app/features/reminders/data/drift_reminder_repository.dart';
import 'package:now_app/features/reminders/domain/notification_service.dart';
import 'package:now_app/features/reminders/domain/reminder_repository.dart';
import 'package:now_app/features/reminders/domain/reminder_texts.dart';
import 'package:now_app/features/settings/application/data_reset_service.dart';
import 'package:now_app/features/settings/application/settings_controller.dart';
import 'package:now_app/features/tasks/application/task_actions.dart';
import 'package:now_app/features/tasks/data/drift_task_repository.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/domain/task_repository.dart';

/// Must be overridden at startup (see bootstrap).
final appDatabaseProvider = Provider<AppDatabase>(
  (ref) => throw UnimplementedError('Override appDatabaseProvider.'),
);

final unitOfWorkProvider = Provider<UnitOfWork>(
  (ref) => DriftUnitOfWork(ref.watch(appDatabaseProvider)),
);

final taskRepositoryProvider = Provider<TaskRepository>(
  (ref) => DriftTaskRepository(ref.watch(appDatabaseProvider)),
);

final eventRepositoryProvider = Provider<EventRepository>(
  (ref) => DriftEventRepository(ref.watch(appDatabaseProvider)),
);

final reminderRepositoryProvider = Provider<ReminderRepository>(
  (ref) => DriftReminderRepository(ref.watch(appDatabaseProvider)),
);

/// Overridden at startup with the real plugin-backed service.
final notificationServiceProvider = Provider<NotificationService>(
  (ref) => NoopNotificationService(),
);

final reminderTextsProvider = Provider<ReminderTexts>(
  (ref) => L10nReminderTexts(() => ref.read(settingsControllerProvider)),
);

final reminderCoordinatorProvider = Provider<ReminderCoordinator>((ref) {
  return ReminderCoordinator(
    tasks: ref.watch(taskRepositoryProvider),
    events: ref.watch(eventRepositoryProvider),
    reminders: ref.watch(reminderRepositoryProvider),
    notifications: ref.watch(notificationServiceProvider),
    texts: ref.watch(reminderTextsProvider),
    clock: ref.watch(clockProvider),
    isEnabled: () => ref.read(settingsControllerProvider).remindersEnabled,
  );
});

final taskActionsProvider = Provider<TaskActions>((ref) {
  return TaskActions(
    tasks: ref.watch(taskRepositoryProvider),
    reminders: ref.watch(reminderRepositoryProvider),
    unitOfWork: ref.watch(unitOfWorkProvider),
    coordinator: ref.watch(reminderCoordinatorProvider),
    clock: ref.watch(clockProvider),
  );
});

final eventActionsProvider = Provider<EventActions>((ref) {
  return EventActions(
    events: ref.watch(eventRepositoryProvider),
    reminders: ref.watch(reminderRepositoryProvider),
    unitOfWork: ref.watch(unitOfWorkProvider),
    coordinator: ref.watch(reminderCoordinatorProvider),
    clock: ref.watch(clockProvider),
  );
});

final dataResetServiceProvider = Provider<DataResetService>((ref) {
  return DataResetService(
    tasks: ref.watch(taskRepositoryProvider),
    events: ref.watch(eventRepositoryProvider),
    reminders: ref.watch(reminderRepositoryProvider),
    unitOfWork: ref.watch(unitOfWorkProvider),
    coordinator: ref.watch(reminderCoordinatorProvider),
  );
});

final tasksProvider = StreamProvider<List<Task>>(
  (ref) => ref.watch(taskRepositoryProvider).watchAll(),
);

final eventsProvider = StreamProvider<List<Event>>(
  (ref) => ref.watch(eventRepositoryProvider).watchAll(),
);

/// Emits the current time now and once a minute (for "next up" accuracy).
final currentTimeProvider = StreamProvider<DateTime>((ref) async* {
  final clock = ref.watch(clockProvider);
  yield clock();
  yield* Stream<DateTime>.periodic(const Duration(minutes: 1), (_) => clock());
});

/// Whether the OS currently allows notifications.
final notificationPermissionProvider = FutureProvider.autoDispose<bool>(
  (ref) => ref.watch(notificationServiceProvider).permissionGranted(),
);

/// The date shown in the calendar.
final selectedDateProvider = NotifierProvider<SelectedDateNotifier, DateTime>(
  SelectedDateNotifier.new,
);

class SelectedDateNotifier extends Notifier<DateTime> {
  @override
  DateTime build() => dateOnly(ref.read(clockProvider)());

  void select(DateTime date) {
    state = dateOnly(date);
  }
}
