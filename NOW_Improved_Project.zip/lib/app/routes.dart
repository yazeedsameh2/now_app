import 'package:now_app/core/utils/dates.dart';

/// Central route paths.
abstract final class AppRoutes {
  static const home = '/';
  static const tasks = '/tasks';
  static const calendar = '/calendar';
  static const settings = '/settings';
  static const onboarding = '/onboarding';

  static String newTask({DateTime? date}) => _withDate('/tasks/new', date);

  static String editTask(String id) => '/tasks/$id';

  static String newEvent({DateTime? date}) => _withDate('/events/new', date);

  static String editEvent(String id) => '/events/$id';

  static String review(DateTime date) => '/review?date=${dateKey(date)}';

  static String _withDate(String path, DateTime? date) {
    return date == null ? path : '$path?date=${dateKey(date)}';
  }
}
