import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/app/routes.dart';
import 'package:now_app/l10n/app_localizations.dart';

/// Bottom sheet that lets the user choose between a new task and a new event.
Future<void> showAddSheet(BuildContext context, {DateTime? date}) {
  final l10n = AppLocalizations.of(context);
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) {
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              key: const ValueKey('add-task'),
              leading: const Icon(Icons.check_circle_outline),
              title: Text(l10n.addTask),
              onTap: () {
                Navigator.of(sheetContext).pop();
                context.push(AppRoutes.newTask(date: date));
              },
            ),
            ListTile(
              key: const ValueKey('add-event'),
              leading: const Icon(Icons.event_outlined),
              title: Text(l10n.addEvent),
              onTap: () {
                Navigator.of(sheetContext).pop();
                context.push(AppRoutes.newEvent(date: date));
              },
            ),
          ],
        ),
      );
    },
  );
}
