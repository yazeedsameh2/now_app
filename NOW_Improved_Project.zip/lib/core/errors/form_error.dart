/// Validation problems a form can report. Messages live in the ARB files.
enum FormError {
  titleRequired,
  titleTooLong,
  timeWithoutDate,
  endNotAfterStart,
  reminderNeedsDate,
  reminderInPast,
}

/// Outcome of a save request: success or the set of problems found.
class SaveResult {
  const SaveResult(this.errors);

  static const success = SaveResult({});

  final Set<FormError> errors;

  bool get ok => errors.isEmpty;
}

const int maxTitleLength = 200;
