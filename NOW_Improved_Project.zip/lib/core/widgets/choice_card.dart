import 'package:material_ui/material_ui.dart';

/// A card of mutually exclusive choices, one tappable row per option.
class ChoiceCard<T> extends StatelessWidget {
  const ChoiceCard({
    super.key,
    required this.groupKey,
    required this.value,
    required this.options,
    required this.onSelected,
  });

  final String groupKey;
  final T value;
  final List<(T, String)> options;
  final void Function(T) onSelected;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: [
          for (final (option, label) in options)
            ListTile(
              key: ValueKey('$groupKey-$option'),
              title: Text(label),
              selected: option == value,
              trailing: option == value ? const Icon(Icons.check) : null,
              onTap: () => onSelected(option),
            ),
        ],
      ),
    );
  }
}
