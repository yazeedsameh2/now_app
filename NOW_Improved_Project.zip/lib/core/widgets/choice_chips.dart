import 'package:material_ui/material_ui.dart';
import 'package:now_app/core/theme/app_tokens.dart';

/// A wrapping row of single-select chips (used instead of dropdowns).
class ChoiceChips<T> extends StatelessWidget {
  const ChoiceChips({
    super.key,
    required this.groupKey,
    required this.value,
    required this.options,
    required this.onSelected,
  });

  final String groupKey;
  final T value;
  final List<(T, String)> options;
  final void Function(T) onSelected;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: AppSpacing.sm,
      runSpacing: AppSpacing.sm,
      children: [
        for (final (option, label) in options)
          ChoiceChip(
            key: ValueKey('$groupKey-$option'),
            label: Text(label),
            selected: option == value,
            onSelected: (_) => onSelected(option),
          ),
      ],
    );
  }
}
