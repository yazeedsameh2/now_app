import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Source of "now". Tests override it so date logic is deterministic.
final clockProvider = Provider<DateTime Function()>((ref) => DateTime.now);
