import 'dart:math';

final Random _random = Random.secure();

/// Random RFC 4122 version-4 identifier used for stable local IDs.
String newId() {
  final bytes = List<int>.generate(16, (_) => _random.nextInt(256));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  final hex = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  final a = hex.substring(0, 8);
  final b = hex.substring(8, 12);
  final c = hex.substring(12, 16);
  final d = hex.substring(16, 20);
  final e = hex.substring(20);
  return '$a-$b-$c-$d-$e';
}
