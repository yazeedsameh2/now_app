import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/l10n/app_localizations.dart';

String formErrorText(AppLocalizations l10n, FormError error) {
  switch (error) {
    case FormError.titleRequired:
      return l10n.errorTitleRequired;
    case FormError.titleTooLong:
      return l10n.errorTitleTooLong;
    case FormError.timeWithoutDate:
      return l10n.errorTimeWithoutDate;
    case FormError.endNotAfterStart:
      return l10n.errorEndNotAfterStart;
    case FormError.reminderNeedsDate:
      return l10n.errorReminderNeedsDate;
    case FormError.reminderInPast:
      return l10n.errorReminderInPast;
  }
}
