import 'package:intl/intl.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/l10n/app_localizations.dart';
import 'package:now_app/shared/models/item_category.dart';
import 'package:now_app/shared/models/priority.dart';

String formatDate(BuildContext context, DateTime date) {
  final locale = Localizations.localeOf(context).toString();
  return DateFormat.yMMMEd(locale).format(date);
}

String formatLongDate(BuildContext context, DateTime date) {
  final locale = Localizations.localeOf(context).toString();
  return DateFormat.yMMMMEEEEd(locale).format(date);
}

String formatShortDate(BuildContext context, DateTime date) {
  final locale = Localizations.localeOf(context).toString();
  return DateFormat.MMMEd(locale).format(date);
}

String formatTimeOfDay(BuildContext context, DateTime time) {
  return TimeOfDay.fromDateTime(time).format(context);
}

String formatMinutes(BuildContext context, int minutes) {
  return TimeOfDay(hour: minutes ~/ 60, minute: minutes % 60).format(context);
}

String priorityLabel(AppLocalizations l10n, Priority priority) {
  switch (priority) {
    case Priority.low:
      return l10n.priorityLow;
    case Priority.medium:
      return l10n.priorityMedium;
    case Priority.high:
      return l10n.priorityHigh;
  }
}

String categoryLabel(AppLocalizations l10n, ItemCategory category) {
  switch (category) {
    case ItemCategory.work:
      return l10n.categoryWork;
    case ItemCategory.study:
      return l10n.categoryStudy;
    case ItemCategory.personal:
      return l10n.categoryPersonal;
    case ItemCategory.health:
      return l10n.categoryHealth;
    case ItemCategory.home:
      return l10n.categoryHome;
    case ItemCategory.errands:
      return l10n.categoryErrands;
  }
}

String reminderLabel(AppLocalizations l10n, int? offsetMinutes) {
  switch (offsetMinutes) {
    case null:
      return l10n.reminderNone;
    case 0:
      return l10n.reminderAtTime;
    case 5:
      return l10n.reminder5;
    case 15:
      return l10n.reminder15;
    case 30:
      return l10n.reminder30;
    case 60:
      return l10n.reminder60;
    case 1440:
      return l10n.reminder1440;
    default:
      return l10n.reminderAtTime;
  }
}
