/// Spacing scale in logical pixels.
abstract final class AppSpacing {
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
}

/// Corner radii.
abstract final class AppRadius {
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 20;
}

/// Icon sizes.
abstract final class AppIconSize {
  static const double md = 24;
  static const double xl = 64;
}

/// Minimum touch target (Material guideline: 48dp).
abstract final class AppTouchTarget {
  static const double min = 48;
}
