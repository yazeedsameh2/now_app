import 'package:now_app/database/app_database.dart';
import 'package:now_app/database/unit_of_work.dart';

/// Runs the action inside a single SQLite transaction (rolled back on error).
class DriftUnitOfWork implements UnitOfWork {
  DriftUnitOfWork(this._db);

  final AppDatabase _db;

  @override
  Future<T> run<T>(Future<T> Function() action) => _db.transaction(action);
}
