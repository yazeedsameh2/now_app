/// Runs several repository writes atomically.
abstract interface class UnitOfWork {
  Future<T> run<T>(Future<T> Function() action);
}

/// For tests with in-memory repositories: no real transaction.
class PassthroughUnitOfWork implements UnitOfWork {
  @override
  Future<T> run<T>(Future<T> Function() action) => action();
}
