import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

part 'app_database.g.dart';

@DataClassName('TaskRow')
class Tasks extends Table {
  TextColumn get id => text()();

  TextColumn get title => text().withLength(min: 1, max: 200)();

  TextColumn get description => text().nullable()();

  /// Index of the Priority enum.
  IntColumn get priority => integer().withDefault(const Constant(1))();

  /// Local date as yyyy-MM-dd (date-only, never an instant).
  TextColumn get dueDate => text().nullable()();

  /// Minutes after local midnight.
  IntColumn get dueMinutes => integer().nullable()();

  TextColumn get category => text().nullable()();

  DateTimeColumn get completedAt => dateTime().nullable()();

  DateTimeColumn get createdAt => dateTime()();

  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column<Object>> get primaryKey => {id};
}

@DataClassName('EventRow')
class Events extends Table {
  TextColumn get id => text()();

  TextColumn get title => text().withLength(min: 1, max: 200)();

  TextColumn get description => text().nullable()();

  DateTimeColumn get startsAt => dateTime()();

  DateTimeColumn get endsAt => dateTime()();

  TextColumn get location => text().nullable()();

  TextColumn get category => text().nullable()();

  DateTimeColumn get createdAt => dateTime()();

  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column<Object>> get primaryKey => {id};
}

@DataClassName('ReminderRow')
class Reminders extends Table {
  /// Also used as the notification identifier. AUTOINCREMENT: never reused.
  IntColumn get id => integer().autoIncrement()();

  /// 'task' or 'event'.
  TextColumn get ownerType => text()();

  TextColumn get ownerId => text()();

  IntColumn get offsetMinutes => integer()();

  BoolColumn get enabled => boolean().withDefault(const Constant(true))();

  DateTimeColumn get createdAt => dateTime()();

  DateTimeColumn get updatedAt => dateTime()();

  @override
  List<Set<Column<Object>>> get uniqueKeys => [
    {ownerType, ownerId},
  ];
}

@DriftDatabase(tables: [Tasks, Events, Reminders])
class AppDatabase extends _$AppDatabase {
  AppDatabase(super.e);

  /// Opens the on-device database used by the app.
  AppDatabase.open() : super(driftDatabase(name: 'now_planner'));

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration {
    return MigrationStrategy(
      onCreate: (migrator) => migrator.createAll(),
      beforeOpen: (details) async {
        await customStatement('PRAGMA foreign_keys = ON');
      },
    );
  }
}
