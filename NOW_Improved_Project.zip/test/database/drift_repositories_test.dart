import 'dart:io';

import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/database/app_database.dart';
import 'package:now_app/database/drift_unit_of_work.dart';
import 'package:now_app/features/calendar/data/drift_event_repository.dart';
import 'package:now_app/features/reminders/data/drift_reminder_repository.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/tasks/data/drift_task_repository.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/shared/models/item_category.dart';
import 'package:now_app/shared/models/priority.dart';

import '../support/test_data.dart';

AppDatabase memoryDb() => AppDatabase(NativeDatabase.memory());

void main() {
  group('tasks', () {
    test('create, read, update, complete, delete', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftTaskRepository(db);
      final task = makeTask(
        'a',
        'Pay rent',
        priority: Priority.high,
        dueDate: DateTime(2026, 12, 1),
        dueMinutes: 9 * 60 + 30,
      );

      await repo.upsert(task);
      final loaded = await repo.getById('a');
      expect(loaded, isNotNull);
      expect(loaded!.title, 'Pay rent');
      expect(loaded.priority, Priority.high);
      expect(loaded.dueDate, DateTime(2026, 12, 1));
      expect(loaded.dueMinutes, 570);
      expect(loaded.isCompleted, isFalse);

      await repo.upsert(loaded.withCompletion(testNow, testNow));
      expect((await repo.getById('a'))!.isCompleted, isTrue);

      await repo.delete('a');
      expect(await repo.getById('a'), isNull);
      expect(await repo.getAll(), isEmpty);
    });

    test('a date-only task keeps no time', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftTaskRepository(db);

      await repo.upsert(makeTask('a', 'Milk', dueDate: testToday));
      final loaded = (await repo.getById('a'))!;

      expect(loaded.dueDate, testToday);
      expect(loaded.dueMinutes, isNull);
      expect(loaded.hasDueTime, isFalse);
    });

    test('optional fields round-trip as null', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftTaskRepository(db);

      await repo.upsert(makeTask('a', 'Bare'));
      final loaded = (await repo.getById('a'))!;

      expect(loaded.description, isNull);
      expect(loaded.dueDate, isNull);
      expect(loaded.category, isNull);
      expect(loaded.completedAt, isNull);
    });

    test('category and description are stored', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftTaskRepository(db);

      await repo.upsert(
        Task(
          id: 'a',
          title: 'Study',
          description: 'Chapter 3',
          priority: Priority.low,
          category: ItemCategory.study,
          createdAt: testNow,
          updatedAt: testNow,
        ),
      );
      final loaded = (await repo.getById('a'))!;

      expect(loaded.category, ItemCategory.study);
      expect(loaded.description, 'Chapter 3');
      expect(loaded.priority, Priority.low);
    });

    test('watchAll emits again after a write', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftTaskRepository(db);

      final emissions = <List<Task>>[];
      final subscription = repo.watchAll().listen(emissions.add);
      addTearDown(subscription.cancel);

      await Future<void>.delayed(const Duration(milliseconds: 100));
      expect(emissions, isNotEmpty);
      expect(emissions.last, isEmpty);

      await repo.upsert(makeTask('a', 'A'));
      await Future<void>.delayed(const Duration(milliseconds: 100));

      expect(emissions.last, hasLength(1));
      expect(emissions.last.single.id, 'a');
    });
  });

  group('events', () {
    test('create, read, update, delete keep instants intact', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftEventRepository(db);
      final event = makeEvent('e', 'Meeting', at(10), at(11), location: 'HQ');

      await repo.upsert(event);
      final loaded = (await repo.getById('e'))!;
      expect(loaded.startsAt, at(10));
      expect(loaded.endsAt, at(11));
      expect(loaded.location, 'HQ');

      await repo.upsert(makeEvent('e', 'Meeting v2', at(12), at(13)));
      final updated = (await repo.getById('e'))!;
      expect(updated.title, 'Meeting v2');
      expect(updated.location, isNull);
      expect(await repo.getAll(), hasLength(1));

      await repo.delete('e');
      expect(await repo.getAll(), isEmpty);
    });
  });

  group('reminders', () {
    test('one reminder per owner; updating keeps the same id', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftReminderRepository(db);

      final first = await repo.save(
        type: ReminderOwnerType.task,
        ownerId: 'a',
        offsetMinutes: 15,
        now: testNow,
      );
      final second = await repo.save(
        type: ReminderOwnerType.task,
        ownerId: 'a',
        offsetMinutes: 60,
        now: testNow,
      );

      expect(second.id, first.id);
      final all = await repo.getAll();
      expect(all, hasLength(1));
      expect(all.single.offsetMinutes, 60);
    });

    test('different owners get different ids, ids are never reused', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final repo = DriftReminderRepository(db);

      final a = await repo.save(
        type: ReminderOwnerType.task,
        ownerId: 'a',
        offsetMinutes: 0,
        now: testNow,
      );
      final b = await repo.save(
        type: ReminderOwnerType.event,
        ownerId: 'a',
        offsetMinutes: 0,
        now: testNow,
      );
      expect(a.id, isNot(b.id));

      await repo.removeForOwner(ReminderOwnerType.event, 'a');
      final c = await repo.save(
        type: ReminderOwnerType.event,
        ownerId: 'a',
        offsetMinutes: 0,
        now: testNow,
      );
      expect(c.id, greaterThan(b.id));
      expect(await repo.getForOwner(ReminderOwnerType.task, 'a'), isNotNull);
    });
  });

  group('transactions', () {
    test('a failing unit of work rolls back every write', () async {
      final db = memoryDb();
      addTearDown(db.close);
      final tasks = DriftTaskRepository(db);
      final reminders = DriftReminderRepository(db);

      await expectLater(
        DriftUnitOfWork(db).run(() async {
          await tasks.upsert(makeTask('a', 'A'));
          await reminders.save(
            type: ReminderOwnerType.task,
            ownerId: 'a',
            offsetMinutes: 0,
            now: testNow,
          );
          throw StateError('boom');
        }),
        throwsStateError,
      );

      expect(await tasks.getAll(), isEmpty);
      expect(await reminders.getAll(), isEmpty);
    });
  });

  group('persistence', () {
    test('data survives closing and reopening the database file', () async {
      final dir = Directory.systemTemp.createTempSync('now_db_test');
      addTearDown(() => dir.deleteSync(recursive: true));
      final file = File('${dir.path}/planner.sqlite');

      final first = AppDatabase(NativeDatabase(file));
      await DriftTaskRepository(first).upsert(
        makeTask('a', 'Persistent', dueDate: testToday, dueMinutes: 600),
      );
      await DriftEventRepository(first).upsert(
        makeEvent('e', 'Persistent event', at(10), at(11)),
      );
      await first.close();

      final second = AppDatabase(NativeDatabase(file));
      addTearDown(second.close);
      final task = await DriftTaskRepository(second).getById('a');
      final event = await DriftEventRepository(second).getById('e');

      expect(task?.title, 'Persistent');
      expect(task?.dueMinutes, 600);
      expect(event?.title, 'Persistent event');
    });
  });
}
