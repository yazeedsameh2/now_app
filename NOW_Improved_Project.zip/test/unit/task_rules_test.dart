import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/features/tasks/domain/task_rules.dart';
import 'package:now_app/shared/models/priority.dart';

import '../support/test_data.dart';

void main() {
  group('validateTaskFields', () {
    test('accepts a normal task', () {
      expect(validateTaskFields(title: 'Pay rent'), isEmpty);
    });

    test('requires a non-blank title', () {
      expect(validateTaskFields(title: ''), {FormError.titleRequired});
      expect(validateTaskFields(title: '   '), {FormError.titleRequired});
    });

    test('rejects an overlong title', () {
      expect(
        validateTaskFields(title: 'x' * (maxTitleLength + 1)),
        {FormError.titleTooLong},
      );
    });

    test('a time without a date is contradictory', () {
      expect(
        validateTaskFields(title: 'a', dueMinutes: 600),
        {FormError.timeWithoutDate},
      );
      expect(
        validateTaskFields(title: 'a', dueDate: testToday, dueMinutes: 600),
        isEmpty,
      );
    });
  });

  group('compareTasks', () {
    test('pending tasks come before completed ones', () {
      final pending = makeTask('a', 'A');
      final done = makeTask('b', 'B', completedAt: testNow);
      final sorted = [done, pending]
        ..sort((x, y) => compareTasks(x, y, TaskSort.dueDate));
      expect(sorted.first.id, 'a');
    });

    test('sorts by due date then time, undated last', () {
      final late = makeTask('late', 'L', dueDate: DateTime(2026, 11, 27));
      final early = makeTask(
        'early',
        'E',
        dueDate: DateTime(2026, 11, 26),
        dueMinutes: 600,
      );
      final earlier = makeTask(
        'earlier',
        'D',
        dueDate: DateTime(2026, 11, 26),
        dueMinutes: 480,
      );
      final undated = makeTask('undated', 'U');
      final sorted = [undated, late, early, earlier]
        ..sort((x, y) => compareTasks(x, y, TaskSort.dueDate));
      expect(sorted.map((t) => t.id), ['earlier', 'early', 'late', 'undated']);
    });

    test('priority sort puts high first and breaks ties by due date', () {
      final low = makeTask('low', 'A', priority: Priority.low);
      final highLate = makeTask(
        'highLate',
        'B',
        priority: Priority.high,
        dueDate: DateTime(2026, 12),
      );
      final highSoon = makeTask(
        'highSoon',
        'C',
        priority: Priority.high,
        dueDate: DateTime(2026, 11, 26),
      );
      final sorted = [low, highLate, highSoon]
        ..sort((x, y) => compareTasks(x, y, TaskSort.priority));
      expect(sorted.map((t) => t.id), ['highSoon', 'highLate', 'low']);
    });
  });

  group('matchesFilter and overdueTasks', () {
    final today = makeTask('today', 'T', dueDate: testToday);
    final done = makeTask('done', 'D', dueDate: testToday, completedAt: testNow);
    final old = makeTask('old', 'O', dueDate: DateTime(2026, 11, 20));
    final oldDone = makeTask(
      'oldDone',
      'OD',
      dueDate: DateTime(2026, 11, 20),
      completedAt: testNow,
    );
    final future = makeTask('future', 'F', dueDate: DateTime(2026, 12, 1));
    final all = [today, done, old, oldDone, future];

    test('filters', () {
      List<String> ids(TaskFilter f) => all
          .where((t) => matchesFilter(t, f, testToday))
          .map((t) => t.id)
          .toList();
      expect(ids(TaskFilter.pending), ['today', 'old', 'future']);
      expect(ids(TaskFilter.today), ['today', 'done']);
      expect(ids(TaskFilter.completed), ['done', 'oldDone']);
      expect(ids(TaskFilter.all), hasLength(5));
    });

    test('overdue means pending and due before today', () {
      expect(overdueTasks(all, testToday).map((t) => t.id), ['old']);
    });
  });

  test('dueAt is only set when a date and a time exist', () {
    expect(makeTask('a', 'A').dueAt, isNull);
    expect(makeTask('a', 'A', dueDate: testToday).dueAt, isNull);
    expect(
      makeTask('a', 'A', dueDate: testToday, dueMinutes: 90).dueAt,
      DateTime(2026, 11, 25, 1, 30),
    );
  });
}
