import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/tasks/application/task_actions.dart';
import 'package:now_app/shared/models/priority.dart';

import '../support/services.dart';
import '../support/test_data.dart';

void main() {
  TaskDraft draft({
    String title = 'Call mom',
    DateTime? dueDate,
    int? dueMinutes,
    int? reminder,
  }) {
    return TaskDraft(
      title: title,
      priority: Priority.high,
      dueDate: dueDate,
      dueMinutes: dueMinutes,
      reminderOffset: reminder,
    );
  }

  test('creates a task with trimmed fields and no reminder', () async {
    final s = Services();

    final result = await s.taskActions.save(draft(title: '  Call mom  '));

    expect(result.ok, isTrue);
    final saved = s.tasks.all.single;
    expect(saved.title, 'Call mom');
    expect(saved.priority, Priority.high);
    expect(saved.createdAt, testNow);
    expect(s.reminders.items, isEmpty);
  });

  test('blank title is rejected and nothing is stored', () async {
    final s = Services();

    final result = await s.taskActions.save(draft(title: '  '));

    expect(result.errors, {FormError.titleRequired});
    expect(s.tasks.all, isEmpty);
  });

  test('a reminder without a date is rejected', () async {
    final s = Services();

    final result = await s.taskActions.save(draft(reminder: 15));

    expect(result.errors, {FormError.reminderNeedsDate});
    expect(s.tasks.all, isEmpty);
  });

  test('a reminder time in the past is rejected for new tasks', () async {
    final s = Services();

    final result = await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 9 * 60 + 10, reminder: 30),
    );

    expect(result.errors, {FormError.reminderInPast});
    expect(s.tasks.all, isEmpty);
  });

  test('saving with a reminder schedules exactly one notification', () async {
    final s = Services();

    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 30),
    );

    final task = s.tasks.all.single;
    expect(s.reminders.items.single.ownerId, task.id);
    expect(s.notifications.scheduled, hasLength(1));
    expect(s.notifications.scheduled.values.single.triggerAt, at(13, 30));
    expect(s.notifications.scheduled.values.single.title, 'Call mom');
  });

  test('editing the reminder replaces the notification (no duplicates)',
      () async {
    final s = Services();
    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 30),
    );
    final task = s.tasks.all.single;

    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 60),
      existing: task,
      previousReminderOffset: 30,
    );

    expect(s.reminders.items, hasLength(1));
    expect(s.notifications.scheduled, hasLength(1));
    expect(s.notifications.scheduled.values.single.triggerAt, at(13));
  });

  test('removing the reminder cancels the notification', () async {
    final s = Services();
    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 30),
    );
    final task = s.tasks.all.single;

    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60),
      existing: task,
      previousReminderOffset: 30,
    );

    expect(s.reminders.items, isEmpty);
    expect(s.notifications.scheduled, isEmpty);
  });

  test('completing a task cancels its reminder; reopening restores it',
      () async {
    final s = Services();
    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 30),
    );
    final task = s.tasks.all.single;

    await s.taskActions.setCompleted(task, completed: true);
    expect(s.tasks.all.single.isCompleted, isTrue);
    expect(s.notifications.scheduled, isEmpty);

    await s.taskActions.setCompleted(s.tasks.all.single, completed: false);
    expect(s.tasks.all.single.isCompleted, isFalse);
    expect(s.notifications.scheduled, hasLength(1));
  });

  test('deleting a task removes its reminder and notification', () async {
    final s = Services();
    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 30),
    );
    final task = s.tasks.all.single;

    await s.taskActions.delete(task.id);

    expect(s.tasks.all, isEmpty);
    expect(s.reminders.items, isEmpty);
    expect(s.notifications.scheduled, isEmpty);
  });

  test('editing an old task is not blocked by a passed reminder time',
      () async {
    final s = Services();
    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 30),
    );
    final task = s.tasks.all.single;
    s.clockValue = at(14, 10);

    final result = await s.taskActions.save(
      draft(
        title: 'Call mom now',
        dueDate: testToday,
        dueMinutes: 14 * 60,
        reminder: 30,
      ),
      existing: task,
      previousReminderOffset: 30,
    );

    expect(result.ok, isTrue);
    expect(s.tasks.all.single.title, 'Call mom now');
    expect(s.notifications.scheduled, isEmpty);
  });

  test('moveToDate changes only the date and keeps the time', () async {
    final s = Services();
    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60),
    );
    final task = s.tasks.all.single;

    await s.taskActions.moveToDate([task], DateTime(2026, 11, 26, 15));

    final moved = s.tasks.all.single;
    expect(moved.dueDate, DateTime(2026, 11, 26));
    expect(moved.dueMinutes, 14 * 60);
  });

  test('reminder owner type is task for task reminders', () async {
    final s = Services();
    await s.taskActions.save(
      draft(dueDate: testToday, dueMinutes: 14 * 60, reminder: 0),
    );
    expect(s.reminders.items.single.ownerType, ReminderOwnerType.task);
  });
}
