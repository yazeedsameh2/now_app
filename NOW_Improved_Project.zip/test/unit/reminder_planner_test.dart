import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';

import '../support/test_data.dart';

Reminder reminder(
  int id,
  ReminderOwnerType type,
  String ownerId,
  int offset, {
  bool enabled = true,
}) {
  return Reminder(
    id: id,
    ownerType: type,
    ownerId: ownerId,
    offsetMinutes: offset,
    enabled: enabled,
  );
}

void main() {
  final timedTask = makeTask(
    'task',
    'Report',
    dueDate: testToday,
    dueMinutes: 14 * 60,
  );
  final dateOnlyTask = makeTask('dateonly', 'Milk', dueDate: DateTime(2026, 11, 27));
  final event = makeEvent('event', 'Meeting', at(15), at(16));

  List<PlannedNotification> plan(
    List<Reminder> reminders, {
    DateTime? now,
  }) {
    return planNotifications(
      now: now ?? testNow,
      tasks: [timedTask, dateOnlyTask],
      events: [event],
      reminders: reminders,
    );
  }

  test('task reminder fires before the due time by the offset', () {
    final result = plan([reminder(1, ReminderOwnerType.task, 'task', 30)]);
    expect(result.single.triggerAt, at(13, 30));
    expect(result.single.title, 'Report');
    expect(result.single.isDateOnlyTask, isFalse);
  });

  test('date-only task reminds at 09:00 on the due date', () {
    final result = plan([reminder(1, ReminderOwnerType.task, 'dateonly', 0)]);
    expect(result.single.triggerAt, DateTime(2026, 11, 27, 9));
    expect(result.single.isDateOnlyTask, isTrue);
  });

  test('event reminder uses the event start', () {
    final result = plan([reminder(1, ReminderOwnerType.event, 'event', 15)]);
    expect(result.single.triggerAt, at(14, 45));
    expect(result.single.itemStart, at(15));
  });

  test('skips disabled reminders, missing owners and completed tasks', () {
    final completed = makeTask(
      'c',
      'Done',
      dueDate: testToday,
      dueMinutes: 1000,
      completedAt: testNow,
    );
    final result = planNotifications(
      now: testNow,
      tasks: [timedTask, completed],
      events: const [],
      reminders: [
        reminder(1, ReminderOwnerType.task, 'task', 0, enabled: false),
        reminder(2, ReminderOwnerType.task, 'ghost', 0),
        reminder(3, ReminderOwnerType.task, 'c', 0),
        reminder(4, ReminderOwnerType.event, 'ghost', 0),
      ],
    );
    expect(result, isEmpty);
  });

  test('skips triggers that are not in the future', () {
    final result = plan(
      [reminder(1, ReminderOwnerType.task, 'task', 0)],
      now: at(14),
    );
    expect(result, isEmpty);
  });

  test('result is sorted by trigger time and capped', () {
    final reminders = [
      reminder(1, ReminderOwnerType.event, 'event', 0),
      reminder(2, ReminderOwnerType.task, 'task', 0),
    ];
    final sorted = plan(reminders);
    expect(sorted.map((n) => n.id), [2, 1]);
    final capped = planNotifications(
      now: testNow,
      tasks: [timedTask],
      events: [event],
      reminders: reminders,
      limit: 1,
    );
    expect(capped.single.id, 2);
  });

  test('notification id is the reminder id (stable identifier)', () {
    final result = plan([reminder(42, ReminderOwnerType.task, 'task', 0)]);
    expect(result.single.id, 42);
  });
}
