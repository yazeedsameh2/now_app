import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/features/calendar/domain/event_rules.dart';

import '../support/test_data.dart';

void main() {
  test('valid event has no errors', () {
    expect(
      validateEventFields(title: 'Meet', startsAt: at(9), endsAt: at(10)),
      isEmpty,
    );
  });

  test('end must be strictly after start', () {
    expect(
      validateEventFields(title: 'Meet', startsAt: at(10), endsAt: at(10)),
      {FormError.endNotAfterStart},
    );
    expect(
      validateEventFields(title: 'Meet', startsAt: at(10), endsAt: at(9)),
      {FormError.endNotAfterStart},
    );
  });

  test('title rules apply to events too', () {
    expect(
      validateEventFields(title: ' ', startsAt: at(9), endsAt: at(10)),
      {FormError.titleRequired},
    );
  });

  test('touching events do not overlap, nested and partial ones do', () {
    final a = makeEvent('a', 'A', at(9), at(10));
    final touching = makeEvent('b', 'B', at(10), at(11));
    final partial = makeEvent('c', 'C', at(9, 30), at(10, 30));
    final nested = makeEvent('d', 'D', at(9, 15), at(9, 45));
    expect(a.overlaps(touching), isFalse);
    expect(touching.overlaps(a), isFalse);
    expect(a.overlaps(partial), isTrue);
    expect(a.overlaps(nested), isTrue);
  });
}
