import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/core/utils/dates.dart';

void main() {
  test('addDays moves whole calendar days across month and year ends', () {
    expect(addDays(DateTime(2026, 11, 30), 1), DateTime(2026, 12));
    expect(addDays(DateTime(2026, 12, 31), 1), DateTime(2027));
    expect(addDays(DateTime(2026, 3, 1), -1), DateTime(2026, 2, 28));
  });

  test('atMinutes builds wall-clock time on the given date', () {
    expect(atMinutes(DateTime(2026, 11, 25), 14 * 60 + 30), at(14, 30));
  });

  test('startOfWeek honors the first weekday', () {
    final wednesday = DateTime(2026, 11, 25);
    expect(startOfWeek(wednesday, DateTime.saturday), DateTime(2026, 11, 21));
    expect(startOfWeek(wednesday, DateTime.sunday), DateTime(2026, 11, 22));
    expect(startOfWeek(wednesday, DateTime.monday), DateTime(2026, 11, 23));
    expect(
      startOfWeek(DateTime(2026, 11, 23), DateTime.monday),
      DateTime(2026, 11, 23),
    );
  });

  test('date keys round-trip and reject garbage', () {
    expect(dateKey(DateTime(2026, 1, 5)), '2026-01-05');
    expect(parseDateKey('2026-01-05'), DateTime(2026, 1, 5));
    expect(parseDateKey(null), isNull);
    expect(parseDateKey('nope'), isNull);
    expect(parseDateKey('2026-xx-05'), isNull);
  });

  test('weekdayFromFirstDayIndex converts Sunday-based index', () {
    expect(weekdayFromFirstDayIndex(0), DateTime.sunday);
    expect(weekdayFromFirstDayIndex(1), DateTime.monday);
    expect(weekdayFromFirstDayIndex(6), DateTime.saturday);
  });

  test('isSameDay ignores time of day', () {
    expect(isSameDay(DateTime(2026, 11, 25, 1), DateTime(2026, 11, 25, 23)), true);
    expect(isSameDay(DateTime(2026, 11, 25), DateTime(2026, 11, 26)), false);
  });
}

DateTime at(int hour, int minute) => DateTime(2026, 11, 25, hour, minute);
