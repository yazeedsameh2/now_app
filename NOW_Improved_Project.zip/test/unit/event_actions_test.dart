import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/core/errors/form_error.dart';
import 'package:now_app/features/calendar/application/event_actions.dart';

import '../support/services.dart';
import '../support/test_data.dart';

void main() {
  EventDraft draft({
    String title = 'Standup',
    int start = 10 * 60,
    int end = 11 * 60,
    int? reminder,
  }) {
    return EventDraft(
      title: title,
      date: testToday,
      startMinutes: start,
      endMinutes: end,
      location: '  Room 1 ',
      reminderOffset: reminder,
    );
  }

  test('creates an event with cleaned optional fields', () async {
    final s = Services();

    final result = await s.eventActions.save(draft());

    expect(result.ok, isTrue);
    final event = s.events.all.single;
    expect(event.startsAt, at(10));
    expect(event.endsAt, at(11));
    expect(event.location, 'Room 1');
    expect(event.description, isNull);
  });

  test('end before or equal to start is rejected', () async {
    final s = Services();

    final same = await s.eventActions.save(draft(start: 600, end: 600));
    final before = await s.eventActions.save(draft(start: 600, end: 540));

    expect(same.errors, {FormError.endNotAfterStart});
    expect(before.errors, {FormError.endNotAfterStart});
    expect(s.events.all, isEmpty);
  });

  test('event reminder is scheduled, edited and cancelled on delete', () async {
    final s = Services();
    await s.eventActions.save(draft(reminder: 15));
    final event = s.events.all.single;
    expect(s.notifications.scheduled.values.single.triggerAt, at(9, 45));

    await s.eventActions.save(
      draft(start: 12 * 60, end: 13 * 60, reminder: 15),
      existing: event,
      previousReminderOffset: 15,
    );
    expect(s.notifications.scheduled, hasLength(1));
    expect(s.notifications.scheduled.values.single.triggerAt, at(11, 45));

    await s.eventActions.delete(event.id);
    expect(s.events.all, isEmpty);
    expect(s.reminders.items, isEmpty);
    expect(s.notifications.scheduled, isEmpty);
  });

  test('a reminder in the past is rejected', () async {
    final s = Services(now: at(10, 5));

    final result = await s.eventActions.save(draft(reminder: 15));

    expect(result.errors, {FormError.reminderInPast});
  });
}
