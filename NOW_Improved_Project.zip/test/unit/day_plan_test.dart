import 'package:flutter_test/flutter_test.dart';
import 'package:now_app/features/scheduling/domain/day_plan.dart';

import '../support/test_data.dart';

void main() {
  group('findConflicts', () {
    test('finds overlapping pairs only', () {
      final events = [
        makeEvent('a', 'A', at(9), at(10)),
        makeEvent('b', 'B', at(9, 30), at(10, 30)),
        makeEvent('c', 'C', at(10, 30), at(11)),
        makeEvent('d', 'D', at(13), at(14)),
      ];
      final conflicts = findConflicts(events);
      expect(conflicts, hasLength(1));
      expect(conflicts.single.first.id, 'a');
      expect(conflicts.single.second.id, 'b');
    });

    test('a long event conflicts with several others', () {
      final events = [
        makeEvent('long', 'Long', at(9), at(17)),
        makeEvent('x', 'X', at(10), at(11)),
        makeEvent('y', 'Y', at(12), at(13)),
      ];
      expect(findConflicts(events), hasLength(2));
    });

    test('input order does not matter', () {
      final events = [
        makeEvent('b', 'B', at(9, 30), at(10, 30)),
        makeEvent('a', 'A', at(9), at(10)),
      ];
      expect(findConflicts(events), hasLength(1));
    });

    test('no events, no conflicts', () {
      expect(findConflicts(const []), isEmpty);
    });
  });

  group('buildDayPlan', () {
    test('orders events and timed tasks chronologically, events first on ties',
        () {
      final plan = buildDayPlan(
        date: testToday,
        tasks: [
          makeTask('t1', 'Task at 10', dueDate: testToday, dueMinutes: 600),
          makeTask('t2', 'Task at 8', dueDate: testToday, dueMinutes: 480),
        ],
        events: [makeEvent('e1', 'Event at 10', at(10), at(11))],
      );
      expect(plan.timeline.map((e) => e.title), [
        'Task at 8',
        'Event at 10',
        'Task at 10',
      ]);
    });

    test('date-only tasks are anytime tasks, not timeline entries', () {
      final plan = buildDayPlan(
        date: testToday,
        tasks: [makeTask('t', 'Anytime', dueDate: testToday)],
        events: const [],
      );
      expect(plan.timeline, isEmpty);
      expect(plan.anytimeTasks.single.id, 't');
      expect(plan.isEmpty, isFalse);
    });

    test('ignores tasks and events of other days', () {
      final plan = buildDayPlan(
        date: testToday,
        tasks: [
          makeTask('t', 'Tomorrow', dueDate: DateTime(2026, 11, 26)),
          makeTask('u', 'Undated'),
        ],
        events: [makeEvent('e', 'Tomorrow', at(9, 0, 26), at(10, 0, 26))],
      );
      expect(plan.isEmpty, isTrue);
    });

    test('an overnight event appears on both days', () {
      final overnight = makeEvent('n', 'Night', at(22), at(1, 0, 26));
      final today = buildDayPlan(
        date: testToday,
        tasks: const [],
        events: [overnight],
      );
      final tomorrow = buildDayPlan(
        date: DateTime(2026, 11, 26),
        tasks: const [],
        events: [overnight],
      );
      expect(today.events, hasLength(1));
      expect(tomorrow.events, hasLength(1));
    });

    test('counts completed and total tasks', () {
      final plan = buildDayPlan(
        date: testToday,
        tasks: [
          makeTask('a', 'A', dueDate: testToday, dueMinutes: 600),
          makeTask('b', 'B', dueDate: testToday, completedAt: testNow),
          makeTask('c', 'C', dueDate: testToday),
        ],
        events: const [],
      );
      expect(plan.tasksTotal, 3);
      expect(plan.tasksDone, 1);
    });

    test('conflict ids list every event involved', () {
      final plan = buildDayPlan(
        date: testToday,
        tasks: const [],
        events: seedEvents(),
      );
      expect(plan.conflictEventIds, {'e-team', 'e-dentist'});
    });
  });

  group('computeOverview', () {
    final plan = buildDayPlan(
      date: testToday,
      tasks: [
        makeTask('t', 'Report', dueDate: testToday, dueMinutes: 14 * 60),
      ],
      events: seedEvents(),
    );

    test('next item is the first one not yet started', () {
      final overview = computeOverview(plan, at(9));
      expect(overview.nextEntry?.title, 'Team meeting');
      expect(overview.ongoingEvent, isNull);
    });

    test('reports the event in progress and the next item', () {
      final overview = computeOverview(plan, at(10, 15));
      expect(overview.ongoingEvent?.id, 'e-team');
      expect(overview.nextEntry?.title, 'Dentist');
    });

    test('nothing next after the last item', () {
      expect(computeOverview(plan, at(20)).nextEntry, isNull);
    });

    test('completed tasks are never "next"', () {
      final donePlan = buildDayPlan(
        date: testToday,
        tasks: [
          makeTask(
            't',
            'Done',
            dueDate: testToday,
            dueMinutes: 9 * 60 + 30,
            completedAt: testNow,
          ),
        ],
        events: const [],
      );
      expect(computeOverview(donePlan, at(9)).nextEntry, isNull);
    });
  });
}
