import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/shared/models/priority.dart';

/// Fixed "now": Wednesday, 25 November 2026, 09:00 local time.
final testNow = DateTime(2026, 11, 25, 9);
final testToday = DateTime(2026, 11, 25);

Task makeTask(
  String id,
  String title, {
  Priority priority = Priority.medium,
  DateTime? dueDate,
  int? dueMinutes,
  DateTime? completedAt,
}) {
  return Task(
    id: id,
    title: title,
    priority: priority,
    dueDate: dueDate,
    dueMinutes: dueMinutes,
    completedAt: completedAt,
    createdAt: DateTime(2026, 11, 1),
    updatedAt: DateTime(2026, 11, 1),
  );
}

Event makeEvent(
  String id,
  String title,
  DateTime startsAt,
  DateTime endsAt, {
  String? location,
}) {
  return Event(
    id: id,
    title: title,
    startsAt: startsAt,
    endsAt: endsAt,
    location: location,
    createdAt: DateTime(2026, 11, 1),
    updatedAt: DateTime(2026, 11, 1),
  );
}

DateTime at(int hour, [int minute = 0, int day = 25]) {
  return DateTime(2026, 11, day, hour, minute);
}

/// Tasks and events used by widget tests (all on or before testToday).
List<Task> seedTasks() => [
  makeTask(
    't-report',
    'Write report',
    priority: Priority.high,
    dueDate: testToday,
    dueMinutes: 14 * 60,
  ),
  makeTask('t-milk', 'Buy milk', dueDate: testToday),
  makeTask('t-old', 'Old task', dueDate: DateTime(2026, 11, 20)),
  makeTask(
    't-done',
    'Done thing',
    dueDate: testToday,
    completedAt: DateTime(2026, 11, 25, 8),
  ),
];

List<Event> seedEvents() => [
  makeEvent('e-team', 'Team meeting', at(10), at(11)),
  makeEvent('e-dentist', 'Dentist', at(10, 30), at(11, 30)),
  makeEvent('e-lunch', 'Lunch', at(13), at(14), location: 'Cafe'),
];
