import 'dart:async';

import 'package:now_app/features/calendar/domain/event.dart';
import 'package:now_app/features/calendar/domain/event_repository.dart';
import 'package:now_app/features/reminders/domain/notification_service.dart';
import 'package:now_app/features/reminders/domain/reminder.dart';
import 'package:now_app/features/reminders/domain/reminder_repository.dart';
import 'package:now_app/features/reminders/domain/reminder_texts.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';
import 'package:now_app/features/settings/domain/settings_repository.dart';
import 'package:now_app/features/tasks/domain/task.dart';
import 'package:now_app/features/tasks/domain/task_repository.dart';

/// Keyed in-memory collection with a change stream (no timers involved).
class _Store<T> {
  final Map<String, T> items = {};
  final StreamController<void> _changes = StreamController<void>.broadcast(
    sync: true,
  );

  void changed() => _changes.add(null);

  Stream<List<T>> watch() {
    late StreamController<List<T>> controller;
    StreamSubscription<void>? subscription;
    controller = StreamController<List<T>>(
      onListen: () {
        controller.add(items.values.toList());
        subscription = _changes.stream.listen(
          (_) => controller.add(items.values.toList()),
        );
      },
      onCancel: () => subscription?.cancel(),
    );
    return controller.stream;
  }
}

class InMemoryTaskRepository implements TaskRepository {
  InMemoryTaskRepository([List<Task> initial = const []]) {
    for (final task in initial) {
      _store.items[task.id] = task;
    }
  }

  final _Store<Task> _store = _Store<Task>();

  List<Task> get all => _store.items.values.toList();

  @override
  Stream<List<Task>> watchAll() => _store.watch();

  @override
  Future<List<Task>> getAll() async => all;

  @override
  Future<Task?> getById(String id) async => _store.items[id];

  @override
  Future<void> upsert(Task task) async {
    _store.items[task.id] = task;
    _store.changed();
  }

  @override
  Future<void> delete(String id) async {
    _store.items.remove(id);
    _store.changed();
  }

  @override
  Future<void> deleteAll() async {
    _store.items.clear();
    _store.changed();
  }
}

class InMemoryEventRepository implements EventRepository {
  InMemoryEventRepository([List<Event> initial = const []]) {
    for (final event in initial) {
      _store.items[event.id] = event;
    }
  }

  final _Store<Event> _store = _Store<Event>();

  List<Event> get all => _store.items.values.toList();

  @override
  Stream<List<Event>> watchAll() => _store.watch();

  @override
  Future<List<Event>> getAll() async => all;

  @override
  Future<Event?> getById(String id) async => _store.items[id];

  @override
  Future<void> upsert(Event event) async {
    _store.items[event.id] = event;
    _store.changed();
  }

  @override
  Future<void> delete(String id) async {
    _store.items.remove(id);
    _store.changed();
  }

  @override
  Future<void> deleteAll() async {
    _store.items.clear();
    _store.changed();
  }
}

class InMemoryReminderRepository implements ReminderRepository {
  final List<Reminder> items = [];
  int _nextId = 1;

  @override
  Future<List<Reminder>> getAll() async => List.of(items);

  @override
  Future<Reminder?> getForOwner(ReminderOwnerType type, String ownerId) async {
    for (final reminder in items) {
      if (reminder.ownerType == type && reminder.ownerId == ownerId) {
        return reminder;
      }
    }
    return null;
  }

  @override
  Future<Reminder> save({
    required ReminderOwnerType type,
    required String ownerId,
    required int offsetMinutes,
    required DateTime now,
  }) async {
    final existing = await getForOwner(type, ownerId);
    final id = existing?.id ?? _nextId++;
    final reminder = Reminder(
      id: id,
      ownerType: type,
      ownerId: ownerId,
      offsetMinutes: offsetMinutes,
    );
    items.removeWhere((r) => r.id == id);
    items.add(reminder);
    return reminder;
  }

  @override
  Future<void> removeForOwner(ReminderOwnerType type, String ownerId) async {
    items.removeWhere((r) => r.ownerType == type && r.ownerId == ownerId);
  }

  @override
  Future<void> deleteAll() async => items.clear();
}

class FakeSettingsRepository implements SettingsRepository {
  FakeSettingsRepository([this.settings = const AppSettings()]);

  AppSettings settings;
  int saveCount = 0;

  @override
  AppSettings load() => settings;

  @override
  Future<void> save(AppSettings settings) async {
    this.settings = settings;
    saveCount++;
  }
}

/// Records what would be scheduled with the operating system.
class FakeNotificationService implements NotificationService {
  FakeNotificationService({this.granted = true, this.grantOnRequest = false});

  bool granted;
  bool grantOnRequest;
  final Map<int, ReminderNotification> scheduled = {};
  final List<int> cancelled = [];
  int scheduleCalls = 0;

  @override
  Future<void> initialize() async {}

  @override
  Future<bool> permissionGranted() async => granted;

  @override
  Future<bool> requestPermission() async {
    if (grantOnRequest) {
      granted = true;
    }
    return granted;
  }

  @override
  Future<void> schedule(ReminderNotification notification) async {
    scheduleCalls++;
    scheduled[notification.id] = notification;
  }

  @override
  Future<void> cancel(int id) async {
    cancelled.add(id);
    scheduled.remove(id);
  }

  @override
  Future<Set<int>> pendingIds() async => scheduled.keys.toSet();
}

class FakeReminderTexts implements ReminderTexts {
  @override
  String body(PlannedNotification notification) => 'body-${notification.id}';
}
