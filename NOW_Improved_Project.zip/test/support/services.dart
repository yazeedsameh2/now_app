import 'package:now_app/database/unit_of_work.dart';
import 'package:now_app/features/calendar/application/event_actions.dart';
import 'package:now_app/features/reminders/application/reminder_coordinator.dart';
import 'package:now_app/features/tasks/application/task_actions.dart';

import 'fakes.dart';
import 'test_data.dart';

/// Real use cases wired to in-memory repositories and a fake notifier.
class Services {
  Services({
    bool notificationsGranted = true,
    bool remindersEnabled = true,
    DateTime? now,
  }) : clockValue = now ?? testNow,
       enabled = remindersEnabled,
       notifications = FakeNotificationService(granted: notificationsGranted) {
    coordinator = ReminderCoordinator(
      tasks: tasks,
      events: events,
      reminders: reminders,
      notifications: notifications,
      texts: FakeReminderTexts(),
      clock: () => clockValue,
      isEnabled: () => enabled,
    );
    taskActions = TaskActions(
      tasks: tasks,
      reminders: reminders,
      unitOfWork: PassthroughUnitOfWork(),
      coordinator: coordinator,
      clock: () => clockValue,
    );
    eventActions = EventActions(
      events: events,
      reminders: reminders,
      unitOfWork: PassthroughUnitOfWork(),
      coordinator: coordinator,
      clock: () => clockValue,
    );
  }

  DateTime clockValue;
  bool enabled;
  final InMemoryTaskRepository tasks = InMemoryTaskRepository();
  final InMemoryEventRepository events = InMemoryEventRepository();
  final InMemoryReminderRepository reminders = InMemoryReminderRepository();
  final FakeNotificationService notifications;
  late final ReminderCoordinator coordinator;
  late final TaskActions taskActions;
  late final EventActions eventActions;
}
