import 'package:flutter_test/flutter_test.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:material_ui/material_ui.dart';
import 'package:now_app/features/daily_review/presentation/daily_review_screen.dart';
import 'package:now_app/features/settings/domain/app_settings.dart';

import '../support/test_app.dart';
import '../support/test_data.dart';

void main() {
  setUpAll(() async {
    await initializeDateFormatting();
  });

  group('onboarding', () {
    testWidgets('first launch shows the introduction, then the dashboard', (
      tester,
    ) async {
      final h = await pumpNowApp(tester, onboardingDone: false);

      expect(find.byKey(const ValueKey('onboarding-title')), findsOneWidget);
      expect(find.text('Welcome to NOW'), findsOneWidget);
      expect(find.byType(NavigationBar), findsNothing);

      await tapScrolled(tester, find.byKey(const ValueKey('onboarding-start')));

      expect(find.byKey(const ValueKey('dashboard-empty')), findsOneWidget);
      expect(h.settings.settings.onboardingDone, isTrue);
    });

    testWidgets('language can be chosen during onboarding', (tester) async {
      await pumpNowApp(tester, onboardingDone: false);

      await tapScrolled(
        tester,
        find.byKey(const ValueKey('language-AppLanguage.arabic')),
      );

      expect(find.text('مرحبًا بك في NOW'), findsOneWidget);
    });
  });

  group('shell', () {
    testWidgets('English (LTR) empty dashboard with localized navigation', (
      tester,
    ) async {
      await pumpNowApp(tester);

      expect(directionOf(tester), TextDirection.ltr);
      expect(find.byKey(const ValueKey('dashboard-empty')), findsOneWidget);
      expect(find.text('Nothing planned for today'), findsOneWidget);
      expect(find.text('Wednesday, November 25, 2026'), findsOneWidget);
      for (final label in ['Home', 'Tasks', 'Calendar', 'Settings']) {
        expect(navLabel(label), findsOneWidget);
      }
    });

    testWidgets('Arabic (RTL) mirrors the layout and uses Arabic strings', (
      tester,
    ) async {
      await pumpNowApp(tester, language: AppLanguage.arabic);

      expect(directionOf(tester), TextDirection.rtl);
      expect(find.text('لا يوجد شيء مخطط لليوم'), findsOneWidget);
      for (final label in ['الرئيسية', 'المهام', 'التقويم', 'الإعدادات']) {
        expect(navLabel(label), findsOneWidget);
      }
    });

    testWidgets('navigates between all four tabs', (tester) async {
      await pumpNowApp(tester);

      await tester.tap(navLabel('Tasks'));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('tasks-empty')), findsOneWidget);

      await tester.tap(navLabel('Calendar'));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('calendar-title')), findsOneWidget);

      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('reminders-switch')), findsOneWidget);

      await tester.tap(navLabel('Home'));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('dashboard-empty')), findsOneWidget);
    });
  });

  group('dashboard with data', () {
    testWidgets('summary, next item, conflicts and sections are accurate', (
      tester,
    ) async {
      await pumpNowApp(
        tester,
        tasks: seedTasks(),
        events: seedEvents(),
        size: const Size(400, 2400),
      );

      expect(find.byKey(const ValueKey('dashboard-empty')), findsNothing);
      expect(find.text('1 of 3 tasks done'), findsOneWidget);
      expect(find.byKey(const ValueKey('dashboard-next')), findsOneWidget);
      expect(find.text('1 time conflict'), findsOneWidget);
      expect(find.text('Overdue'), findsOneWidget);
      expect(find.text('Old task'), findsOneWidget);
      expect(find.text('Anytime today'), findsOneWidget);
      expect(find.text('Buy milk'), findsOneWidget);
    });

    testWidgets('completing a task updates the summary immediately', (
      tester,
    ) async {
      final h = await pumpNowApp(
        tester,
        tasks: seedTasks(),
        events: seedEvents(),
        size: const Size(400, 2400),
      );

      await tapScrolled(tester, find.byKey(const ValueKey('check-t-milk')));

      expect(find.text('2 of 3 tasks done'), findsOneWidget);
      final milk = h.tasks.all.firstWhere((t) => t.id == 't-milk');
      expect(milk.isCompleted, isTrue);
    });

    testWidgets('overlapping events are flagged on the dashboard', (
      tester,
    ) async {
      await pumpNowApp(
        tester,
        tasks: seedTasks(),
        events: seedEvents(),
        size: const Size(400, 2400),
      );

      expect(find.byKey(const ValueKey('conflict-e-team')), findsOneWidget);
      expect(find.byKey(const ValueKey('conflict-e-dentist')), findsOneWidget);
      expect(find.byKey(const ValueKey('conflict-e-lunch')), findsNothing);
    });
  });

  group('tasks', () {
    testWidgets('filters show the right tasks', (tester) async {
      await pumpNowApp(tester, tasks: seedTasks());
      await tester.tap(navLabel('Tasks'));
      await tester.pumpAndSettle();

      expect(find.text('Write report'), findsOneWidget);
      expect(find.text('Old task'), findsOneWidget);
      expect(find.text('Done thing'), findsNothing);

      await tester.tap(find.byKey(const ValueKey('filter-completed')));
      await tester.pumpAndSettle();
      expect(find.text('Done thing'), findsOneWidget);
      expect(find.text('Write report'), findsNothing);

      await tester.tap(find.byKey(const ValueKey('filter-all')));
      await tester.pumpAndSettle();
      expect(find.text('Done thing'), findsOneWidget);
      expect(find.text('Write report'), findsOneWidget);
    });

    testWidgets('creating a task validates the title, then saves', (
      tester,
    ) async {
      final h = await pumpNowApp(tester);
      await tester.tap(navLabel('Tasks'));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const ValueKey('tasks-fab')));
      await tester.pumpAndSettle();
      expect(find.text('New task'), findsOneWidget);

      await tapScrolled(tester, find.byKey(const ValueKey('save-button')));
      expect(find.text('Please enter a title.'), findsOneWidget);
      expect(h.tasks.all, isEmpty);

      await tester.enterText(
        find.byKey(const ValueKey('title-field')),
        'Call mom',
      );
      await tapScrolled(tester, find.byKey(const ValueKey('save-button')));

      expect(h.tasks.all.single.title, 'Call mom');
      expect(find.text('Call mom'), findsOneWidget);
      expect(find.byKey(const ValueKey('tasks-fab')), findsOneWidget);
    });

    testWidgets('editing a task changes it', (tester) async {
      final h = await pumpNowApp(tester, tasks: seedTasks());
      await tester.tap(navLabel('Tasks'));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const ValueKey('task-t-milk')));
      await tester.pumpAndSettle();
      expect(find.text('Edit task'), findsOneWidget);

      await tester.enterText(
        find.byKey(const ValueKey('title-field')),
        'Buy oat milk',
      );
      await tapScrolled(tester, find.byKey(const ValueKey('save-button')));

      final milk = h.tasks.all.firstWhere((t) => t.id == 't-milk');
      expect(milk.title, 'Buy oat milk');
      expect(find.text('Buy oat milk'), findsOneWidget);
    });

    testWidgets('deleting asks for confirmation first', (tester) async {
      final h = await pumpNowApp(tester, tasks: seedTasks());
      await tester.tap(navLabel('Tasks'));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('task-t-milk')));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const ValueKey('delete-button')));
      await tester.pumpAndSettle();
      expect(find.text('Delete this task?'), findsOneWidget);

      await tester.tap(find.text('Cancel'));
      await tester.pumpAndSettle();
      expect(h.tasks.all.any((t) => t.id == 't-milk'), isTrue);

      await tester.tap(find.byKey(const ValueKey('delete-button')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('confirm-action')));
      await tester.pumpAndSettle();

      expect(h.tasks.all.any((t) => t.id == 't-milk'), isFalse);
    });
  });

  group('calendar', () {
    testWidgets('day view lists the day and flags conflicts', (tester) async {
      await pumpNowApp(
        tester,
        tasks: seedTasks(),
        events: seedEvents(),
        size: const Size(400, 2400),
      );
      await tester.tap(navLabel('Calendar'));
      await tester.pumpAndSettle();

      expect(find.text('Team meeting'), findsOneWidget);
      expect(find.text('Dentist'), findsOneWidget);
      expect(find.text('Lunch'), findsOneWidget);
      expect(find.text('Write report'), findsOneWidget);
      expect(find.byKey(const ValueKey('conflict-e-team')), findsOneWidget);
    });

    testWidgets('next and previous day navigation', (tester) async {
      await pumpNowApp(
        tester,
        tasks: seedTasks(),
        events: seedEvents(),
        size: const Size(400, 2400),
      );
      await tester.tap(navLabel('Calendar'));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const ValueKey('calendar-next')));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('calendar-empty-day')), findsOneWidget);
      expect(find.text('Team meeting'), findsNothing);

      await tester.tap(find.byKey(const ValueKey('calendar-today')));
      await tester.pumpAndSettle();
      expect(find.text('Team meeting'), findsOneWidget);
    });

    testWidgets('week view shows seven days with counts', (tester) async {
      await pumpNowApp(
        tester,
        tasks: seedTasks(),
        events: seedEvents(),
        size: const Size(400, 2400),
      );
      await tester.tap(navLabel('Calendar'));
      await tester.pumpAndSettle();

      await tester.tap(find.text('Week'));
      await tester.pumpAndSettle();

      expect(find.byKey(const ValueKey('week-day-2026-11-25')), findsOneWidget);
      expect(find.text('3 events, 3 tasks'), findsOneWidget);
    });
  });

  group('daily review', () {
    testWidgets('summarizes the day and moves nothing by itself', (
      tester,
    ) async {
      final h = await pumpScreen(
        tester,
        DailyReviewScreen(date: testToday),
        tasks: seedTasks(),
      );

      expect(find.text('You completed 1 of 3 tasks.'), findsOneWidget);
      expect(find.text('Done thing'), findsOneWidget);
      expect(find.text('Buy milk'), findsOneWidget);
      expect(
        h.tasks.all.firstWhere((t) => t.id == 't-milk').dueDate,
        testToday,
      );
    });

    testWidgets('moving all open tasks requires confirmation', (tester) async {
      final h = await pumpScreen(
        tester,
        DailyReviewScreen(date: testToday),
        tasks: seedTasks(),
      );

      await tapScrolled(tester, find.byKey(const ValueKey('review-move-all')));
      expect(find.text('Move open tasks to tomorrow?'), findsOneWidget);
      await tester.tap(find.text('Cancel'));
      await tester.pumpAndSettle();
      expect(
        h.tasks.all.firstWhere((t) => t.id == 't-milk').dueDate,
        testToday,
      );

      await tapScrolled(tester, find.byKey(const ValueKey('review-move-all')));
      await tester.tap(find.byKey(const ValueKey('confirm-action')));
      await tester.pumpAndSettle();

      final tomorrow = DateTime(2026, 11, 26);
      expect(h.tasks.all.firstWhere((t) => t.id == 't-milk').dueDate, tomorrow);
      expect(
        h.tasks.all.firstWhere((t) => t.id == 't-report').dueDate,
        tomorrow,
      );
      expect(
        h.tasks.all.firstWhere((t) => t.id == 't-done').dueDate,
        testToday,
      );
    });
  });

  group('settings', () {
    testWidgets('switching language to Arabic flips to RTL and persists', (
      tester,
    ) async {
      final h = await pumpNowApp(tester);
      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();

      await tester.tap(
        find.byKey(const ValueKey('language-AppLanguage.arabic')),
      );
      await tester.pumpAndSettle();

      expect(directionOf(tester), TextDirection.rtl);
      expect(h.settings.settings.language, AppLanguage.arabic);
    });

    testWidgets('switching theme to dark changes brightness', (tester) async {
      final h = await pumpNowApp(tester);
      expect(brightnessOf(tester), Brightness.light);
      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const ValueKey('theme-AppThemeSetting.dark')));
      await tester.pumpAndSettle();

      expect(brightnessOf(tester), Brightness.dark);
      expect(h.settings.settings.theme, AppThemeSetting.dark);
    });

    testWidgets('reminders switch is persisted', (tester) async {
      final h = await pumpNowApp(tester);
      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const ValueKey('reminders-switch')));
      await tester.pumpAndSettle();

      expect(h.settings.settings.remindersEnabled, isFalse);
    });

    testWidgets('deleting all data needs confirmation and clears everything', (
      tester,
    ) async {
      final h = await pumpNowApp(
        tester,
        tasks: seedTasks(),
        events: seedEvents(),
      );
      await tester.tap(navLabel('Settings'));
      await tester.pumpAndSettle();

      await tapScrolled(tester, find.byKey(const ValueKey('reset-data')));
      expect(find.text('Delete all data?'), findsOneWidget);
      await tester.tap(find.text('Cancel'));
      await tester.pumpAndSettle();
      expect(h.tasks.all, isNotEmpty);

      await tapScrolled(tester, find.byKey(const ValueKey('reset-data')));
      await tester.tap(find.byKey(const ValueKey('confirm-action')));
      await tester.pumpAndSettle();

      expect(h.tasks.all, isEmpty);
      expect(h.events.all, isEmpty);
    });
  });

  group('small screen (320x568), no overflow', () {
    for (final language in [AppLanguage.english, AppLanguage.arabic]) {
      for (final theme in [AppThemeSetting.light, AppThemeSetting.dark]) {
        testWidgets('${language.name}, ${theme.name}', (tester) async {
          await pumpNowApp(
            tester,
            language: language,
            theme: theme,
            tasks: seedTasks(),
            events: seedEvents(),
            size: const Size(320, 568),
          );

          for (var index = 0; index < 4; index++) {
            await tester.tap(find.byType(NavigationDestination).at(index));
            await tester.pumpAndSettle();
            expect(tester.takeException(), isNull);
          }
        });
      }
    }

    testWidgets('forms fit a small screen', (tester) async {
      await pumpNowApp(tester, size: const Size(320, 568));
      await tester.tap(navLabel('Tasks'));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('tasks-fab')));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    });
  });
}
